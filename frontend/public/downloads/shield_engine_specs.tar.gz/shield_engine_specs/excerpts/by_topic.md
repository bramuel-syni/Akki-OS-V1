# Verbatim excerpts by topic

Mechanical `sed -n '<s>,<e>p'` outputs. Zero editorial prose between blocks.


## T1 — Shield role & positioning (per doctrine)

### `/app/docs/governance/registry_doctrine_v1.md:107-111`

```
| 2 · Classical NLP (spaCy-class) | Tokenization, NER, sentence segmentation, language ID, rule-based tagging — anywhere linguistic structure is needed without open reasoning. | CPU-cheap, deterministic-enough, offline-capable. |
| 3 · Small owned models | Estate-fine-tuned perception and domain models (ASR, diarization, classifiers) from the transformation layer; registry-pinned. | Owned IP, near-free inference in-perimeter; the flywheel migrates work down to this rung continuously. |
| 4 · Frontier LLM | Open synthesis only: fluent composition, brief narrative — always behind the Shield, always with a lower-rung fallback arm. | Highest unit cost; every use answers "why not rung 3?" at Stage A. |

The deflation law: the transformation layer is the cost answer to itself. Every training cycle on the estate produces owned models that migrate rung-4 and rung-2 work to rung 3, and rung-3 findings that harden into rung-1 checks. The flywheel that improves quality is the same flywheel that deflates unit cost — by design, not by hope.
```


## T2 — Shield-mediated model invocation (Sonnet 4.6 via Shield, rung classification)

### `/app/docs/registry/function_promise_registry_v0.md:100-105`

```
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
```

### `/app/docs/requirements/operating_values_v1.md:18-22`

```
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:17-21`

```
**Disposition — applied verbatim:**

- LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured JSON via Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (mirrors AF-E1 β precedent).
- Grounding gate at `services/opportunity_briefs/brief_grounding.py::verify_brief_grounding(...)`:
  - **(A) byte-verbatim value check:** every `value` in `quantitative_anchors` MUST appear byte-verbatim in the text of the Registry read at `registry_read_ref`. Mechanical byte-substring check; **no semantic scoring**.
```


## T3 — Fluency synthesizer via Shield (`synisense.shield.fluency_synthesizer`)

### `/app/docs/registry/function_promise_registry_v0.md:100-106`

```
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:411-415`

```
    source: v0.md
    rulings: []
  - function_id: synisense.shield.fluency_synthesizer
    governor: SyniSense
    mandate: "Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass."
```

### `/app/docs/registry/machine/registry.yaml:419-423`

```
    service_trace:
      - S1.call
    surface: "`backend/services/synisense/shield/fluency_synthesizer.py:L182`"
    enforcement: Runtime chokepoint + AST single-source (piggyback)
    cost: AF-G6a · §6.11 · 4 async cells
```

### `/app/docs/registry/machine/registry.yaml:450-454`

```
    service_trace:
      - S1.call
    surface: "`backend/services/synisense/shield/fluency_synthesizer.py` (structured output block)"
    enforcement: Runtime schema validate
    cost: AF-E1 β per-sentence structured mapping cells
```

### `/app/backend/services/synisense/shield/fluency_synthesizer.py:53-57`

```


log = logging.getLogger("synisense.shield.fluency_synthesizer")
```

### `/app/backend/services/service_1/composed_conclusion.py:90-94`

```
from services.service_1.answer_grounding import verify_grounding
from services.service_1.fluency_mode_telemetry import annotate_result
from services.synisense.shield.fluency_synthesizer import (
    EmergentKeyMissingError,
    LLMParseFailureError,
```

### `/app/backend/routers/service_1.py:39-43`

```
from services.service_1 import qualified_data as qualified_data_module
from services.service_1 import service
from services.synisense.shield import fluency_synthesizer as fluency_synthesizer_module
```

### `/app/backend/routers/service_1.py:288-292`

```
            detail=f"async delivery queue saturated: {exc}",
        )
    except fluency_synthesizer_module.EmergentKeyMissingError as exc:
        # Answer Fluency AF-E2 amended boundary (Owner 2026-07-10):
        # CONFIG DEFECT → fail loud. Emergent LLM key missing/invalid
```


## T4 — Brief synthesizer via Shield (`synisense.shield.brief_synthesizer`)

### `/app/docs/registry/function_promise_registry_v0.md:101-105`

```
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:427-431`

```
    source: v0.md
    rulings: []
  - function_id: synisense.shield.brief_synthesizer
    governor: SyniSense
    mandate: "Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for(\"analytical\")` reuse of Phase 7 Stage B-2 seed."
```

### `/app/docs/registry/machine/registry.yaml:435-439`

```
    service_trace:
      - S1.call (advisory to S1's app-facing)
    surface: "`backend/services/synisense/shield/brief_synthesizer.py:L116`"
    enforcement: Runtime chokepoint
    cost: OB-G1 async cells · §6.11
```

### `/app/backend/services/synisense/shield/brief_synthesizer.py:44-48`

```


log = logging.getLogger("synisense.shield.brief_synthesizer")
```

### `/app/backend/services/opportunity_briefs/generator.py:9-13`

```
     the map today; production wiring lands post-9.2b when the
     Registry read API is populated).
  3. Call Shield brief_synthesizer for a `{brief_text,
     quantitative_anchors}` payload.
  4. Verify grounding — mechanical byte-verbatim per OB-E1 α.
```

### `/app/backend/services/opportunity_briefs/generator.py:36-40`

```
from services.opportunity_briefs.brief_grounding import verify_brief_grounding
from services.opportunity_briefs.brief_telemetry import annotate_brief_result
from services.synisense.shield import brief_synthesizer as _synth
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:17-21`

```
**Disposition — applied verbatim:**

- LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured JSON via Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (mirrors AF-E1 β precedent).
- Grounding gate at `services/opportunity_briefs/brief_grounding.py::verify_brief_grounding(...)`:
  - **(A) byte-verbatim value check:** every `value` in `quantitative_anchors` MUST appear byte-verbatim in the text of the Registry read at `registry_read_ref`. Mechanical byte-substring check; **no semantic scoring**.
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:53-57`

```
- Registry-computable aggregate = a numeric field the Registry read API (`services/mtafiti/registry.py`) exposes as its own read (e.g., `count_of_units_in_slice(slice_id) → int`).
- The brief quotes the returned value byte-verbatim in `brief_text` with corresponding `registry_read_ref` in `quantitative_anchors`.
- **Synthesis-time computation FORBIDDEN:** no `sum(...)` / `avg(...)` / `min(...)` / `max(...)` / `count(...)` or equivalent operator applied inside `services/synisense/shield/brief_synthesizer.py` or `services/opportunity_briefs/brief_proposer.py` at synthesis time.
- Enforcement: §6.10 grep-negative reflection gate on generator + synthesizer paths for the operator whitelist.
- β (whitelisted operator replay) explicitly declined; γ (no aggregates) explicitly declined.
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:99-103`

```
- **§6.10 AST/reflection (AS-G6 / TF-G9 / FR-G4 / AF-G6b lineage)** → OB-E2 Seam-1/2/3 α mechanism.
- **Sidecar telemetry (9.2a-E2 α cond 2 + AF-E3 α)** → OB fluency-mode-style observability.
- **Shield chokepoint (Phase 7 Stage B-2)** → OB brief_synthesizer via `llm_router::_provider_for("analytical")`.

---
```


## T5 — Mechanical fallback arms (verbatim per registry rows)

### `/app/docs/registry/function_promise_registry_v0.md:50-54`

```
| PROM-S1-registry-native-aggregate | A Combined-scope aggregate = Registry-exposed native (the Registry computes; the brief/answer quotes byte-verbatim); synthesis-time computation is FORBIDDEN. | yes | 2 | OB-E3 α · doctrine §Part VII |
| PROM-S1-class-honesty-render-time | Class-honesty is enforced at render time — no render path strips the advisory marker; no governed-response import path touches advisory content; namespace boundaries surfaced via distinct id prefixes. | yes | 4 | OB-E2 α × 3 seams · AS-G6 · TF-G9 · FR-G4 · AF-G6b |
| PROM-S1-runtime-transient-never-refusal | Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope. | yes | 2 | AF-E2 amended · OB-runtime-transient-precedent |
| PROM-S1-config-defect-fail-loud | Config defects (missing Emergent key · invalid key) fail loud 503 at startup; NEVER routed via refusal envelope. | yes | 1 | AF-E2 amended |
| PROM-S2-estate-onboarded-and-mapped | The Operator's estate is onboarded, mapped, and turned into qualified intelligence they can commit with confidence. | yes | 1 | doctrine §Part II S2 · BCR v1.5 §3.4 (housing) |
```

### `/app/docs/registry/function_promise_registry_v0.md:100-105`

```
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:111-115`

```
      - AF-G6b
  - promise_id: PROM-S1-runtime-transient-never-refusal
    text: Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope.
    active: true
    functions_that_cite: 2
```

### `/app/docs/registry/machine/registry.yaml:423-427`

```
    cost: AF-G6a · §6.11 · 4 async cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (with mechanical fallback per AF-E2 amended)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:439-443`

```
    cost: OB-G1 async cells · §6.11
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)
    owner: Owner
    source: v0.md
```

### `/app/docs/requirements/operating_values_v1.md:18-22`

```
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```


## T6 — Cost classification & rung-4 accounting

### `/app/docs/registry/function_promise_registry_v0.md:70-74`

```
| PROM-S5-substrate-not-optimized-against | Akki's extraction and governance capacity as a substrate for future ventures; no platform function may cite S5 as sole anchor without Owner ruling. | no (internal / future) | 0 (registered, unbuilt) | doctrine §Part II S5 |
| PROM-registry-taxonomy-canonical | Every function belongs to SyniSense · Northena · Mtafiti · Targeta · Solva OR a named surface; no new top-level categories without Owner ruling. | no | 6 | doctrine §3.1 |
| PROM-registry-schema-conformance | Every function row populates all 11 §3.2 schema fields; `unknown` is legal only for `cost` (and per RP-E4 α for `ladder_rung` where source silent). | no | 1 | doctrine §3.2 R1 · RP-E4 α |
| PROM-registry-service-trace-integrity | Every promise cites at least one S1..S5 sentence + journey step; empty/invalid trace = D1 orphan finding. | no | 1 | doctrine R2 · RP-G4 |
| PROM-registry-rent-paying | The Registry itself is subject to §3.4 queries (Q1/Q2/Q3); if it stops retiring gates, finding gaps, or cheapening sequences over sustained time it is itself retired or restructured. | no | 1 | doctrine §3.6 · doctrine D-8 |
```

### `/app/docs/registry/function_promise_registry_v0.md:98-106`

```
|---|---|---|---|---|---|---|---|---|---|---|
| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:196-200`

```
| registry.population.g1_promise_set_completeness | (named surface: Registry) | Attest every "Promise protected" source line resolves to a §2 promise-row OR §4 Q2 orphan. | PROM-registry-service-trace-integrity | S3.prove | This file §2 + §4 | grep-negative (source-line vs promise-row citation) | RP-G1 · §6.1 · unknown | 1 · Deterministic | Owner |
| registry.population.g2_function_attachment_completeness | (named surface: Registry) | Attest every named-gate identifier in CI roster has a function row OR appears in §4 Q2. | PROM-registry-service-trace-integrity | S3.prove · S1.call | This file §3 + §4 | grep-negative | RP-G2 · unknown | 1 · Deterministic | Owner |
| registry.population.g3_schema_conformance | (named surface: Registry) | Attest every §3 row populates all 11 §3.2 fields; `unknown` legal only for `cost` + `ladder_rung` (per RP-E4 α). | PROM-registry-schema-conformance | S3.prove | This file §3 | table-shape lint | RP-G3 · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.g4_service_trace_integrity | (named surface: Registry) | Attest every `service_trace` cites S1..S5 + journey step from doctrine Part II verbatim. | PROM-registry-service-trace-integrity | S1..S5 · S3.prove | This file §3 | reference-check | RP-G4 · unknown | 1 · Deterministic | Owner |
| registry.population.g5_q2_orphan_coverage | (named surface: Registry) | Attest every unrecoverable-promise gate appears in §4 Q2 list. | PROM-registry-rent-paying | S3.prove | This file §4 | inclusion-check | RP-G5 · unknown | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:203-207`

```
| registry.population.q2_q3_client_promise_escalation | (named surface: Registry) | Per RP-E2 α: route every client-promise-touching Q2/Q3 finding to `[CLIENT-PROMISE · ESCALATE-AT-CLOSE]` marker in §4/§5 + surface at close. | PROM-registry-rent-paying · PROM-S1-provable-envelope-inheritance | S1.call · S3.prove · S4.receive | This file §4 + §5 + §7 | grep-negative on client-promise class keywords | RP-E2 α · unknown | 1 · Deterministic | Owner |
| registry.population.governor_scope_boundary_ruling | (named surface: Registry) | Per RP-E3 α-amended: (i)∧(ii) → §3 row; (i)∧¬(ii) → §5 Q3 gap finding, never dropped; sub-steps fold into parent's mandate. | PROM-registry-taxonomy-canonical | S2.commission · S3.prove | This file §3 + §5 | grep-positive on §-clause citations | RP-E3 α-amended · unknown | 1 · Deterministic (mandate-clause match) | Owner |
| registry.population.ladder_rung_unknown_honesty | (named surface: Registry) | Per RP-E4 α: `ladder_rung: unknown` is the honest value where source is silent; NO builder-guessed rungs. | PROM-S1-honesty-grammar-source-labels · PROM-registry-schema-conformance | S3.prove | This file §3 | grep-positive on `unknown` where evidence absent | RP-E4 α · unknown | 1 · Deterministic | Owner |
| registry.population.gaux_parity_31_preserved | (named surface: Registry · SyniSense) | Attest 31 frozen contracts + 31 snapshots byte-identical at Registry Population close. | PROM-S1-frozen-wire-contract | S1.call · S3.prove | `backend/contracts/**` + `*.contract_snapshot.json` | fs-count (shared parity_counter) | RP-G-Parity · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.gaux_data_blind | (named surface: Registry) | Attest zero secret values in the Registry deliverable (grep-negative on MongoDB URI · JWT · sk-* · AKIA*). | PROM-S1-honesty-grammar-source-labels · governance §8 | S3.prove | This file (whole) | grep-negative on secret patterns | RP-G-DataBlind · §6.1 | 1 · Deterministic | builder-Tier-3 |
```

### `/app/docs/registry/machine/registry.yaml:391-395`

```
    cost: 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class
    dependencies: AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring
    ladder_rung: 1 · Deterministic + rung-4 upstream synthesis
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:407-411`

```
    cost: OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11
    dependencies: ""
    ladder_rung: 1 · Deterministic + rung-4 upstream
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:423-427`

```
    cost: AF-G6a · §6.11 · 4 async cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (with mechanical fallback per AF-E2 amended)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:439-443`

```
    cost: OB-G1 async cells · §6.11
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:454-458`

```
    cost: AF-E1 β per-sentence structured mapping cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (structured output)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:1421-1425`

```
  - function_id: registry.population.g3_schema_conformance
    governor: "(named surface: Registry)"
    mandate: "Attest every §3 row populates all 11 §3.2 fields; `unknown` legal only for `cost` + `ladder_rung` (per RP-E4 α)."
    promise:
      - PROM-registry-schema-conformance
```

### `/app/docs/governance/registry_doctrine_v1.md:107-117`

```
| 2 · Classical NLP (spaCy-class) | Tokenization, NER, sentence segmentation, language ID, rule-based tagging — anywhere linguistic structure is needed without open reasoning. | CPU-cheap, deterministic-enough, offline-capable. |
| 3 · Small owned models | Estate-fine-tuned perception and domain models (ASR, diarization, classifiers) from the transformation layer; registry-pinned. | Owned IP, near-free inference in-perimeter; the flywheel migrates work down to this rung continuously. |
| 4 · Frontier LLM | Open synthesis only: fluent composition, brief narrative — always behind the Shield, always with a lower-rung fallback arm. | Highest unit cost; every use answers "why not rung 3?" at Stage A. |

The deflation law: the transformation layer is the cost answer to itself. Every training cycle on the estate produces owned models that migrate rung-4 and rung-2 work to rung 3, and rung-3 findings that harden into rung-1 checks. The flywheel that improves quality is the same flywheel that deflates unit cost — by design, not by hope.

## §5.2 The sequencing harness

Specification (enters as code only on Owner dispatch): a harness that executes registered functions against fixture traffic in candidate orderings and measures real cost — not simulated approximations. Principle: this system is predominantly deterministic; you do not simulate a deterministic gate, you run it. Orderings are optimized over the Registry's cost and dependency fields: cheap gates before expensive, deterministic rungs before model rungs, independent functions in parallel, fail-fast paths surfaced. Honest boundary, stated as a spec constraint: rung-3/rung-4 behavior is measured statistically (repeated runs over the harness, route-level comparisons), never claimed as exact. Output: the measured best path of integration and sequencing per journey — replacing sequencing judgment with sequencing measurement, and back-filling every "unknown" cost field in the Registry.

# Part VI — The culture layer
```


## T7 — Behavioural bindings (D-* defect classes touching Shield, if any)

### `/app/docs/governance/registry_doctrine_v1.md:52-56`

```
| service_trace | The Layer 0 sentence(s) and journey step(s) this promise secures (e.g. S1.call, S3.prove). Empty or invalid trace = orphan (Q2). |
| surface | Where it acts: module path, route, contract, console element. |
| enforcement | Mechanism class: byte-identity lock · AST/reflection walk · grep-negative · runtime check · E2E cell · type-level wall · constraint-architecture (§6.1). "NL-only" is not a legal value (defect D2). |
| cost | Execution time class, maintenance burden, false-positive rate where known. "Unknown" is a legal initial value; it must be replaced by measurement when the sequencing harness first exercises the function. |
| dependencies | Functions or data required ordered-before. Input to sequencing. |
```

### `/app/docs/governance/registry_doctrine_v1.md:79-83`

```
## §3.6 The Registry pays rent

The Registry is subject to its own law. Its rent is the three queries: if over a sustained period it stops retiring gates, finding gaps, or cheapening sequences, it is itself retired or restructured by Owner ruling. One artifact, one schema; a second meta-layer above it is defect D5.

# Part IV — Behavioral doctrine (in force on ratification)
```

### `/app/docs/governance/registry_doctrine_v1.md:85-98`

```
These bind every actor in the build — Owner's ruling authority, builder, and any agent or model worker — immediately on ratification, with no code change required:

- D-1 · Reasoning order. Service → journey → promise → function, in every scoping, escalation, and ruling. Escalations name the promise protected and its service trace (the existing "Promise protected" discipline, now with the trace made explicit).
- D-2 · Rules pay rent. Every gate carries its promise and its cost. A gate that protects no live promise is retired, not preserved out of caution. Caution that costs forever must justify itself forever.
- D-3 · The conflation test. Before any function is proposed: which Layer 0 sentence does this serve? No sentence, no build. This is the structural prevention of "doing the wrong job well."
- D-4 · Cheapest-sufficient rung. Every task lands on the lowest model-ladder rung that meets its promise (§5.1). Rung inflation requires written justification at Stage A.
- D-5 · NL is interface, never enforcement. Every natural-language rule pairs with a machine-enforced twin. NL-only enforcement is defect D2, reportable on sight.
- D-6 · Constraint architecture first. Prefer designs where correct behavior is the path of least resistance; gates are the backstop, not the mechanism. Every promise the architecture absorbs is a gate never written (§6.1).
- D-7 · Verdicts are never curated. Inputs, models, corpora, and discovery paths may be engineered without limit; validation verdicts are drawn from measured composition, uncurated, and published internally whatever they say (Part VII).
- D-8 · Reduction applies to its own output. Specs, trackers, and meta-artifacts are retired when they stop earning. The dead-tracker sweep is a standing pattern, not an event.
- D-9 · Platform serves applications. No platform decision optimizes end-user UX directly; end-user experience is application territory (Part II).
- D-10 · Builder conduct standard. Meticulousness is enforced by structure, not assumed: every proposal self-audits against defect classes D1–D7 before submission, and a proposal arriving with a defect the self-audit would have caught is itself a reportable finding.

# Part V — Cost architecture
```

### `/app/docs/governance/registry_doctrine_v1.md:129-133`

```
# Part VII — Extraction quality: the de-risking specification

Premise, Owner-agreed: extraction quality on a specific estate is unmeasured until measured — but its weak surfaces are enumerable in advance, each has existing open art, and each maps to a designed lever in the platform. The gap is speccable, not fated. Governing principle, restating D-7: engineer the inputs relentlessly; never touch the test. Model choice, fine-tuning, augmentation, and corpus curation are legitimate curation of success; the validation verdict (the human-baseline benchmark, BM-V) is drawn from measured estate composition, post-census, uncurated — a rehearsed checkpoint is preparation; a curated verdict is worthless.

| Weak surface | Existing art (starting points) | Akki lever | Pre-verdict checkpoint |
```

### `/app/docs/governance/registry_doctrine_v1.md:152-156`

```
## §8.1 What is in force, what drafts, what codes

- In force on ratification (no build): Part II service layer; Part III derivation rules R1–R4 as scoping discipline; Part IV doctrine D-1–D-9; Part VII claims discipline.
- Documents (draft on Owner word, no code): Registry population (§3.5 archaeology); Instance Replication Playbook; Commercial Thesis.
- Code-level (each enters only via Stage A → Owner ruling → atomic execution → close, on explicit Owner dispatch; no schedule exists or is implied): (a) the three standing queries as executable checks over a machine-readable Registry; (b) the sequencing harness (§5.2); (c) Registry-as-context worker harnessing (§6.2); (d) the Registry's machine-readable form itself; (e) far endpoint — mandates as structured specs from which gates are generated.
```

### `/app/docs/governance/registry_doctrine_v1.md:159-173`

```
## §8.2 Defect classes (named, reportable on sight)

- D1 · Orphan gate: function with no honest promise or no service trace.
- D2 · NL-only enforcement: a rule whose only enforcement is prose interpretation.
- D3 · Curated verdict: any selection of validation material by favorability rather than measured composition.
- D4 · Rung inflation: model-ladder placement above cheapest-sufficient without written Stage A justification.
- D5 · Meta-spiral: a second governance layer above the Registry; governance artifacts that stop paying rent.
- D6 · Service conflation: platform function optimized for an end-user persona rather than a Layer 0 service; the wrong job done well.
- D7 · Invented schedule or scope: sequencing, deferral, or owner-side workstreams introduced without Owner instruction — binding on the ruling authority and the builder alike.

## §8.3 Ratification

This document binds on Owner ratification of: (a) the five Layer 0 service sentences verbatim or as corrected; (b) the doctrine set D-1–D-9; (c) the defect classes D1–D7. On ratification it lands on-disk as a governed artifact beside the governor mandates, and R4 takes effect for all subsequent Stage A proposals.

Syni.ai · The Registry Doctrine v1.0 · Companion to: governor mandate documents · tiered ruling model · BCR v1.5 · Extraction De-Risking Spec v1
```

### `/app/docs/registry/function_promise_registry_v0.md:29-33`

```
**Owner-ruled RP-E2 α** (2026-07-11): client-promise-touching Q2/Q3 findings publish verbatim in the deliverable with `[CLIENT-PROMISE · ESCALATE-AT-CLOSE]` markers. Zero builder-retirement in this phase.

**Owner rulings on all 11 findings** (2026-07-11 · post-close): **RULED · 11 of 11 applied** — dispositions recorded in `docs/rulings/registry_findings_01_to_11.md` (Owner verbatim carrier). Corrections applied to §2 (new `PROM-S1-external-scoped-access` from Q2-01) + §3.f (`ui.engineer.onboarding` re-attachment) + §4/§5 rows (per-finding `[RULED · …]` annotation). Defect D7 respected: gap-fill cells become candidates for future Owner-dispatched phases, NOTHING MORE. No code work dispatched.

---
```

### `/app/docs/registry/function_promise_registry_v0.md:45-51`

```
| PROM-S1-frozen-wire-contract | External parties consume a stable schema over time; frozen contracts are byte-identical; parity is attested at every close. | yes | 6 | V1-G7 · TF-E1 α · CD-E2 α · doctrine §Part VIII |
| PROM-S1-additive-versioning | New contracts land by additive versioning (v0 preserved byte-identical when v1 lands); parity bumps with the new snapshot; V1-G7 assertion set bumps with it. | yes | 2 | AS-E1 α · V1-G7 |
| PROM-S1-honesty-grammar-source-labels | Every value in a client-facing envelope carries its provenance source label; values not observed by the census carry a non-`census_observed` source label OR are null; NO fabricated values. | yes | 5 | CD-E1 α · 9.2a-E1 α · doctrine D-3 |
| PROM-S1-byte-verbatim-anchor-grounding | Every quantitative anchor in an LLM-synthesized advisory or answer must appear byte-verbatim in a Registry-read text; whole-envelope REJECT on any failure; gate NEVER patches prose. | yes | 3 | AF-E1 β · OB-E1 α · doctrine §Part IV D-3 D-5 |
| PROM-S1-no-semantic-scoring | Grounding gates are mechanical byte-substring checks; semantic scoring is FORBIDDEN. | yes | 3 | AF-E1 β cond 1 · OB-E1 α · doctrine D-3 |
| PROM-S1-registry-native-aggregate | A Combined-scope aggregate = Registry-exposed native (the Registry computes; the brief/answer quotes byte-verbatim); synthesis-time computation is FORBIDDEN. | yes | 2 | OB-E3 α · doctrine §Part VII |
| PROM-S1-class-honesty-render-time | Class-honesty is enforced at render time — no render path strips the advisory marker; no governed-response import path touches advisory content; namespace boundaries surfaced via distinct id prefixes. | yes | 4 | OB-E2 α × 3 seams · AS-G6 · TF-G9 · FR-G4 · AF-G6b |
```

### `/app/docs/registry/function_promise_registry_v0.md:71-83`

```
| PROM-registry-taxonomy-canonical | Every function belongs to SyniSense · Northena · Mtafiti · Targeta · Solva OR a named surface; no new top-level categories without Owner ruling. | no | 6 | doctrine §3.1 |
| PROM-registry-schema-conformance | Every function row populates all 11 §3.2 schema fields; `unknown` is legal only for `cost` (and per RP-E4 α for `ladder_rung` where source silent). | no | 1 | doctrine §3.2 R1 · RP-E4 α |
| PROM-registry-service-trace-integrity | Every promise cites at least one S1..S5 sentence + journey step; empty/invalid trace = D1 orphan finding. | no | 1 | doctrine R2 · RP-G4 |
| PROM-registry-rent-paying | The Registry itself is subject to §3.4 queries (Q1/Q2/Q3); if it stops retiring gates, finding gaps, or cheapening sequences over sustained time it is itself retired or restructured. | no | 1 | doctrine §3.6 · doctrine D-8 |
| PROM-fixture-refresh-source-of-truth | Multiple sources of truth for the same fact create disclosure fragmentation; the fixture is the seed for many downstream test-consumers — centralized source of truth is mandatory. | internal | 2 | FR-E2 · doctrine §Part IV D-8 |
| PROM-tf-transform-form-per-call-provisioning | Transform Forms per-call provisioning drives per-call scope enforcement + slice-freeze but is NOT an external wire contract on the query surface. | internal | 1 | TF-E3 |
| PROM-tf-class-with-claim-invariant | Class widening in disclosure-types is accommodated by additive versioned registry (`disclosure_types.v0.json` pattern); Literal freeze on class would force contract mutations. | yes | 1 | TF-E5 · Phase 8 Stage B-5b |
| PROM-9-2a-real-worker-provenance | A real ASR/diarization worker without pinned model provenance is a fabricated-claim risk; downstream telemetry attributes work to models; unlabeled attribution is fabricated. | yes | 2 | 9.2a-E1 α · doctrine D-3 |
| PROM-9-2a-mode-selection-evident | Perception mode selection (real vs mock, CPU vs GPU) is evident at read-time; a GPU-only code path leaking into CPU-mode CI would silently expose paths that aren't proven green. | yes | 1 | 9.2a-E2 α |
| PROM-9-2a-first-contact-reverification | The 9.2a first-contact rider closes an intentional first-contact re-verification loop; its semantics must be evident to reviewers. | internal | 1 | 9.2a-E3 α |
| PROM-9-2a-never-rule-v1-d1-raw-never-egresses | A real worker holding a long-lived reference to audio bytes IS the never-rule violation; structural proof required; convention insufficient. | yes | 1 | 9.2a-E4 α · governance §1.1 never-rule V1-D1 |
| PROM-ph-r1-secret-externalization | No secret value in the container image or in a repo-committed `.env` at production time; vault-class binding at deploy time. | yes | 2 | PH-E1 α · BCR §3.4 annex |
| PROM-ph-r1-fe-be-serve-separable | Frontend build is separable from backend serve at deploy time; multi-stage single image; deploy topology chooses how to serve. | yes | 1 | PH-E2 α · BCR §3.4 |
```

### `/app/docs/registry/function_promise_registry_v0.md:134-138`

```
| mtafiti.perception.mode_selection_evident_at_read | Mtafiti | Built to make perception mode (real vs mock, CPU vs GPU) evident at read-time; no silent GPU-code-path in CPU-mode CI. | PROM-9-2a-mode-selection-evident | S2.integrate-sources · S3.prove | `backend/services/mtafiti/execution_mode_telemetry.py` + read-time metadata | Contract field required (execution_mode) | 9.2a-E2 α cells · §6.1 | 1 · Deterministic | Owner |
| mtafiti.perception.first_contact_reverification | Mtafiti | Built to close the intentional first-contact re-verification loop with semantics evident to reviewers. | PROM-9-2a-first-contact-reverification | S2.integrate-sources | `backend/services/mtafiti/first_contact_reverification.py` | Runtime check + comment carrier | 9.2a-E3 α cells · unknown | 1 · Deterministic | Owner |
| mtafiti.perception.raw_bytes_no_long_lived_ref | Mtafiti | Built to structurally prove no long-lived reference to raw audio bytes exists (never-rule V1-D1); module-level cache / class attribute / closure capture all forbidden. | PROM-9-2a-never-rule-v1-d1-raw-never-egresses | S2.integrate-sources · S3.prove | `backend/services/mtafiti/**` + AST/reflection walk | AST/reflection walk (byte-reference scan) | 9.2a-E4 α cells · §6.10 · unknown | 1 · Deterministic | Owner |
| mtafiti.extraction_console.slice_scoped_intel | Mtafiti | Built to render extraction-console surfaces (`/extraction/console`) with slice-scoped intelligence and Registry-vocabulary aggregation. | PROM-S2-slice-freeze-at-commission | S2.commission · S2.integrate-sources | `frontend/src/pages/extraction/ExtractionConsoleHomePage.jsx` | Jest render + auth-gate | SM-E1..SM-E3 · Phase 9.3 close · Jest cells · unknown | 1 · Deterministic (render) | Owner |
| mtafiti.extraction_console.registry_admin | Mtafiti | Built to expose Registry admin surface (`/extraction/registry-admin`) for named-vocabulary maintenance by Compliance. | PROM-S2-census-dimension-integrity | S2.commission · S3.prove | `frontend/src/pages/extraction/RegistryAdminView.jsx` | Jest render + auth-gate | SM-Registry-Admin cells · unknown | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:186-190`

```
| governance.tiered_ruling_model | (named surface: governance) | Built to enforce 3-tier ruling model (§§1-13); every Stage A pre-tiers escalations; §12 close-ratification-on-own-text; §13 Registry Doctrine in force. | PROM-S3-governance-doc-on-disk | S3.prove | `/app/docs/governance/tiered_ruling_model.md` | On-disk canonical + append-only amendments | Every close · unknown | 1 · Deterministic | Owner |
| governance.standing_rule_v3 | (named surface: governance) | Built to enforce all deliverables land on-disk (no inline dumps); historical carriers immutable; SHAs in reply body. | PROM-S3-governance-doc-on-disk | S3.prove | Every reply-body SHA + every landed file | Standing convention + reply-body SHA discipline | Every reply · unknown | 1 · Deterministic | Owner |
| governance.registry_doctrine_v1 | (named surface: governance §13) | Built to enforce doctrine v1.0 (S1..S5 · R1..R4 · D-1..D-10 · D1..D7). | PROM-S3-governance-doc-on-disk · PROM-registry-rent-paying | S3.prove | `/app/docs/governance/registry_doctrine_v1.md` | On-disk canonical + doctrine-ratification | §13 pointer · RP phase · unknown | 1 · Deterministic | Owner |

### §3.g Registry Population reflexive rows (R4 · this phase's own gates)
```

### `/app/docs/registry/function_promise_registry_v0.md:304-306`

```
═══════════════════════════════════════════════════════════════════

*End of Function & Promise Registry v0. Archaeology posture (doctrine §3.5) applied — 47 promises + 66 functions + 5 Q2 + 6 Q3 all extracted from on-disk record; nothing invented. RP-E1 α + tie-break-toward-distinct applied at §2. RP-E2 α applied at §4 + §5 + §7. RP-E3 α-amended applied at §5 (Q3-02 + Q3-06 · mandate-named-but-untestable landed as Q3 gap, never dropped). RP-E4 α applied throughout (unknown honest values retained). RP-E5 α applied at §3 close reporting. R4 reflexive: this phase's own gates registered at §3.g. **All 11 findings RULED 2026-07-11 per Owner** (rulings/registry_findings_01_to_11.md): Q2-01 corrected (new `PROM-S1-external-scoped-access` + strike tentative `PROM-S1-provable-envelope-inheritance` on `ui.engineer.onboarding`); Q2-02/Q2-03 accepted; Q2-04 attached-not-retired (`PROM-S1-frozen-wire-contract`); Q2-05 HOLD (no bulk disposition); Q3-01 reclassified (narrowed platform-side scope); Q3-02 open-by-design [OWNER: future phase]; Q3-03 stays-in-L0 [OWNER: buyer-commercial-tier]; Q3-04 confirmed-by-design (closed); Q3-05 recorded (candidate + sub-coverage indirect); Q3-06 recorded (candidate + half-surface tested). No code dispatched. Defect D7 respected. Parity 31/31 preserved. Standing Rule v3 · on-disk canonical.*
```


## T8 — Operating Values §1/§10 references to Shield (from operating_values_v1.md)

### `/app/docs/requirements/operating_values_v1.md:7-22`

```
*Every value below carries an evidence class per the Solva discipline — the assertion never exceeds its evidence: ***FACT ***(verifiable, cite freely) · ***NORM ***(literature/convention-anchored placement within a defensible range) · ***DEFAULT ***(operating constant, cheap to correct, revisable via dual-control config swap without reopening this document). Values revise only by Owner ruling except where marked DEFAULT. This document defines values and decisions; it mints no gates — enforcement belongs to the phases that consume each value.*

## **§1 — Model & tooling decisions (locked)**

| **Component** | **Decision** | **License** | **Rung** | **Role** | **Notes / fallback** |
| --- | --- | --- | --- | --- | --- |
| ASR · production base | whisper-large-v3 | MIT · FACT | 3 | Production extraction base; built-in LID serves language routing (no separate LID model) | Registry-pinned at deployment; CI tier stays whisper-tiny per 9.2a-E1 |
| ASR · adaptation | LoRA adapters via HF transformers + peft | Apache-2.0 · FACT | 3 | Per-stratum fine-tunes (Swahili, code-switch, accent, degraded audio) trained in-perimeter | Adapters, not full fine-tunes: 10–100× cheaper, per-stratum swappable, version additively in the model registry |
| ASR · benchmark-only | Meta MMS | CC-BY-NC · FACT | — | Rung-1 comparison baseline ONLY | NEVER production or fine-tune lineage — non-commercial license. See §10 amendment |
| Diarization | pyannote speaker-diarization | Open-weights · verify commercial terms at acquisition · FLAG | 3 | Production speaker attribution | If current license text fails commercial use: fall back to NeMo-class (Apache-2.0) |
| VAD | Silero VAD (as integrated) | MIT · FACT | 3 | Voice activity detection | No churn — integrated and sufficient |
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```

### `/app/docs/requirements/operating_values_v1.md:26-32`

```
A model is eligible for the production registry iff all four hold — **FACT-class criteria, mechanical to check:**

- **C1 · License: **permits commercial use and derivative fine-tunes (Apache-2.0 / MIT / CC-BY class).

- **C2 · Coverage: **handles the target stratum’s language natively or via a licensed fine-tune path.

- **C3 · Envelope: **single-GPU inference ≤40GB VRAM on the deployment class.
```

### `/app/docs/requirements/operating_values_v1.md:42-46`

```
| **Stratum** | **Working threshold** | **Lever on miss** |
| --- | --- | --- |
| Clean / studio speech | WER ≤ 15% | Adapter fine-tune on census-curated stratum corpus |
| Degraded / telephone / AM archival | WER ≤ 25% | Augmentation in training loop + era-stratified corpus |
| Code-switched segments (Sheng, SW–EN) | WER ≤ 30% | Code-switch adapter on census-curated CS corpus |
```

### `/app/docs/requirements/operating_values_v1.md:105-115`

```
- **LLM swap (PH-R4): **target shape per llm_swap_seam.md · cutover proven by the AF golden set: mechanical arm byte-identical, fluent arm re-validated through the grounding gates · zero call-site changes per BCR.

## **§10 — Amendment note: Registry Doctrine Part VII**

**The Part VII “existing art” column’s reading of Meta MMS is narrowed by §1 of this document: **MMS = rung-1 benchmark baseline only (CC-BY-NC); production and fine-tune lineage carry on whisper-large-v3 (MIT) and Apache-class checkpoints. The doctrine file remains byte-identical per Standing Rule v3; this note is the live reading.

## **§11 — Change discipline**

FACT rows revise only if the underlying fact changes (e.g., a license re-issue). NORM rows revise by Owner ruling with the new anchor stated. DEFAULT rows revise via the dual-control config-swap path without reopening this document; each swap ledgered. This document is consumed by: the de-risking sequence (§2–§4), 9.2b deployment (§1, §9), future S2.onboard and S4 phases (§7–§8), and BM-C operations (§5).

Syni.ai · Operating Values v1.0 · 2026-07-11 · Companion to: Registry Doctrine v1.0 · Extraction De-Risking Spec v1 · BCR v1.5
```

### `/app/docs/requirements/operating_values_v1.md:119-123`

```
Paragraph P0 (banner, bold) -> `#` H1
Paragraph P1 (title, bold)  -> `##` H2
Paragraph "Heading 1"       -> `##` H2  (used for §1..§11)
Paragraph "List Paragraph"  -> `- ` unordered list item
Paragraph style None        -> plain paragraph
```
