# Verbatim excerpts by topic (T1..T12)

Mechanical `sed -n '<s>,<e>p'` outputs, ±2 line context per anchor, merged. Zero editorial prose between blocks.


## T1 — Shield role & positioning (per doctrine)

### `/app/docs/governance/registry_doctrine_v1.md:107-111`

```
| 2 · Classical NLP (spaCy-class) | Tokenization, NER, sentence segmentation, language ID, rule-based tagging — anywhere linguistic structure is needed without open reasoning. | CPU-cheap, deterministic-enough, offline-capable. |
| 3 · Small owned models | Estate-fine-tuned perception and domain models (ASR, diarization, classifiers) from the transformation layer; registry-pinned. | Owned IP, near-free inference in-perimeter; the flywheel migrates work down to this rung continuously. |
| 4 · Frontier LLM | Open synthesis only: fluent composition, brief narrative — always behind the Shield, always with a lower-rung fallback arm. | Highest unit cost; every use answers "why not rung 3?" at Stage A. |

The deflation law: the transformation layer is the cost answer to itself. Every training cycle on the estate produces owned models that migrate rung-4 and rung-2 work to rung 3, and rung-3 findings that harden into rung-1 checks. The flywheel that improves quality is the same flywheel that deflates unit cost — by design, not by hope.
```

### `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:28-32`

```
## 1.5 How it should be HOUSED
Four environments: RMS estate (raw AV, CMS, social — raw lives here always), GPU zone (processing layer 1, perception), control plane (processing layer 2 + governance core + the record), consumer edge (apps, buyers, public receipts). Placement follows data gravity: V1 sits with the archive; the core and the record sit together and never separate; delivered artifacts sit with the core; raw never moves.
HS1 Custody.  Transform keys and Ledger-write capability exist only in the control plane. LLM access exists only behind the Shield boundary in the control plane. The only worker-side secret is a service credential unlocking the job seam and nothing else.
HS2 Never-rules (hold in every topology).  Raw AV NEVER reaches the consumer edge. The transform key NEVER enters the GPU zone. Workers NEVER write the Ledger. [STAKED — asserted from the design's own logic; strike if wrong]
HS3 Production rule.  The data plane (database + artifact store) MUST be production-grade before the first real hour is mined — at that moment the database contents become the product plus its audit record. Demo deployment of the application may happen any time.
```

### `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:234-238`

```
## 3.8 Answer fluency — V2 quality completion
FL-R1  LLM synthesis of answer_text lands behind the same frozen ComposedConclusion envelope — no wire change, no new contract. Binding constraint: every sentence MUST be derived from the load-bearing units; invented connective claims are fabrication on a governed wire and fail the gate.
FL-R2  Synthesis runs behind the Shield boundary; LLM unavailability surfaces as infrastructure fault (503), never as refusal and never as silent degrade to the mechanical composition without marking. The current mechanical composition remains the honest fallback and the regression baseline; its derivation gates are replaced only by equivalent gates over the synthesized text at landing.
## 3.9 Dual-actor engineer surface — internal and external engineers
Per UI Specification v2 Section 5.4. The owner architecture states internal and external explicitly, and the enforcement primitives already exist: key class internal|external at registration, path grants, scope enforced server-side per call, grant events ledgered. What was open — the external party's own view — closes as role-scoping on the three existing Engineer screens, replacing the former partner-portal open item. No new surface is built.
```

### `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:294-298`

```
## 3.15 Recommendation module — Opportunity Briefs (UI Spec v2.2 §3.7)

OB-R1 — A recommendation service consuming the Registry read API and producing opportunity briefs: census-slice selection, product-shape proposal with real-world precedent, gap statement. LLM generation behind the Shield, standard routing. Salvage input: reasoning patterns lifted from Akki-Executive-Core (github.com/bramuel-syni/Akki-Executive-Core) as reference logic — lifted, not imported; no runtime dependency on any Akki system.

OB-R2 — Grounding integrity: every quantitative value in a brief is a Registry read passed through verbatim. The generation layer receives facts as structured input and may not emit numbers absent from that input. Tier-1 — the no-fabricated-values promise applied to advisory output.
```


## T2 — Shield-mediated model invocation (Sonnet 4.6 via Shield, rung classification)

### `/app/docs/registry/function_promise_registry_v0.md:98-106`

```
|---|---|---|---|---|---|---|---|---|---|---|
| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/requirements/operating_values_v1.md:18-22`

```
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```


## T3 — Fluency synthesizer (`synisense.shield.fluency_synthesizer`)

### `/app/docs/registry/function_promise_registry_v0.md:100-106`

```
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:411-415`

```
    source: v0.md
    rulings: []
  - function_id: synisense.shield.fluency_synthesizer
    governor: SyniSense
    mandate: "Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass."
```

### `/app/docs/registry/machine/registry.yaml:419-423`

```
    service_trace:
      - S1.call
    surface: "`backend/services/synisense/shield/fluency_synthesizer.py:L182`"
    enforcement: Runtime chokepoint + AST single-source (piggyback)
    cost: AF-G6a · §6.11 · 4 async cells
```

### `/app/docs/registry/machine/registry.yaml:450-454`

```
    service_trace:
      - S1.call
    surface: "`backend/services/synisense/shield/fluency_synthesizer.py` (structured output block)"
    enforcement: Runtime schema validate
    cost: AF-E1 β per-sentence structured mapping cells
```

### `/app/backend/services/synisense/shield/fluency_synthesizer.py:53-57`

```


log = logging.getLogger("synisense.shield.fluency_synthesizer")
```

### `/app/backend/services/service_1/composed_conclusion.py:90-94`

```
from services.service_1.answer_grounding import verify_grounding
from services.service_1.fluency_mode_telemetry import annotate_result
from services.synisense.shield.fluency_synthesizer import (
    EmergentKeyMissingError,
    LLMParseFailureError,
```


## T4 — Brief synthesizer (`synisense.shield.brief_synthesizer`)

### `/app/docs/registry/function_promise_registry_v0.md:101-105`

```
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:427-431`

```
    source: v0.md
    rulings: []
  - function_id: synisense.shield.brief_synthesizer
    governor: SyniSense
    mandate: "Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for(\"analytical\")` reuse of Phase 7 Stage B-2 seed."
```

### `/app/docs/registry/machine/registry.yaml:435-439`

```
    service_trace:
      - S1.call (advisory to S1's app-facing)
    surface: "`backend/services/synisense/shield/brief_synthesizer.py:L116`"
    enforcement: Runtime chokepoint
    cost: OB-G1 async cells · §6.11
```

### `/app/backend/services/synisense/shield/brief_synthesizer.py:44-48`

```


log = logging.getLogger("synisense.shield.brief_synthesizer")
```

### `/app/backend/services/opportunity_briefs/generator.py:9-13`

```
     the map today; production wiring lands post-9.2b when the
     Registry read API is populated).
  3. Call Shield brief_synthesizer for a `{brief_text,
     quantitative_anchors}` payload.
  4. Verify grounding — mechanical byte-verbatim per OB-E1 α.
```

### `/app/backend/services/opportunity_briefs/generator.py:36-40`

```
from services.opportunity_briefs.brief_grounding import verify_brief_grounding
from services.opportunity_briefs.brief_telemetry import annotate_brief_result
from services.synisense.shield import brief_synthesizer as _synth
```


## T5 — Mechanical fallback arms

### `/app/docs/registry/function_promise_registry_v0.md:50-54`

```
| PROM-S1-registry-native-aggregate | A Combined-scope aggregate = Registry-exposed native (the Registry computes; the brief/answer quotes byte-verbatim); synthesis-time computation is FORBIDDEN. | yes | 2 | OB-E3 α · doctrine §Part VII |
| PROM-S1-class-honesty-render-time | Class-honesty is enforced at render time — no render path strips the advisory marker; no governed-response import path touches advisory content; namespace boundaries surfaced via distinct id prefixes. | yes | 4 | OB-E2 α × 3 seams · AS-G6 · TF-G9 · FR-G4 · AF-G6b |
| PROM-S1-runtime-transient-never-refusal | Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope. | yes | 2 | AF-E2 amended · OB-runtime-transient-precedent |
| PROM-S1-config-defect-fail-loud | Config defects (missing Emergent key · invalid key) fail loud 503 at startup; NEVER routed via refusal envelope. | yes | 1 | AF-E2 amended |
| PROM-S2-estate-onboarded-and-mapped | The Operator's estate is onboarded, mapped, and turned into qualified intelligence they can commit with confidence. | yes | 1 | doctrine §Part II S2 · BCR v1.5 §3.4 (housing) |
```

### `/app/docs/registry/function_promise_registry_v0.md:100-105`

```
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:109-113`

```
| synisense.shield.fluency_mode_telemetry_sidecar | SyniSense | Built to emit fluency-mode telemetry via sidecar; envelope byte-identical; parity preserved. | PROM-S1-frozen-wire-contract · PROM-S1-runtime-transient-never-refusal | S3.prove | `backend/services/service_1/fluency_mode_telemetry.py` | Contract-shape lint | AF-G-Sidecar cells · §6.1 · 4 cells | 1 · Deterministic | Owner |
| synisense.shield.brief_telemetry_sidecar | SyniSense | Built to emit brief-generation telemetry via sidecar following AF-E3 α precedent; envelope byte-identical. | PROM-S1-frozen-wire-contract | S3.prove | `backend/services/opportunity_briefs/brief_telemetry.py` | Contract-shape lint | OB-G-Telemetry · §6.1 · 1 cell | 1 · Deterministic | builder-Tier-3 |
| synisense.shield.mechanical_composer_baseline | SyniSense | Built to preserve the pre-fluency f-string mechanical composer byte-identically to goldens for regression-check. | PROM-S1-frozen-wire-contract | S1.call | `backend/services/service_1/mechanical_composer.py` + `backend/tests/goldens/answer_fluency/pre_3_8/mechanical_baseline.json` | Byte-identity lock (SHA-pin) | AF-G1 · 5 legacy SHA-pin gates repointed · §6.6 | 1 · Deterministic | Owner |
| synisense.shield.brief_id_namespace_boundary | SyniSense | Built to mint brief IDs in a distinct `brief_` namespace; `/api/solva/trace/{brief_*}` returns 404. | PROM-S3-brief-namespace-distinct-from-trace | S3.prove | `backend/services/opportunity_briefs/brief_registry.new_brief_id` + `backend/routers/solva.py:get_trace` | Runtime 404 + namespace grep | OB-G3 · OB-G3-Seam2-Namespace-Distinct · §6.11 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.refusal_taxonomy_closed | SyniSense | Built to enforce the 4-code auth-refusal registry; runtime transients and infra 503s never routed via refusal envelope. | PROM-S1-refusal-taxonomy-closed | S1.call · S3.prove | `backend/services/auth/refusal_envelope.py` + AST negative on health.py | Type-level wall + AST scan | AF-G-Never-Refusal-Envelope · OB-G-Runtime-Transient-Never-Refusal-Envelope · PH-G-Refusal-Closed · §6.10 · 3 cells | 1 · Deterministic | Owner |
```

### `/app/docs/registry/machine/registry.yaml:111-115`

```
      - AF-G6b
  - promise_id: PROM-S1-runtime-transient-never-refusal
    text: Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope.
    active: true
    functions_that_cite: 2
```

### `/app/docs/registry/machine/registry.yaml:423-427`

```
    cost: AF-G6a · §6.11 · 4 async cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (with mechanical fallback per AF-E2 amended)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:439-443`

```
    cost: OB-G1 async cells · §6.11
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:551-555`

```
    source: v0.md
    rulings: []
  - function_id: synisense.shield.mechanical_composer_baseline
    governor: SyniSense
    mandate: Built to preserve the pre-fluency f-string mechanical composer byte-identically to goldens for regression-check.
```

### `/app/docs/registry/machine/registry.yaml:558-562`

```
    service_trace:
      - S1.call
    surface: "`backend/services/service_1/mechanical_composer.py` + `backend/tests/goldens/answer_fluency/pre_3_8/mechanical_baseline.json`"
    enforcement: Byte-identity lock (SHA-pin)
    cost: AF-G1 · 5 legacy SHA-pin gates repointed · §6.6
```

### `/app/docs/requirements/operating_values_v1.md:18-22`

```
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```


## T6 — Cost classification & rung-4 accounting

### `/app/docs/registry/function_promise_registry_v0.md:70-74`

```
| PROM-S5-substrate-not-optimized-against | Akki's extraction and governance capacity as a substrate for future ventures; no platform function may cite S5 as sole anchor without Owner ruling. | no (internal / future) | 0 (registered, unbuilt) | doctrine §Part II S5 |
| PROM-registry-taxonomy-canonical | Every function belongs to SyniSense · Northena · Mtafiti · Targeta · Solva OR a named surface; no new top-level categories without Owner ruling. | no | 6 | doctrine §3.1 |
| PROM-registry-schema-conformance | Every function row populates all 11 §3.2 schema fields; `unknown` is legal only for `cost` (and per RP-E4 α for `ladder_rung` where source silent). | no | 1 | doctrine §3.2 R1 · RP-E4 α |
| PROM-registry-service-trace-integrity | Every promise cites at least one S1..S5 sentence + journey step; empty/invalid trace = D1 orphan finding. | no | 1 | doctrine R2 · RP-G4 |
| PROM-registry-rent-paying | The Registry itself is subject to §3.4 queries (Q1/Q2/Q3); if it stops retiring gates, finding gaps, or cheapening sequences over sustained time it is itself retired or restructured. | no | 1 | doctrine §3.6 · doctrine D-8 |
```

### `/app/docs/registry/function_promise_registry_v0.md:98-106`

```
|---|---|---|---|---|---|---|---|---|---|---|
| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:196-200`

```
| registry.population.g1_promise_set_completeness | (named surface: Registry) | Attest every "Promise protected" source line resolves to a §2 promise-row OR §4 Q2 orphan. | PROM-registry-service-trace-integrity | S3.prove | This file §2 + §4 | grep-negative (source-line vs promise-row citation) | RP-G1 · §6.1 · unknown | 1 · Deterministic | Owner |
| registry.population.g2_function_attachment_completeness | (named surface: Registry) | Attest every named-gate identifier in CI roster has a function row OR appears in §4 Q2. | PROM-registry-service-trace-integrity | S3.prove · S1.call | This file §3 + §4 | grep-negative | RP-G2 · unknown | 1 · Deterministic | Owner |
| registry.population.g3_schema_conformance | (named surface: Registry) | Attest every §3 row populates all 11 §3.2 fields; `unknown` legal only for `cost` + `ladder_rung` (per RP-E4 α). | PROM-registry-schema-conformance | S3.prove | This file §3 | table-shape lint | RP-G3 · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.g4_service_trace_integrity | (named surface: Registry) | Attest every `service_trace` cites S1..S5 + journey step from doctrine Part II verbatim. | PROM-registry-service-trace-integrity | S1..S5 · S3.prove | This file §3 | reference-check | RP-G4 · unknown | 1 · Deterministic | Owner |
| registry.population.g5_q2_orphan_coverage | (named surface: Registry) | Attest every unrecoverable-promise gate appears in §4 Q2 list. | PROM-registry-rent-paying | S3.prove | This file §4 | inclusion-check | RP-G5 · unknown | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:203-207`

```
| registry.population.q2_q3_client_promise_escalation | (named surface: Registry) | Per RP-E2 α: route every client-promise-touching Q2/Q3 finding to `[CLIENT-PROMISE · ESCALATE-AT-CLOSE]` marker in §4/§5 + surface at close. | PROM-registry-rent-paying · PROM-S1-provable-envelope-inheritance | S1.call · S3.prove · S4.receive | This file §4 + §5 + §7 | grep-negative on client-promise class keywords | RP-E2 α · unknown | 1 · Deterministic | Owner |
| registry.population.governor_scope_boundary_ruling | (named surface: Registry) | Per RP-E3 α-amended: (i)∧(ii) → §3 row; (i)∧¬(ii) → §5 Q3 gap finding, never dropped; sub-steps fold into parent's mandate. | PROM-registry-taxonomy-canonical | S2.commission · S3.prove | This file §3 + §5 | grep-positive on §-clause citations | RP-E3 α-amended · unknown | 1 · Deterministic (mandate-clause match) | Owner |
| registry.population.ladder_rung_unknown_honesty | (named surface: Registry) | Per RP-E4 α: `ladder_rung: unknown` is the honest value where source is silent; NO builder-guessed rungs. | PROM-S1-honesty-grammar-source-labels · PROM-registry-schema-conformance | S3.prove | This file §3 | grep-positive on `unknown` where evidence absent | RP-E4 α · unknown | 1 · Deterministic | Owner |
| registry.population.gaux_parity_31_preserved | (named surface: Registry · SyniSense) | Attest 31 frozen contracts + 31 snapshots byte-identical at Registry Population close. | PROM-S1-frozen-wire-contract | S1.call · S3.prove | `backend/contracts/**` + `*.contract_snapshot.json` | fs-count (shared parity_counter) | RP-G-Parity · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.gaux_data_blind | (named surface: Registry) | Attest zero secret values in the Registry deliverable (grep-negative on MongoDB URI · JWT · sk-* · AKIA*). | PROM-S1-honesty-grammar-source-labels · governance §8 | S3.prove | This file (whole) | grep-negative on secret patterns | RP-G-DataBlind · §6.1 | 1 · Deterministic | builder-Tier-3 |
```

### `/app/docs/registry/machine/registry.yaml:391-395`

```
    cost: 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class
    dependencies: AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring
    ladder_rung: 1 · Deterministic + rung-4 upstream synthesis
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:407-411`

```
    cost: OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11
    dependencies: ""
    ladder_rung: 1 · Deterministic + rung-4 upstream
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:423-427`

```
    cost: AF-G6a · §6.11 · 4 async cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (with mechanical fallback per AF-E2 amended)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:439-443`

```
    cost: OB-G1 async cells · §6.11
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:454-458`

```
    cost: AF-E1 β per-sentence structured mapping cells
    dependencies: ""
    ladder_rung: 4 · Frontier LLM (structured output)
    owner: Owner
    source: v0.md
```

### `/app/docs/registry/machine/registry.yaml:1421-1425`

```
  - function_id: registry.population.g3_schema_conformance
    governor: "(named surface: Registry)"
    mandate: "Attest every §3 row populates all 11 §3.2 fields; `unknown` legal only for `cost` + `ladder_rung` (per RP-E4 α)."
    promise:
      - PROM-registry-schema-conformance
```

### `/app/docs/governance/registry_doctrine_v1.md:107-117`

```
| 2 · Classical NLP (spaCy-class) | Tokenization, NER, sentence segmentation, language ID, rule-based tagging — anywhere linguistic structure is needed without open reasoning. | CPU-cheap, deterministic-enough, offline-capable. |
| 3 · Small owned models | Estate-fine-tuned perception and domain models (ASR, diarization, classifiers) from the transformation layer; registry-pinned. | Owned IP, near-free inference in-perimeter; the flywheel migrates work down to this rung continuously. |
| 4 · Frontier LLM | Open synthesis only: fluent composition, brief narrative — always behind the Shield, always with a lower-rung fallback arm. | Highest unit cost; every use answers "why not rung 3?" at Stage A. |

The deflation law: the transformation layer is the cost answer to itself. Every training cycle on the estate produces owned models that migrate rung-4 and rung-2 work to rung 3, and rung-3 findings that harden into rung-1 checks. The flywheel that improves quality is the same flywheel that deflates unit cost — by design, not by hope.

## §5.2 The sequencing harness

Specification (enters as code only on Owner dispatch): a harness that executes registered functions against fixture traffic in candidate orderings and measures real cost — not simulated approximations. Principle: this system is predominantly deterministic; you do not simulate a deterministic gate, you run it. Orderings are optimized over the Registry's cost and dependency fields: cheap gates before expensive, deterministic rungs before model rungs, independent functions in parallel, fail-fast paths surfaced. Honest boundary, stated as a spec constraint: rung-3/rung-4 behavior is measured statistically (repeated runs over the harness, route-level comparisons), never claimed as exact. Output: the measured best path of integration and sequencing per journey — replacing sequencing judgment with sequencing measurement, and back-filling every "unknown" cost field in the Registry.

# Part VI — The culture layer
```


## T7 — Behavioural bindings (D-* defect classes touching Shield)

### `/app/docs/governance/registry_doctrine_v1.md:85-98`

```
These bind every actor in the build — Owner's ruling authority, builder, and any agent or model worker — immediately on ratification, with no code change required:

- D-1 · Reasoning order. Service → journey → promise → function, in every scoping, escalation, and ruling. Escalations name the promise protected and its service trace (the existing "Promise protected" discipline, now with the trace made explicit).
- D-2 · Rules pay rent. Every gate carries its promise and its cost. A gate that protects no live promise is retired, not preserved out of caution. Caution that costs forever must justify itself forever.
- D-3 · The conflation test. Before any function is proposed: which Layer 0 sentence does this serve? No sentence, no build. This is the structural prevention of "doing the wrong job well."
- D-4 · Cheapest-sufficient rung. Every task lands on the lowest model-ladder rung that meets its promise (§5.1). Rung inflation requires written justification at Stage A.
- D-5 · NL is interface, never enforcement. Every natural-language rule pairs with a machine-enforced twin. NL-only enforcement is defect D2, reportable on sight.
- D-6 · Constraint architecture first. Prefer designs where correct behavior is the path of least resistance; gates are the backstop, not the mechanism. Every promise the architecture absorbs is a gate never written (§6.1).
- D-7 · Verdicts are never curated. Inputs, models, corpora, and discovery paths may be engineered without limit; validation verdicts are drawn from measured composition, uncurated, and published internally whatever they say (Part VII).
- D-8 · Reduction applies to its own output. Specs, trackers, and meta-artifacts are retired when they stop earning. The dead-tracker sweep is a standing pattern, not an event.
- D-9 · Platform serves applications. No platform decision optimizes end-user UX directly; end-user experience is application territory (Part II).
- D-10 · Builder conduct standard. Meticulousness is enforced by structure, not assumed: every proposal self-audits against defect classes D1–D7 before submission, and a proposal arriving with a defect the self-audit would have caught is itself a reportable finding.

# Part V — Cost architecture
```

### `/app/docs/governance/registry_doctrine_v1.md:129-133`

```
# Part VII — Extraction quality: the de-risking specification

Premise, Owner-agreed: extraction quality on a specific estate is unmeasured until measured — but its weak surfaces are enumerable in advance, each has existing open art, and each maps to a designed lever in the platform. The gap is speccable, not fated. Governing principle, restating D-7: engineer the inputs relentlessly; never touch the test. Model choice, fine-tuning, augmentation, and corpus curation are legitimate curation of success; the validation verdict (the human-baseline benchmark, BM-V) is drawn from measured estate composition, post-census, uncurated — a rehearsed checkpoint is preparation; a curated verdict is worthless.

| Weak surface | Existing art (starting points) | Akki lever | Pre-verdict checkpoint |
```

### `/app/docs/governance/registry_doctrine_v1.md:152-156`

```
## §8.1 What is in force, what drafts, what codes

- In force on ratification (no build): Part II service layer; Part III derivation rules R1–R4 as scoping discipline; Part IV doctrine D-1–D-9; Part VII claims discipline.
- Documents (draft on Owner word, no code): Registry population (§3.5 archaeology); Instance Replication Playbook; Commercial Thesis.
- Code-level (each enters only via Stage A → Owner ruling → atomic execution → close, on explicit Owner dispatch; no schedule exists or is implied): (a) the three standing queries as executable checks over a machine-readable Registry; (b) the sequencing harness (§5.2); (c) Registry-as-context worker harnessing (§6.2); (d) the Registry's machine-readable form itself; (e) far endpoint — mandates as structured specs from which gates are generated.
```

### `/app/docs/governance/registry_doctrine_v1.md:169-173`

```
## §8.3 Ratification

This document binds on Owner ratification of: (a) the five Layer 0 service sentences verbatim or as corrected; (b) the doctrine set D-1–D-9; (c) the defect classes D1–D7. On ratification it lands on-disk as a governed artifact beside the governor mandates, and R4 takes effect for all subsequent Stage A proposals.

Syni.ai · The Registry Doctrine v1.0 · Companion to: governor mandate documents · tiered ruling model · BCR v1.5 · Extraction De-Risking Spec v1
```

### `/app/docs/registry/function_promise_registry_v0.md:45-51`

```
| PROM-S1-frozen-wire-contract | External parties consume a stable schema over time; frozen contracts are byte-identical; parity is attested at every close. | yes | 6 | V1-G7 · TF-E1 α · CD-E2 α · doctrine §Part VIII |
| PROM-S1-additive-versioning | New contracts land by additive versioning (v0 preserved byte-identical when v1 lands); parity bumps with the new snapshot; V1-G7 assertion set bumps with it. | yes | 2 | AS-E1 α · V1-G7 |
| PROM-S1-honesty-grammar-source-labels | Every value in a client-facing envelope carries its provenance source label; values not observed by the census carry a non-`census_observed` source label OR are null; NO fabricated values. | yes | 5 | CD-E1 α · 9.2a-E1 α · doctrine D-3 |
| PROM-S1-byte-verbatim-anchor-grounding | Every quantitative anchor in an LLM-synthesized advisory or answer must appear byte-verbatim in a Registry-read text; whole-envelope REJECT on any failure; gate NEVER patches prose. | yes | 3 | AF-E1 β · OB-E1 α · doctrine §Part IV D-3 D-5 |
| PROM-S1-no-semantic-scoring | Grounding gates are mechanical byte-substring checks; semantic scoring is FORBIDDEN. | yes | 3 | AF-E1 β cond 1 · OB-E1 α · doctrine D-3 |
| PROM-S1-registry-native-aggregate | A Combined-scope aggregate = Registry-exposed native (the Registry computes; the brief/answer quotes byte-verbatim); synthesis-time computation is FORBIDDEN. | yes | 2 | OB-E3 α · doctrine §Part VII |
| PROM-S1-class-honesty-render-time | Class-honesty is enforced at render time — no render path strips the advisory marker; no governed-response import path touches advisory content; namespace boundaries surfaced via distinct id prefixes. | yes | 4 | OB-E2 α × 3 seams · AS-G6 · TF-G9 · FR-G4 · AF-G6b |
```

### `/app/docs/registry/function_promise_registry_v0.md:72-80`

```
| PROM-registry-schema-conformance | Every function row populates all 11 §3.2 schema fields; `unknown` is legal only for `cost` (and per RP-E4 α for `ladder_rung` where source silent). | no | 1 | doctrine §3.2 R1 · RP-E4 α |
| PROM-registry-service-trace-integrity | Every promise cites at least one S1..S5 sentence + journey step; empty/invalid trace = D1 orphan finding. | no | 1 | doctrine R2 · RP-G4 |
| PROM-registry-rent-paying | The Registry itself is subject to §3.4 queries (Q1/Q2/Q3); if it stops retiring gates, finding gaps, or cheapening sequences over sustained time it is itself retired or restructured. | no | 1 | doctrine §3.6 · doctrine D-8 |
| PROM-fixture-refresh-source-of-truth | Multiple sources of truth for the same fact create disclosure fragmentation; the fixture is the seed for many downstream test-consumers — centralized source of truth is mandatory. | internal | 2 | FR-E2 · doctrine §Part IV D-8 |
| PROM-tf-transform-form-per-call-provisioning | Transform Forms per-call provisioning drives per-call scope enforcement + slice-freeze but is NOT an external wire contract on the query surface. | internal | 1 | TF-E3 |
| PROM-tf-class-with-claim-invariant | Class widening in disclosure-types is accommodated by additive versioned registry (`disclosure_types.v0.json` pattern); Literal freeze on class would force contract mutations. | yes | 1 | TF-E5 · Phase 8 Stage B-5b |
| PROM-9-2a-real-worker-provenance | A real ASR/diarization worker without pinned model provenance is a fabricated-claim risk; downstream telemetry attributes work to models; unlabeled attribution is fabricated. | yes | 2 | 9.2a-E1 α · doctrine D-3 |
| PROM-9-2a-mode-selection-evident | Perception mode selection (real vs mock, CPU vs GPU) is evident at read-time; a GPU-only code path leaking into CPU-mode CI would silently expose paths that aren't proven green. | yes | 1 | 9.2a-E2 α |
| PROM-9-2a-first-contact-reverification | The 9.2a first-contact rider closes an intentional first-contact re-verification loop; its semantics must be evident to reviewers. | internal | 1 | 9.2a-E3 α |
```

### `/app/docs/registry/function_promise_registry_v0.md:131-135`

```
| function_id | governor | mandate | promise | service_trace | surface | enforcement | cost | dependencies | ladder_rung | owner |
|---|---|---|---|---|---|---|---|---|---|---|
| mtafiti.perception.pinned_model_provenance | Mtafiti | Built to require every real ASR/diarization pass emit `transcript_v0` with pinned model provenance; unlabeled attribution is a fabricated claim. | PROM-9-2a-real-worker-provenance · PROM-S1-honesty-grammar-source-labels | S2.integrate-sources · S3.prove | `backend/services/mtafiti/**` real worker pass + telemetry | Contract field required (model_id + weights_sha) | 9.2a-E1 α cells · §6.11 · unknown | 3 · Owned model (real workers) OR 1 · Deterministic (fixture) | Owner |
| mtafiti.perception.mode_selection_evident_at_read | Mtafiti | Built to make perception mode (real vs mock, CPU vs GPU) evident at read-time; no silent GPU-code-path in CPU-mode CI. | PROM-9-2a-mode-selection-evident | S2.integrate-sources · S3.prove | `backend/services/mtafiti/execution_mode_telemetry.py` + read-time metadata | Contract field required (execution_mode) | 9.2a-E2 α cells · §6.1 | 1 · Deterministic | Owner |
| mtafiti.perception.first_contact_reverification | Mtafiti | Built to close the intentional first-contact re-verification loop with semantics evident to reviewers. | PROM-9-2a-first-contact-reverification | S2.integrate-sources | `backend/services/mtafiti/first_contact_reverification.py` | Runtime check + comment carrier | 9.2a-E3 α cells · unknown | 1 · Deterministic | Owner |
```

### `/app/docs/registry/function_promise_registry_v0.md:137-143`

```
| mtafiti.extraction_console.slice_scoped_intel | Mtafiti | Built to render extraction-console surfaces (`/extraction/console`) with slice-scoped intelligence and Registry-vocabulary aggregation. | PROM-S2-slice-freeze-at-commission | S2.commission · S2.integrate-sources | `frontend/src/pages/extraction/ExtractionConsoleHomePage.jsx` | Jest render + auth-gate | SM-E1..SM-E3 · Phase 9.3 close · Jest cells · unknown | 1 · Deterministic (render) | Owner |
| mtafiti.extraction_console.registry_admin | Mtafiti | Built to expose Registry admin surface (`/extraction/registry-admin`) for named-vocabulary maintenance by Compliance. | PROM-S2-census-dimension-integrity | S2.commission · S3.prove | `frontend/src/pages/extraction/RegistryAdminView.jsx` | Jest render + auth-gate | SM-Registry-Admin cells · unknown | 1 · Deterministic | Owner |
| mtafiti.census.dimension_registry_vocabulary | Mtafiti | Built to enforce that any census-observed dimension value appears in the disclosure_types/content_surface Registry; hard-coded values not in the vocabulary are honesty violations. | PROM-S2-census-dimension-integrity · PROM-S1-honesty-grammar-source-labels | S2.integrate-sources | `backend/services/census/dimension_registry.py` + sidecar | Vocabulary-set membership check | CD-G1..G4 · §6.11 · 4 cells | 1 · Deterministic | Owner |
| mtafiti.census.sidecar_record_shape | Mtafiti | Built to freeze the sidecar record shape (source label attribution) even though sidecar is INTERNAL — analogous to TF-E2 β but ruled α at TF; here ruled INTERNAL. | PROM-S2-census-dimension-integrity | S2.integrate-sources | `backend/services/census/sidecar.py` | Load-bearing wire-shape gate | CD-E2 α · §6.1 | 1 · Deterministic | Owner |
| mtafiti.census.no_fabricated_content_surface | Mtafiti | Built to prevent silent `content_surface="hard_coded_value_not_in_registry"` writes at census-run time; the registry IS the vocabulary. | PROM-S2-census-dimension-integrity · PROM-S1-honesty-grammar-source-labels | S2.integrate-sources | `backend/services/census/**` + write-time validation | Runtime schema validate | CD-E3 α · §6.11 | 1 · Deterministic | Owner |

### §3.d Targeta (commission · wizard · slice-freeze · objective shaping)
```

### `/app/docs/registry/function_promise_registry_v0.md:186-190`

```
| governance.tiered_ruling_model | (named surface: governance) | Built to enforce 3-tier ruling model (§§1-13); every Stage A pre-tiers escalations; §12 close-ratification-on-own-text; §13 Registry Doctrine in force. | PROM-S3-governance-doc-on-disk | S3.prove | `/app/docs/governance/tiered_ruling_model.md` | On-disk canonical + append-only amendments | Every close · unknown | 1 · Deterministic | Owner |
| governance.standing_rule_v3 | (named surface: governance) | Built to enforce all deliverables land on-disk (no inline dumps); historical carriers immutable; SHAs in reply body. | PROM-S3-governance-doc-on-disk | S3.prove | Every reply-body SHA + every landed file | Standing convention + reply-body SHA discipline | Every reply · unknown | 1 · Deterministic | Owner |
| governance.registry_doctrine_v1 | (named surface: governance §13) | Built to enforce doctrine v1.0 (S1..S5 · R1..R4 · D-1..D-10 · D1..D7). | PROM-S3-governance-doc-on-disk · PROM-registry-rent-paying | S3.prove | `/app/docs/governance/registry_doctrine_v1.md` | On-disk canonical + doctrine-ratification | §13 pointer · RP phase · unknown | 1 · Deterministic | Owner |

### §3.g Registry Population reflexive rows (R4 · this phase's own gates)
```

### `/app/docs/registry/function_promise_registry_v0.md:200-209`

```
| registry.population.g5_q2_orphan_coverage | (named surface: Registry) | Attest every unrecoverable-promise gate appears in §4 Q2 list. | PROM-registry-rent-paying | S3.prove | This file §4 | inclusion-check | RP-G5 · unknown | 1 · Deterministic | Owner |
| registry.population.g6_q3_gap_coverage | (named surface: Registry) | Attest every doctrine-Part-II journey step with zero registered functions appears in §5 Q3 list. Per RP-E3 α-amended: also every (i)∧¬(ii) mandate-named-but-untestable behavior. | PROM-registry-rent-paying | S3.prove · S1..S5 | This file §5 | inclusion-check | RP-G6 · unknown | 1 · Deterministic | Owner |
| registry.population.promise_consolidation_judgment | (named surface: Registry) | Per RP-E1 α + tie-break-toward-distinct: consolidate iff ≥60% core-token overlap AND same governor/surface; keep DISTINCT at borderline. | PROM-registry-rent-paying · PROM-S1-honesty-grammar-source-labels | S3.prove | This file §2 + consolidation_log_v0.md | grep-negative + inclusion-check | RP-E1 α landing · §6.11 · unknown | 1 · Deterministic (token-overlap check) | Owner |
| registry.population.q2_q3_client_promise_escalation | (named surface: Registry) | Per RP-E2 α: route every client-promise-touching Q2/Q3 finding to `[CLIENT-PROMISE · ESCALATE-AT-CLOSE]` marker in §4/§5 + surface at close. | PROM-registry-rent-paying · PROM-S1-provable-envelope-inheritance | S1.call · S3.prove · S4.receive | This file §4 + §5 + §7 | grep-negative on client-promise class keywords | RP-E2 α · unknown | 1 · Deterministic | Owner |
| registry.population.governor_scope_boundary_ruling | (named surface: Registry) | Per RP-E3 α-amended: (i)∧(ii) → §3 row; (i)∧¬(ii) → §5 Q3 gap finding, never dropped; sub-steps fold into parent's mandate. | PROM-registry-taxonomy-canonical | S2.commission · S3.prove | This file §3 + §5 | grep-positive on §-clause citations | RP-E3 α-amended · unknown | 1 · Deterministic (mandate-clause match) | Owner |
| registry.population.ladder_rung_unknown_honesty | (named surface: Registry) | Per RP-E4 α: `ladder_rung: unknown` is the honest value where source is silent; NO builder-guessed rungs. | PROM-S1-honesty-grammar-source-labels · PROM-registry-schema-conformance | S3.prove | This file §3 | grep-positive on `unknown` where evidence absent | RP-E4 α · unknown | 1 · Deterministic | Owner |
| registry.population.gaux_parity_31_preserved | (named surface: Registry · SyniSense) | Attest 31 frozen contracts + 31 snapshots byte-identical at Registry Population close. | PROM-S1-frozen-wire-contract | S1.call · S3.prove | `backend/contracts/**` + `*.contract_snapshot.json` | fs-count (shared parity_counter) | RP-G-Parity · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.gaux_data_blind | (named surface: Registry) | Attest zero secret values in the Registry deliverable (grep-negative on MongoDB URI · JWT · sk-* · AKIA*). | PROM-S1-honesty-grammar-source-labels · governance §8 | S3.prove | This file (whole) | grep-negative on secret patterns | RP-G-DataBlind · §6.1 | 1 · Deterministic | builder-Tier-3 |
| registry.population.gaux_docs_on_disk | (named surface: Registry · Standing Rule v3) | Attest deliverable + rulings + close + consolidation-log all land on Standing Rule v3 canonical paths. | PROM-S3-governance-doc-on-disk | S3.prove | 4 canonical paths under `docs/` | file-existence | RP-G-Docs · §6.1 · 4 cells | 1 · Deterministic | builder-Tier-3 |
| registry.population.gaux_doctrine_ref | (named surface: Registry) | Attest this file §1 cites the doctrine SHA verbatim. | PROM-S3-governance-doc-on-disk | S3.prove | This file §1 | grep-positive on doctrine SHA `0bfe65c4…` | RP-G-DoctrineRef · §6.1 | 1 · Deterministic | builder-Tier-3 |
```


## T8 — Operating Values §1/§10 references to Shield

### `/app/docs/requirements/operating_values_v1.md:7-22`

```
*Every value below carries an evidence class per the Solva discipline — the assertion never exceeds its evidence: ***FACT ***(verifiable, cite freely) · ***NORM ***(literature/convention-anchored placement within a defensible range) · ***DEFAULT ***(operating constant, cheap to correct, revisable via dual-control config swap without reopening this document). Values revise only by Owner ruling except where marked DEFAULT. This document defines values and decisions; it mints no gates — enforcement belongs to the phases that consume each value.*

## **§1 — Model & tooling decisions (locked)**

| **Component** | **Decision** | **License** | **Rung** | **Role** | **Notes / fallback** |
| --- | --- | --- | --- | --- | --- |
| ASR · production base | whisper-large-v3 | MIT · FACT | 3 | Production extraction base; built-in LID serves language routing (no separate LID model) | Registry-pinned at deployment; CI tier stays whisper-tiny per 9.2a-E1 |
| ASR · adaptation | LoRA adapters via HF transformers + peft | Apache-2.0 · FACT | 3 | Per-stratum fine-tunes (Swahili, code-switch, accent, degraded audio) trained in-perimeter | Adapters, not full fine-tunes: 10–100× cheaper, per-stratum swappable, version additively in the model registry |
| ASR · benchmark-only | Meta MMS | CC-BY-NC · FACT | — | Rung-1 comparison baseline ONLY | NEVER production or fine-tune lineage — non-commercial license. See §10 amendment |
| Diarization | pyannote speaker-diarization | Open-weights · verify commercial terms at acquisition · FLAG | 3 | Production speaker attribution | If current license text fails commercial use: fall back to NeMo-class (Apache-2.0) |
| VAD | Silero VAD (as integrated) | MIT · FACT | 3 | Voice activity detection | No churn — integrated and sufficient |
| Inference runtime | faster-whisper (CTranslate2) | MIT · FACT | — | Serving layer; large-v3 in CT2 format within ≤40GB envelope with batch headroom | Already the integrated backend |
| Embeddings / entity resolution | multilingual-e5-class | MIT · FACT | 3 | Default for Mtafiti entity/similarity surfaces when that phase dispatches | Named now so no future Stage A reopens the category |
| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |

**Open by measurement, deliberately (the one non-decision): **which adapter strata are needed at all — rung-1 domain-transfer measurement determines whether bare large-v3 already clears §3 thresholds on some strata. Deciding this by fiat would be fabricating a measurement.
```

### `/app/docs/requirements/operating_values_v1.md:26-32`

```
A model is eligible for the production registry iff all four hold — **FACT-class criteria, mechanical to check:**

- **C1 · License: **permits commercial use and derivative fine-tunes (Apache-2.0 / MIT / CC-BY class).

- **C2 · Coverage: **handles the target stratum’s language natively or via a licensed fine-tune path.

- **C3 · Envelope: **single-GPU inference ≤40GB VRAM on the deployment class.
```

### `/app/docs/requirements/operating_values_v1.md:42-46`

```
| **Stratum** | **Working threshold** | **Lever on miss** |
| --- | --- | --- |
| Clean / studio speech | WER ≤ 15% | Adapter fine-tune on census-curated stratum corpus |
| Degraded / telephone / AM archival | WER ≤ 25% | Augmentation in training loop + era-stratified corpus |
| Code-switched segments (Sheng, SW–EN) | WER ≤ 30% | Code-switch adapter on census-curated CS corpus |
```

### `/app/docs/requirements/operating_values_v1.md:105-115`

```
- **LLM swap (PH-R4): **target shape per llm_swap_seam.md · cutover proven by the AF golden set: mechanical arm byte-identical, fluent arm re-validated through the grounding gates · zero call-site changes per BCR.

## **§10 — Amendment note: Registry Doctrine Part VII**

**The Part VII “existing art” column’s reading of Meta MMS is narrowed by §1 of this document: **MMS = rung-1 benchmark baseline only (CC-BY-NC); production and fine-tune lineage carry on whisper-large-v3 (MIT) and Apache-class checkpoints. The doctrine file remains byte-identical per Standing Rule v3; this note is the live reading.

## **§11 — Change discipline**

FACT rows revise only if the underlying fact changes (e.g., a license re-issue). NORM rows revise by Owner ruling with the new anchor stated. DEFAULT rows revise via the dual-control config-swap path without reopening this document; each swap ledgered. This document is consumed by: the de-risking sequence (§2–§4), 9.2b deployment (§1, §9), future S2.onboard and S4 phases (§7–§8), and BM-C operations (§5).

Syni.ai · Operating Values v1.0 · 2026-07-11 · Companion to: Registry Doctrine v1.0 · Extraction De-Risking Spec v1 · BCR v1.5
```

### `/app/docs/requirements/operating_values_v1.md:119-123`

```
Paragraph P0 (banner, bold) -> `#` H1
Paragraph P1 (title, bold)  -> `##` H2
Paragraph "Heading 1"       -> `##` H2  (used for §1..§11)
Paragraph "List Paragraph"  -> `- ` unordered list item
Paragraph style None        -> plain paragraph
```


## T9 — llm_router internals

### `/app/backend/services/synisense/shield/llm_router.py:14-18`

```
records all three in the audit log and trust receipt.

Chunk 18 (Track 4 item 1, 2026-05-21) — `emergentintegrations.LlmChat`
moved to module-level import (was inline inside `invoke()` for the
fallback-availability check pattern). Module-level import pays the
```

### `/app/backend/services/synisense/shield/llm_router.py:33-43`

```
# Chunk 18 cold-start fix — module-level import + availability probe.
# This replaces the previous inline `try: from emergentintegrations.llm.chat
# import LlmChat, UserMessage` inside invoke(). The probe runs ONCE at
# import time; subsequent invocations skip the try/except cost.
try:
    from emergentintegrations.llm.chat import LlmChat, UserMessage  # noqa: WPS433
    _EMERGENT_AVAILABLE = True
except Exception as _exc:  # noqa: BLE001
    LlmChat = None  # type: ignore[assignment]
    UserMessage = None  # type: ignore[assignment]
    _EMERGENT_AVAILABLE = False
```

### `/app/backend/services/synisense/shield/llm_router.py:46-61`

```
    _EMERGENT_IMPORT_ERROR = None

# Chunk 18.5 cold-start fix — lift `litellm` + `get_integration_proxy_url`
# from per-call lazy imports to module-level. The previous code paid the
# import-cache lookup + module init on every cold path even though both
# are pure-python wrappers with no side-effects worth deferring.
# Module-level matches the LlmChat probe style above + uses the same
# `_EMERGENT_AVAILABLE` flag to short-circuit on missing deps.
try:
    import litellm  # noqa: WPS433
    from emergentintegrations.llm.utils import get_integration_proxy_url  # noqa: WPS433
    _LITELLM_AVAILABLE = True
except Exception as _lite_exc:  # noqa: BLE001
    litellm = None  # type: ignore[assignment]
    get_integration_proxy_url = None  # type: ignore[assignment]
    _LITELLM_AVAILABLE = False
```

### `/app/backend/services/synisense/shield/llm_router.py:64-68`

```
    _LITELLM_IMPORT_ERROR = None

log = logging.getLogger("synisense.shield.llm_router")

ModelPreference = Literal["analytical", "generative", "balanced"]
```

### `/app/backend/services/synisense/shield/llm_router.py:76-85`

```


def _provider_for(preference: ModelPreference) -> Tuple[str, str]:
    return _PROVIDER_TABLE.get(preference, _PROVIDER_TABLE["balanced"])


# ─────────────────────────────────────────────────────────────────────
# Deterministic echo fallback. Used when EMERGENT_LLM_KEY is missing OR
# when SYNISENSE_LLM_MODE=mock. Smoke tests opt into this so they don't
# burn LLM budget. The fallback intentionally echoes the de-identified
```

### `/app/backend/services/synisense/shield/llm_router.py:103-112`

```
    network) so the Shield can fail-closed and emit a 503.

    Backwards-compatible wrapper around `invoke_with_metering`. Existing
    callers that don't need token metering keep the 3-tuple shape. The
    Shield client + the legacy `/api/synisense/shield/invoke` route both
    use `invoke_with_metering` to capture exact provider usage.
    """
    text, provider, model, _usage = await invoke_with_metering(
        de_id_content,
        model_preference=model_preference,
```

### `/app/backend/services/synisense/shield/llm_router.py:116-120`

```


async def invoke_with_metering(
    de_id_content: str,
    *,
```

### `/app/backend/services/synisense/shield/llm_router.py:138-159`

```
    rippling into every other shield_invoke consumer.
    """
    provider, model = _provider_for(model_preference)

    # Mock mode — explicit opt-in OR no key configured.
    llm_mode = os.environ.get("SYNISENSE_LLM_MODE", "").lower()
    emergent_key = os.environ.get("EMERGENT_LLM_KEY", "").strip()
    if llm_mode == "mock" or not emergent_key:
        if not emergent_key and llm_mode != "mock":
            log.info("synisense.shield.llm_router: EMERGENT_LLM_KEY absent — using echo fallback")
        return (_mock_invoke(de_id_content), provider + ":mock", model + ":mock", {})

    # Live mode — call litellm directly so we can keep the ModelResponse
    # and pull `usage.prompt_tokens` / `usage.completion_tokens`. Module-
    # level import probe (Chunk 18 cold-start) covers the integrations SDK;
    # `_LITELLM_AVAILABLE` (Chunk 18.5) covers litellm + the proxy URL
    # helper. Both probes run ONCE at import time.
    if not _EMERGENT_AVAILABLE or not _LITELLM_AVAILABLE:
        log.warning(
            "synisense.shield.llm_router: SDK unavailable (emergent=%s litellm=%s)",
            _EMERGENT_IMPORT_ERROR or "ok",
            _LITELLM_IMPORT_ERROR or "ok",
```

### `/app/backend/services/synisense/shield/llm_router.py:164-172`

```
        proxy_url = get_integration_proxy_url()
        if provider == "gemini":
            litellm_model = f"gemini/{model}"
        else:
            litellm_model = model  # openai, anthropic via the universal LLM proxy
        params = {
            "model": litellm_model,
            "messages": [
                {
```

### `/app/backend/services/synisense/shield/llm_router.py:185-189`

```
        }
        response = await asyncio.wait_for(
            litellm.acompletion(**params),
            timeout=timeout_seconds,
        )
```

### `/app/backend/services/synisense/shield/llm_router.py:209-213`

```
        # Suppress unused-import warnings when emergentintegrations imports
        # have already been done at module load.
        _ = (LlmChat, UserMessage)
        return (text, provider, model, usage)
    except asyncio.TimeoutError as exc:
```

### `/app/backend/services/synisense/shield/llm_router.py:216-220`

```
        ) from exc
    except Exception as exc:  # noqa: BLE001
        log.warning("synisense.shield.llm_router: invoke failed (%s)", type(exc).__name__)
        raise ServiceUnavailable(
            f"LLM provider call failed: {type(exc).__name__}: {str(exc)[:200]}"
```

### `/app/backend/services/synisense/shield/llm_router.py:222-229`

```

# ─────────────────────────────────────────────────────────────────────
# Commercial-cut 2026-07-06 — SonnetWizardAgent extracted to salvage.
# ─────────────────────────────────────────────────────────────────────
# Owner ruling (BCR v1.4 §12): commercial half + buyer wizard variant
# cut. The `SonnetWizardAgent` class + `_sonnet_invoke` helper landed
# at Phase 7 Stage B-2 for the buyer wizard were moved verbatim to:
#   /app/salvage/commercial_cut_2026_07_06/backend/wizard/sonnet_wizard_agent_extracted.py
```

### `/app/backend/services/synisense/shield/client.py:28-32`

```
    audit_log,
    deidentifier,
    llm_router,
    purpose_validator,
    reidentifier,
```

### `/app/backend/services/synisense/shield/client.py:52-56`

```
    Phase 14 (2026-06-05) — `system_msg` kwarg threads a caller-
    provided system prompt all the way to the provider. When None,
    llm_router uses its built-in generic system prompt (preserves
    pre-Phase-14 behaviour for the 90+ existing call sites). When
    provided (e.g. chat router's fluency preamble), it REPLACES the
```

### `/app/backend/services/synisense/shield/client.py:65-69`

```
    started = time.perf_counter()
    de_id = await deidentifier.deidentify(content, tenant_id=tenant_id, purpose=purpose)
    llm_text, provider, model, usage = await llm_router.invoke_with_metering(
        de_id.redacted_text, model_preference=model_preference,
        system_msg=system_msg,
```

### `/app/backend/services/synisense/shield/client.py:79-85`

```

    # Chunk 18 (Track 4 item 2, 2026-05-21) — token-accurate metering.
    # `llm_router.invoke_with_metering` returns `usage = {"input_tokens",
    # "output_tokens", "method": "exact"}` when the provider SDK
    # surfaced a usage payload (live `litellm.acompletion` path). On
    # mock-mode or any path where usage is empty we fall back to the
    # char/4 estimator. The audit row carries both the token counts
```

### `/app/backend/services/synisense/shield/client.py:133-137`

```
# ─────────────────────────────────────────────────────────────────────
# `invoke()` above does the whole round-trip including the LLM call
# (via `llm_router.invoke_with_metering`). The chat streaming surface
# (`routers/chat.py:2390`) needs to drive the LLM round-trip itself
# via `stream_llm_direct`, so it can yield deltas to the SSE client.
```


## T10 — Grounding gates

### `/app/backend/services/opportunity_briefs/brief_grounding.py:1-12`

```
"""Brief grounding gate — OB-E1 α mechanical byte-verbatim substring check.

Owner ruling OB-E1 α (2026-07-10 · verbatim): *"Structured anchor +
byte-verbatim substring check, whole-brief reject on any failure, gate
never patches — the AF-E1 β grammar ported intact, including its
conditions (mechanical check, no semantic scoring)."*

Two sub-gates:
  (A) byte-verbatim value check — every `value` in
      `quantitative_anchors` MUST appear byte-verbatim in the text of
      the Registry read at `registry_read_ref`.
  (B) numeric-coverage check — every numeric in `brief_text` (regex
```

### `/app/backend/services/opportunity_briefs/brief_grounding.py:17-21`

```

**NO semantic scoring** (AF-G6b lineage · §6.10 AST attest at
`test_ob_g6_brief_grounding_no_semantic_scoring_ast`).
"""
from __future__ import annotations
```

### `/app/backend/services/opportunity_briefs/brief_grounding.py:36-40`

```


def verify_brief_grounding(
    brief_text: str,
    quantitative_anchors: List[Dict],
```

### `/app/backend/services/opportunity_briefs/brief_grounding.py:61-65`

```
    → brief NOT emitted; gate never edits the brief.
    """
    # (A) byte-verbatim value check
    for i, anchor in enumerate(quantitative_anchors):
        value = anchor.get("value", "")
```

### `/app/docs/registry/function_promise_registry_v0.md:46-52`

```
| PROM-S1-additive-versioning | New contracts land by additive versioning (v0 preserved byte-identical when v1 lands); parity bumps with the new snapshot; V1-G7 assertion set bumps with it. | yes | 2 | AS-E1 α · V1-G7 |
| PROM-S1-honesty-grammar-source-labels | Every value in a client-facing envelope carries its provenance source label; values not observed by the census carry a non-`census_observed` source label OR are null; NO fabricated values. | yes | 5 | CD-E1 α · 9.2a-E1 α · doctrine D-3 |
| PROM-S1-byte-verbatim-anchor-grounding | Every quantitative anchor in an LLM-synthesized advisory or answer must appear byte-verbatim in a Registry-read text; whole-envelope REJECT on any failure; gate NEVER patches prose. | yes | 3 | AF-E1 β · OB-E1 α · doctrine §Part IV D-3 D-5 |
| PROM-S1-no-semantic-scoring | Grounding gates are mechanical byte-substring checks; semantic scoring is FORBIDDEN. | yes | 3 | AF-E1 β cond 1 · OB-E1 α · doctrine D-3 |
| PROM-S1-registry-native-aggregate | A Combined-scope aggregate = Registry-exposed native (the Registry computes; the brief/answer quotes byte-verbatim); synthesis-time computation is FORBIDDEN. | yes | 2 | OB-E3 α · doctrine §Part VII |
| PROM-S1-class-honesty-render-time | Class-honesty is enforced at render time — no render path strips the advisory marker; no governed-response import path touches advisory content; namespace boundaries surfaced via distinct id prefixes. | yes | 4 | OB-E2 α × 3 seams · AS-G6 · TF-G9 · FR-G4 · AF-G6b |
| PROM-S1-runtime-transient-never-refusal | Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope. | yes | 2 | AF-E2 amended · OB-runtime-transient-precedent |
```

### `/app/docs/registry/function_promise_registry_v0.md:98-106`

```
|---|---|---|---|---|---|---|---|---|---|---|
| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
```

### `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:17-21`

```
**Disposition — applied verbatim:**

- **β anchor-mapping mechanic:** the LLM MUST emit `{prose, per_sentence: [{sentence_text, unit_ids: [...]}]}` structured JSON (Shield-side schema enforcement in `services/synisense/shield/fluency_synthesizer.py`). Grounding gate at `services/service_1/answer_grounding.py::verify_grounding(...)`:
  - **(A) unit_id ∈ set gate:** every declared `unit_id` in `per_sentence[*].unit_ids` MUST be in the caller's `load_bearing_unit_ids`. Any foreign unit_id → REJECT.
  - **(B) sentence-anchor coverage gate:** every sentence in `prose` (segmented into sentences by a mechanical splitter — see §3 below) MUST correspond to a `per_sentence[i]` entry with a non-empty `unit_ids` list. Any sentence in prose that is not covered by a per_sentence anchor entry → REJECT.
```

### `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:25-29`

```
- **Sentence splitter (Tier-3 default):** mechanical regex splitter on sentence-terminating punctuation `[.!?]` followed by whitespace/EOF; not an LLM-based segmenter (a subtle failure mode would be an LLM-based splitter drifting from the anchor mapping). Whitespace normalisation before comparison.

- **Anchoring reflection cell:** AF-G6b (§6.10 reflection class) attests that `services/service_1/answer_grounding.py` implements exactly gates (A)+(B)+(C)+(D) with no additional semantic-scoring branches (grep-negative on `similarity` / `overlap` / `jaccard` / `embedding` in the module).

### §1.2 AF-E2 — Amended boundary set (Owner-ruled · owner-value amendment to BCR anchor)
```

### `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:124-128`

```
| **AF-G5** | Tier-3 | Fluency-mode telemetry sidecar structure (mirrors execution_mode_telemetry) | `...::test_af_g5_fluency_mode_telemetry_sidecar_shape` |
| **AF-G6a** | Tier-1 | Shield chokepoint discipline (LLM call routes through Shield) | pre-existing `test_no_direct_llm_calls_outside_shield` |
| **AF-G6b** | **Tier-1 (§6.10 AST/reflection)** | `answer_grounding.py` implements exactly gates (A)+(B)+(C)+(D), no semantic branches | `...::test_af_g6b_answer_grounding_no_semantic_scoring_ast` |
| **AF-G7** | Tier-1 | Grounding-gate reject NOT a refusal · quality-gate outcome preserved as mechanical | `...::test_af_g7_grounding_reject_falls_through_not_refusal` |
| **AF-G8** | **Tier-1 (§6.10 · data-blind posture)** | Prompt template file contains no broadcaster/genre/regional residues | `...::test_af_g8_prompt_template_data_blind_no_residues` |
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:11-23`

```
## §1. Owner rulings — verbatim carriers

### §1.1 OB-E1 α — Structured anchor + byte-verbatim substring check (Owner-ruled)

> **OB-E1 — α.** Structured anchor + byte-verbatim substring check, whole-brief reject on any failure, gate never patches — the AF-E1 β grammar ported intact, including its conditions (mechanical check, no semantic scoring). β declined: the "correct numeric from wrong read" gap it closes is citation precision, not fabrication — OB-R2's promise is no-fabricated-values, α closes it fully, and per-slice citation accuracy for Combined briefs is already OB-G5's job under E3 below. No gate beyond the promise.

**Disposition — applied verbatim:**

- LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured JSON via Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (mirrors AF-E1 β precedent).
- Grounding gate at `services/opportunity_briefs/brief_grounding.py::verify_brief_grounding(...)`:
  - **(A) byte-verbatim value check:** every `value` in `quantitative_anchors` MUST appear byte-verbatim in the text of the Registry read at `registry_read_ref`. Mechanical byte-substring check; **no semantic scoring**.
  - **(B) numeric-coverage check:** every numeric appearing in `brief_text` (regex `[0-9]+(?:[.,][0-9]+)*%?`) MUST have a corresponding anchor entry with byte-matching `value`.
  - **(C) whole-brief reject (Owner-verbatim):** *"whole-brief reject on any failure, gate never patches"* — any (A)/(B) failure → brief NOT emitted; regeneration tagged `grounding_reject`; gate NEVER edits the brief.
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:47-56`

```
### §1.3 OB-E3 α — Registry-computable aggregate = Registry-exposed native (Owner-ruled)

> **OB-E3 — α.** A Registry-computable aggregate is one the Registry read API itself exposes and the brief quotes byte-verbatim; synthesis-time computation forbidden. This is the mandate's own sentence made mechanical — the Registry computes, the brief quotes. β moves computation to the exact layer the rule exists to keep it out of; γ guts Combined scope.

**Disposition — applied verbatim:**

- Registry-computable aggregate = a numeric field the Registry read API (`services/mtafiti/registry.py`) exposes as its own read (e.g., `count_of_units_in_slice(slice_id) → int`).
- The brief quotes the returned value byte-verbatim in `brief_text` with corresponding `registry_read_ref` in `quantitative_anchors`.
- **Synthesis-time computation FORBIDDEN:** no `sum(...)` / `avg(...)` / `min(...)` / `max(...)` / `count(...)` or equivalent operator applied inside `services/synisense/shield/brief_synthesizer.py` or `services/opportunity_briefs/brief_proposer.py` at synthesis time.
- Enforcement: §6.10 grep-negative reflection gate on generator + synthesizer paths for the operator whitelist.
```

### `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:96-100`

```

Mechanism classes reused:
- **AF-E1 β + Condition 1 grounding grammar** → OB-E1 α byte-verbatim substring check.
- **§6.10 AST/reflection (AS-G6 / TF-G9 / FR-G4 / AF-G6b lineage)** → OB-E2 Seam-1/2/3 α mechanism.
- **Sidecar telemetry (9.2a-E2 α cond 2 + AF-E3 α)** → OB fluency-mode-style observability.
```


## T11 — Refusal envelopes

### `/app/backend/services/service_1/admission_refusal.py:3-7`

```
Responsibilities:
  1. `is_valid_reason(reason: str) -> bool` — reads the versioned
     registry `admission_refusal_reasons.v1.json` (Ruling 3
     control-surface pattern) and returns whether `reason` is a valid
     registered admission-refusal reason code.
```

### `/app/backend/services/service_1/admission_refusal.py:20-28`

```
deliberations ("await owner acceptance of the ingredient-manifest
guarantee" or similar). Enforced by grep-negative gate
`test_admission_refusal_actor_appropriate_string`.

Ruling 3 posture: this file reads the registry; adding a new reason is
a REGISTRY bump (new entry, or `vN.json` file), NEVER modification of
`contracts/admission_refusal.py` or its `.contract_snapshot.json`. The
service-layer `is_valid_reason` check is defense-in-depth against a
code path passing an unregistered reason.
```

### `/app/backend/services/service_1/admission_refusal.py:33-37`

```
codes (`grain_form_incompatible`, `standard_below_admission_floor`,
`license_class_unavailable`). Extension enforced by
`test_admission_refusal_registry_v1_extends_v0_additively`.

Phase 5 Stage B registry-bump landing (2026-07-04): `_REGISTRY_PATH`
```

### `/app/backend/services/service_1/admission_refusal.py:44-48`

```
governance-refusal codes: `fleet_policy_reserved_zero_capacity`,
`pricing_tier_frozen_by_control_surface`, `exploratory_tier_expired`.
Extension enforced by `test_admission_refusal_v3_extends_v2_additively`.
"""
from __future__ import annotations
```

### `/app/backend/services/service_1/admission_refusal.py:53-61`

```
from typing import Dict, List, Optional

from contracts.admission_refusal import AdmissionRefusal_v0
from contracts.objective_request_v2 import ObjectiveRequest_v2


_REGISTRY_PATH = Path(__file__).parent / "admission_refusal_reasons.v3.json"
```

### `/app/backend/services/service_1/admission_refusal.py:85-89`

```
#
# The following strings are GREP-INSPECTED by
# `test_admission_refusal_actor_appropriate_string`:
#   * MUST NOT contain: "await owner", "owner acceptance",
#     "ingredient manifest", "ingredient-manifest".
```

### `/app/backend/services/service_1/admission_refusal.py:108-112`

```
    trace_id: str,
) -> AdmissionRefusal_v0:
    """Build the admission-refusal envelope for v3 §6.5 form_not_offerable.

    Fires when `request.output.form == OutputForm.MODEL` at admission
```

### `/app/backend/services/service_1/admission_refusal.py:124-128`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:156-160`

```
    path_forward: str,
) -> AdmissionRefusal_v0:
    """Build an admission-refusal envelope for v3 §6.1.4/§6.2.4/§6.3.4/
    §6.4.4 (form, grain) incompatibility.
```

### `/app/backend/services/service_1/admission_refusal.py:176-180`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:202-206`

```
    qualifying_volume_after_filter: int,
) -> AdmissionRefusal_v0:
    """Build an admission-refusal envelope for v3 §6.1.6 standard hard
    input filter.
```

### `/app/backend/services/service_1/admission_refusal.py:216-220`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:247-251`

```
    derived_class: str,
) -> AdmissionRefusal_v0:
    """Build an admission-refusal envelope for v3 §6.1.2 license-class
    axis of the three-way selection intersection.
```

### `/app/backend/services/service_1/admission_refusal.py:261-265`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:315-319`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:354-358`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:414-418`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:453-457`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/admission_refusal.py:491-495`

```
    if not is_valid_reason(reason):
        raise RuntimeError(
            f"admission_refusal_reasons.vN.json registry does not list "
            f"reason={reason!r} — construction blocked."
        )
```

### `/app/backend/services/service_1/refusal_hints.py:15-19`

```
authoritative. Any future addition of a new reason MUST add a row here
or KeyError at raise time — CI catches drift via
`test_service_1_refusal_envelope`.
"""
from __future__ import annotations
```

### `/app/backend/services/v2_gate/refusal.py:24-28`

```
    detail: str = "",
) -> V2RefusalEnvelope:
    """Emit a structured V2 refusal envelope.

    Callers MUST NOT emit content bytes after invoking this. The refusal
```

### `/app/backend/services/compliance/refusal_family_classifier.py:21-25`

```

Families (Owner-enumerated at dispatch):
  * `admission_refusals` — governance refusals at admission time via
    `AdmissionRefusal_v0` (v3 registry codes)
  * `composition_below_floor` — Service_1 refusals at conclusion class
```

### `/app/backend/services/compliance/refusal_family_classifier.py:36-40`

```
     (three reasons: `composition_below_floor`, `no_defensibility_floor`,
      `no_lawful_basis`)
  3. Elif `reason` in ADMISSION_REASONS → `admission_refusals` family
  4. Else → `unclassified` (row falls outside known families; MUST be
     surfaced honestly — not silently dropped)
```

### `/app/backend/services/compliance/refusal_family_classifier.py:51-55`

```
Auth 403s (auth_scope_insufficient / auth_missing / auth_expired /
auth_identity_mismatch_for_wizard_session) and validation 422s are
NOT governed-refusal envelopes — they do NOT reach this classifier.
Enforcement: aggregate query filters `decision == "refused"` in the
ledger; auth denials never write to the ledger. Exclusion gate
```

### `/app/backend/services/compliance/refusal_family_classifier.py:65-69`

```

FamilyName = Literal[
    "admission_refusals",
    "composition_below_floor",
    "outer_gate_refusals",
```

### `/app/backend/services/compliance/refusal_family_classifier.py:75-80`

```
# on-disk versioned registries. `composition_below_floor` family carries
# the three Service_1-refusal reasons per docstring & registry.
_SERVICE_1_REGISTRY = Path(__file__).resolve().parents[2] / "services" / "service_1" / "service_1_refusal_reasons.v0.json"
_ADMISSION_REGISTRY = Path(__file__).resolve().parents[2] / "services" / "service_1" / "admission_refusal_reasons.v3.json"
```

### `/app/backend/services/compliance/refusal_family_classifier.py:108-112`

```
        return "composition_below_floor"
    if reason in ADMISSION_REASONS:
        return "admission_refusals"
    return "unclassified"
```

### `/app/backend/services/compliance/refusal_family_classifier.py:115-119`

```
# response ordering; alphabetical by family name for determinism).
FAMILY_DISPLAY_ORDER = (
    "admission_refusals",
    "composition_below_floor",
    "outer_gate_refusals",
```

### `/app/backend/services/northena/converge.py:129-133`

```
    lawful_basis_ref: str,
) -> LedgerRow:
    """G6 seam — V2 refusal envelope lands in a gate-stage row.

    Product v2.1 §29.1 "V2 gates the outer-gate file-out"; §22.1 "every
```

### `/app/backend/contracts/admission_refusal.py:1-3`

```
"""AdmissionRefusal@v0 — governed admission-time refusal envelope
(Phase 3 freeze — 17th frozen contract).
```

### `/app/backend/contracts/admission_refusal.py:20-24`

```
The `reason` field is typed as constrained `str` (snake_case pattern),
NOT `Literal`. The valid-reason SET lives in a plain versioned registry
at `services/service_1/admission_refusal_reasons.v0.json`. Adding a
future reason is a REGISTRY BUMP (v0.json → v1.json, or an append-only
entry per the config policy), NEVER a contract file modification and
```

### `/app/backend/contracts/admission_refusal.py:39-43`

```

Service-layer validation reads the registry at construction/validation
time (see `services/service_1/admission_refusal.py::is_valid_reason`).
The contract file (this file) and its `.contract_snapshot.json` stay
byte-identical when a reason is added — that is the intended alarm
```

### `/app/backend/contracts/admission_refusal.py:59-63`

```
deliberations ("await owner acceptance of the ingredient-manifest
guarantee" or similar) as if they were caller-actionable. Enforced by
grep-negative gate `test_admission_refusal_actor_appropriate_string`.

**Convention anchors:**
```

### `/app/backend/contracts/admission_refusal.py:69-73`

```

Freeze contract: `AdmissionRefusal_v0.model_json_schema()` snapshotted
to `tests/invariants/admission_refusal.contract_snapshot.json`.
Mechanical parity invariant enforces the source→snapshot bijection at
17 entries post-Phase-3.
```

### `/app/backend/contracts/admission_refusal.py:81-89`

```

class AdmissionRefusal_v0(BaseModel):
    """Governed admission-time refusal envelope.

    First firing reason: `form_not_offerable` (v3 §6.5). Future reasons
    (e.g. standard-not-met, offerability-out-of-scope) land as REGISTRY
    additions at `services/service_1/admission_refusal_reasons.vN.json`
    — this contract file is NOT modified when a reason is added.
    """
```

### `/app/backend/contracts/admission_refusal.py:95-99`

```
        description=(
            "Family discriminator. Same value + type as "
            "Service1Refusal@v0.outcome — refusal envelopes are a "
            "family, distinguished by firing site + reason semantics, "
            "not by a second grammar."
```

### `/app/backend/contracts/admission_refusal.py:107-111`

```
            "Refusal reason code. snake_case. First firing value: "
            "'form_not_offerable' (v3 §6.5). Valid-reason SET governed "
            "by `services/service_1/admission_refusal_reasons.vN.json` "
            "(versioned registry) — NOT by a Literal here. Adding a "
            "reason = registry bump, NEVER contract modification. "
```

### `/app/backend/contracts/admission_refusal.py:153-157`

```
        min_length=1,
        description=(
            "ISO-8601 UTC. When the refusal envelope was constructed. "
            "Convention-anchored to MiningPlan.generated_at."
        ),
```

### `/app/backend/contracts/service_1_refusal.py:1-3`

```
"""Service1Refusal@v0 — governed refusal envelope for Service 1 (A2 frozen).

14th frozen contract. Additive to the 13 pre-A2 frozen contracts; no
```

### `/app/backend/contracts/service_1_refusal.py:35-40`

```

Snapshot invariant:
  `tests/invariants/service_1_refusal.contract_snapshot.json`
  compared in `tests/invariants/test_service_1_refusal_envelope.py`.
  Any drift fails CI (Operating Protocol §1.7).
"""
```

### `/app/backend/contracts/service_1_refusal.py:49-53`

```

class Service1Refusal(BaseModel):
    """Flat governed-refusal envelope emitted by `POST /api/service_1/run`."""

    model_config = ConfigDict(extra="forbid", frozen=True)
```


## T12 — Key custody

### `/app/backend/services/synisense/config.py:25-29`

```
# value (at least 32 bytes of base64 / hex). Per-tenant HMAC keys are
# derived via HKDF from this master secret with `tenant_id` as the
# info parameter (see `shield/trust_receipt.py`).
#
# If the env var is missing we generate a dev-only ephemeral secret and
```

### `/app/backend/services/synisense/config.py:118-122`

```
    "work_studio.*",

    # JC-WS Phase 2 (2026-06-25) — Analyze workspace (canonical
    # spec Part B). The docked-prompt + tips strip + finish-export
    # journey routes free-text questions to a Shield-routed
```

### `/app/backend/services/synisense/config.py:167-171`

```
    # the new `contributions.revision_request_draft` Shield-routed
    # draft endpoint that backs the "AI drafts suggested revision
    # requests" promise from the JC-TM canonical spec Part 0.
    "task_manager.compile.drafting.board_pack",
    "task_manager.compile.drafting.committee_pack",
```

### `/app/backend/services/synisense/shield/trust_receipt.py:9-13`

```
  length=32, salt=b"synisense/v1")``. Different tenants get different
  keys; the same tenant always derives the same key.
- **Signature**   : ``HMAC-SHA256(per_tenant_key, canonical_json(payload
  minus signature))``. We sort keys lexicographically and separators=
  (',', ':') for stability across language / version boundaries.
```

### `/app/backend/services/synisense/shield/trust_receipt.py:33-37`

```
from services.synisense.config import MASTER_SECRET

log = logging.getLogger("synisense.shield.trust_receipt")

_HKDF_SALT = b"synisense/v1"
```

### `/app/backend/services/synisense/shield/trust_receipt.py:62-66`

```


def _canonical_json(payload_no_sig: Dict[str, Any]) -> bytes:
    """Stable JSON encoding: sorted keys, compact separators, UTF-8."""
    return json.dumps(
```

### `/app/backend/services/synisense/shield/trust_receipt.py:71-79`

```

def sign(payload: Dict[str, Any], *, tenant_id: str) -> str:
    """Compute the HMAC-SHA256 hex over the canonical JSON of `payload`
    with the `signature` field stripped. Mutates nothing."""
    body = {k: v for k, v in payload.items() if k != "signature"}
    key = derive_tenant_key(tenant_id)
    mac = hmac.new(key, _canonical_json(body), hashlib.sha256)
    return mac.hexdigest()
```

### `/app/backend/services/synisense/shield/trust_receipt.py:97-101`

```


def build_trust_receipt(
    *,
    receipt_id: str,
```

### `/app/backend/services/synisense/shield/audit_log.py:2-7`

```

Writes to two collections:
- `synisense_audit_log`     : one row per Shield invocation.
- `synisense_trust_receipts`: signed receipt mirror; consumers can
  retrieve their receipts via the Shield without exposing the audit
  log proper.
```

### `/app/backend/services/synisense/shield/audit_log.py:18-26`

```
from core import db

log = logging.getLogger("synisense.shield.audit_log")


AUDIT_COLLECTION = "synisense_audit_log"
RECEIPT_COLLECTION = "synisense_trust_receipts"
```

### `/app/backend/services/synisense/shield/audit_log.py:167-174`

```
    # Store a payload_hash alongside the receipt so the audit chain can
    # be verified without retrieving the full receipt body.
    from services.synisense.shield.trust_receipt import hash_payload, _canonical_json
    body = {k: v for k, v in receipt.items() if k != "signature"}
    payload_hash = "sha256:" + __import__("hashlib").sha256(
        _canonical_json(body),
    ).hexdigest()
    # Phase A leaves `payload_hash` derivable; we still store it
```

### `/app/backend/services/synisense/shield/canonical.py:1-3`

```
"""Synisense Shield — canonical chat ShieldOutcome mint (H2.5 follow-up).

Background
```

### `/app/backend/services/synisense/shield/canonical.py:6-13`

```
reporting Shield activity, each fed by a different engine:

  * ``db.chat_audit_log``           ← legacy ``adapter.shield_payload_async``
                                      (``synisense-pipeline`` vocabulary,
                                      lowercase ``by_category`` keys)
  * ``db.synisense_audit_log``      ← ``shield.client.prepare_for_streaming``
                                      (``synisense-shield-v1``,
                                      UPPERCASE ``de_id_summary`` keys)
```

### `/app/backend/services/synisense/shield/canonical.py:55-59`

```
still goes through Shield's streaming wrapper so prior-turn PII in
history gets re-redacted. That wrapper writes its own
``synisense_audit_log`` row — its counts are a superset of this mint's
counts (history identifiers are added), but the BOOLEAN agrees.
"""
```

### `/app/backend/services/synisense/shield/canonical.py:69-73`

```
from services.synisense.shield.exceptions import ShieldFailure

logger = logging.getLogger("akki.synisense.shield.canonical")

SHIELDED_BY = "synisense-shield-v1"
```

### `/app/backend/services/synisense/shield/canonical.py:79-83`

```
    """Single source of truth for "what did Shield do to the user's
    current message this turn?" Every surface that reports per-turn
    Shield activity (chat_audit_log, synisense_runs, user_msg.shielding)
    derives its counts from this object."""
```

### `/app/backend/services/synisense/shield/canonical.py:91-95`

```
    def by_category(self) -> Dict[str, int]:
        # Alias the legacy `by_category` shape onto `de_id_summary`.
        # Keys stay UPPERCASE for parity with `synisense_audit_log`.
        return dict(self.de_id_summary)
```

### `/app/backend/services/synisense/shield/canonical.py:117-121`

```
    """Run Shield's de-identifier on ``user_text`` and persist a
    ``synisense_runs`` row so ``/synisense-metrics`` finds the
    activity. Returns the canonical outcome.

    Fail-closed: any ``ServiceUnavailable`` from the de-identifier
```

### `/app/backend/services/synisense/shield/llm_router.py:81-85`

```

# ─────────────────────────────────────────────────────────────────────
# Deterministic echo fallback. Used when EMERGENT_LLM_KEY is missing OR
# when SYNISENSE_LLM_MODE=mock. Smoke tests opt into this so they don't
# burn LLM budget. The fallback intentionally echoes the de-identified
```

### `/app/backend/services/synisense/shield/llm_router.py:142-149`

```
    # Mock mode — explicit opt-in OR no key configured.
    llm_mode = os.environ.get("SYNISENSE_LLM_MODE", "").lower()
    emergent_key = os.environ.get("EMERGENT_LLM_KEY", "").strip()
    if llm_mode == "mock" or not emergent_key:
        if not emergent_key and llm_mode != "mock":
            log.info("synisense.shield.llm_router: EMERGENT_LLM_KEY absent — using echo fallback")
        return (_mock_invoke(de_id_content), provider + ":mock", model + ":mock", {})
```
