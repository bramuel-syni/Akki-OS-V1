# Shield Engine Specifications — Mechanical Bundle Manifest

Assembled mechanically per Standing Rule v3 · Verbatim Doctrine · R4/D7 bounds. No new authoring. Every excerpt is byte-identical to its on-disk source; file paths + SHA-256 + line ranges accompany every citation.

Bundle root: `/tmp/shield_engine_specs/`  ·  Files inventoried: **61**

## Section 1 — Discovery transcripts (verbatim)

### 1.1 · Step-1 grep transcript

Command:

```
grep -RIn -E 'synisense\.shield|Shield engine|shield adapter|shield\.fluency_synthesizer|shield\.brief_synthesizer|Shield-mediated|via Shield' /app/docs /app/backend /app/memory | sort -u
```

Line count: **79** lines.

```
/app/backend/routers/service_1.py:41:from services.synisense.shield import fluency_synthesizer as fluency_synthesizer_module
/app/backend/services/layer_b/asr/whisper_provider.py:1:"""ASR provider — OpenAI-Whisper-API path (via Shield perception_router).
/app/backend/services/layer_b/asr/whisper_provider.py:24:from services.synisense.shield import perception_router
/app/backend/services/layer_b/vision/frame_perception_provider.py:1:"""Vision-LM provider — frame perception via Shield perception_router.
/app/backend/services/layer_b/vision/frame_perception_provider.py:22:from services.synisense.shield import perception_router
/app/backend/services/opportunity_briefs/generator.py:38:from services.synisense.shield import brief_synthesizer as _synth
/app/backend/services/service_1/composed_conclusion.py:92:from services.synisense.shield.fluency_synthesizer import (
/app/backend/services/synisense/config.py:77:    # NOTE: `synisense.shield.internal.ner` REMOVED — Phase A switched
/app/backend/services/synisense/shield/audit_log.py:169:    from services.synisense.shield.trust_receipt import hash_payload, _canonical_json
/app/backend/services/synisense/shield/audit_log.py:20:log = logging.getLogger("synisense.shield.audit_log")
/app/backend/services/synisense/shield/brief_synthesizer.py:114:    from services.synisense.shield import llm_router
/app/backend/services/synisense/shield/brief_synthesizer.py:46:log = logging.getLogger("synisense.shield.brief_synthesizer")
/app/backend/services/synisense/shield/canonical.py:68:from services.synisense.shield import deidentifier
/app/backend/services/synisense/shield/canonical.py:69:from services.synisense.shield.exceptions import ShieldFailure
/app/backend/services/synisense/shield/canonical.py:71:logger = logging.getLogger("akki.synisense.shield.canonical")
/app/backend/services/synisense/shield/client.py:27:from services.synisense.shield import (
/app/backend/services/synisense/shield/client.py:9:    from services.synisense.shield.client import invoke as shield_invoke
/app/backend/services/synisense/shield/deidentifier.py:254:            "synisense.shield: %s load raised %s: %s — attempting download",
/app/backend/services/synisense/shield/deidentifier.py:287:                        "synisense.shield: using en_core_web_sm fallback "
/app/backend/services/synisense/shield/deidentifier.py:291:                log.info("synisense.shield: spaCy NER ready (model=%s)", candidate)
/app/backend/services/synisense/shield/deidentifier.py:295:                log.warning("synisense.shield: %s failed (%s)", candidate, last)
/app/backend/services/synisense/shield/deidentifier.py:438:            "synisense.shield: warmup OK (model=%s, %d ms)",
/app/backend/services/synisense/shield/deidentifier.py:449:            "synisense.shield: ⚠️  WARMUP FAILED (%s) — backend will "
/app/backend/services/synisense/shield/deidentifier.py:474:                "synisense.shield: also failed to persist "
/app/backend/services/synisense/shield/deidentifier.py:49:log = logging.getLogger("synisense.shield.deidentifier")
/app/backend/services/synisense/shield/deidentifier.py:582:        from services.synisense.shield.tenant_entities import lookup_in_text
/app/backend/services/synisense/shield/fluency_synthesizer.py:180:    from services.synisense.shield import llm_router  # local to avoid cycles
/app/backend/services/synisense/shield/fluency_synthesizer.py:55:log = logging.getLogger("synisense.shield.fluency_synthesizer")
/app/backend/services/synisense/shield/llm_router.py:147:            log.info("synisense.shield.llm_router: EMERGENT_LLM_KEY absent — using echo fallback")
/app/backend/services/synisense/shield/llm_router.py:157:            "synisense.shield.llm_router: SDK unavailable (emergent=%s litellm=%s)",
/app/backend/services/synisense/shield/llm_router.py:218:        log.warning("synisense.shield.llm_router: invoke failed (%s)", type(exc).__name__)
/app/backend/services/synisense/shield/llm_router.py:66:log = logging.getLogger("synisense.shield.llm_router")
/app/backend/services/synisense/shield/perception_router.py:31:from services.synisense.shield import trust_receipt
/app/backend/services/synisense/shield/perception_router.py:33:log = logging.getLogger("synisense.shield.perception_router")
/app/backend/services/synisense/shield/trust_receipt.py:35:log = logging.getLogger("synisense.shield.trust_receipt")
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:36:from services.synisense.shield import fluency_synthesizer
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:35:from services.synisense.shield import brief_synthesizer
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:117:        "`services.synisense.shield.client.invoke(...)`. "
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:7:LLM provider SDK call goes through `services.synisense.shield.client`
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:8:(consumer-facing) → `services.synisense.shield.llm_router` (the
/app/backend/tests/test_perception_router.py:5:from services.synisense.shield import perception_router, trust_receipt
/app/docs/close_reports/machine_readable_registry.md:62:**(a) Foreign-key promise integrity (β):** verified — every function row's `PROM-*` token in the `promise` field resolves to an existing top-level `promises` array `promise_id`. Non-PROM adjacent references (e.g., `governance §8` on `synisense.shield.data_blind_prompt_template`) are documentation cross-references, not primary promise attributions; not linted. **No unresolved PROM-references landed.**
/app/docs/close_reports/registry_population.md:44:- Sub-steps of named-and-tested behaviors folded into parent row's `mandate` field per α-amended posture (attested throughout §3 — e.g., "AF-G2a..d + AF-G3a..c" cell subgroups fold into `synisense.shield.grounding_gate_answer_fluency`).
/app/docs/lift_manifest.json:250:      "shape_signature": "Vision-LM provider via Shield perception_router chokepoint",
/app/docs/production_housing/promotion_audit_v0.md:68:**Verifiable:** Yes — `grep -rn "invoke_with_metering\|from services.synisense.shield import llm_router" backend/services/` returns exactly the 2 documented call sites plus the router itself.
/app/docs/registry/function_promise_registry_v0.md:100:| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
/app/docs/registry/function_promise_registry_v0.md:101:| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
/app/docs/registry/function_promise_registry_v0.md:102:| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
/app/docs/registry/function_promise_registry_v0.md:103:| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
/app/docs/registry/function_promise_registry_v0.md:104:| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
/app/docs/registry/function_promise_registry_v0.md:105:| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:106:| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:107:| synisense.shield.advisory_marker_render_time_visible | SyniSense (render surface class) | Built to render the advisory marker verbatim on every card via `data-testid="opportunity-brief-advisory-marker"`. | PROM-S1-class-honesty-render-time | S1.call (advisory route) | `frontend/src/pages/opportunity_briefs/OpportunityBriefCard.jsx` | Jest render assertion | OB-Jest-marker cells · 2 Jest | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:108:| synisense.shield.class_honesty_governed_response_boundary | SyniSense | Built to enforce that governed-response synthesis (service_1) never imports opportunity_briefs; §6.10 AST walk over service_1/**. | PROM-S1-class-honesty-render-time | S1.call (governed response path) | `backend/services/service_1/**` + AST negative-scan | AST/reflection walk (grep-negative) | OB-G-Seam3 · §6.10 · 1 cell | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:109:| synisense.shield.fluency_mode_telemetry_sidecar | SyniSense | Built to emit fluency-mode telemetry via sidecar; envelope byte-identical; parity preserved. | PROM-S1-frozen-wire-contract · PROM-S1-runtime-transient-never-refusal | S3.prove | `backend/services/service_1/fluency_mode_telemetry.py` | Contract-shape lint | AF-G-Sidecar cells · §6.1 · 4 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:110:| synisense.shield.brief_telemetry_sidecar | SyniSense | Built to emit brief-generation telemetry via sidecar following AF-E3 α precedent; envelope byte-identical. | PROM-S1-frozen-wire-contract | S3.prove | `backend/services/opportunity_briefs/brief_telemetry.py` | Contract-shape lint | OB-G-Telemetry · §6.1 · 1 cell | 1 · Deterministic | builder-Tier-3 |
/app/docs/registry/function_promise_registry_v0.md:111:| synisense.shield.mechanical_composer_baseline | SyniSense | Built to preserve the pre-fluency f-string mechanical composer byte-identically to goldens for regression-check. | PROM-S1-frozen-wire-contract | S1.call | `backend/services/service_1/mechanical_composer.py` + `backend/tests/goldens/answer_fluency/pre_3_8/mechanical_baseline.json` | Byte-identity lock (SHA-pin) | AF-G1 · 5 legacy SHA-pin gates repointed · §6.6 | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:112:| synisense.shield.brief_id_namespace_boundary | SyniSense | Built to mint brief IDs in a distinct `brief_` namespace; `/api/solva/trace/{brief_*}` returns 404. | PROM-S3-brief-namespace-distinct-from-trace | S3.prove | `backend/services/opportunity_briefs/brief_registry.new_brief_id` + `backend/routers/solva.py:get_trace` | Runtime 404 + namespace grep | OB-G3 · OB-G3-Seam2-Namespace-Distinct · §6.11 · 2 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:113:| synisense.shield.refusal_taxonomy_closed | SyniSense | Built to enforce the 4-code auth-refusal registry; runtime transients and infra 503s never routed via refusal envelope. | PROM-S1-refusal-taxonomy-closed | S1.call · S3.prove | `backend/services/auth/refusal_envelope.py` + AST negative on health.py | Type-level wall + AST scan | AF-G-Never-Refusal-Envelope · OB-G-Runtime-Transient-Never-Refusal-Envelope · PH-G-Refusal-Closed · §6.10 · 3 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:99:| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
/app/docs/registry/machine/registry.yaml:365:  - function_id: synisense.shield.llm_single_source_boundary
/app/docs/registry/machine/registry.yaml:381:  - function_id: synisense.shield.grounding_gate_answer_fluency
/app/docs/registry/machine/registry.yaml:397:  - function_id: synisense.shield.grounding_gate_opportunity_briefs
/app/docs/registry/machine/registry.yaml:413:  - function_id: synisense.shield.fluency_synthesizer
/app/docs/registry/machine/registry.yaml:429:  - function_id: synisense.shield.brief_synthesizer
/app/docs/registry/machine/registry.yaml:445:  - function_id: synisense.shield.per_sentence_anchor_map
/app/docs/registry/machine/registry.yaml:460:  - function_id: synisense.shield.data_blind_prompt_template
/app/docs/registry/machine/registry.yaml:476:  - function_id: synisense.shield.advisory_marker_write_time_attach
/app/docs/registry/machine/registry.yaml:492:  - function_id: synisense.shield.advisory_marker_render_time_visible
/app/docs/registry/machine/registry.yaml:507:  - function_id: synisense.shield.class_honesty_governed_response_boundary
/app/docs/registry/machine/registry.yaml:522:  - function_id: synisense.shield.fluency_mode_telemetry_sidecar
/app/docs/registry/machine/registry.yaml:538:  - function_id: synisense.shield.brief_telemetry_sidecar
/app/docs/registry/machine/registry.yaml:553:  - function_id: synisense.shield.mechanical_composer_baseline
/app/docs/registry/machine/registry.yaml:568:  - function_id: synisense.shield.brief_id_namespace_boundary
/app/docs/registry/machine/registry.yaml:583:  - function_id: synisense.shield.refusal_taxonomy_closed
/app/docs/requirements/operating_values_v1.md:20:| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:19:- LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured JSON via Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (mirrors AF-E1 β precedent).
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:249:Sonnet 4.6 via Shield's existing `emergentintegrations.LlmChat` path. Owner explicitly said: "Use the standard Emergent LLM key path via Shield's config. Do NOT prompt for API keys." **No user prompt** — Stage B lifts the key from Shield's config lookup (existing pattern at `llm_router.py:41-80` via `os.environ.get("EMERGENT_LLM_KEY")` — verify at Stage B).
/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md:70:- Q3-01 `S1.pass-receipts-through` — cited by `synisense.shield.llm_single_source_boundary`; mechanical Q3 (b) does NOT flag it as gap (has a function). v0.md's Q3-01 finding is that no CI cell attests downstream trust — that's post-boundary archaeology, not mechanical.
```

### 1.2 · Step-2 find inventory

Command:

```
find /app -type f \( -name '*.md' -o -name '*.py' -o -name '*.json' -o -name '*.yaml' \) \( -path '/app/docs/*' -o -path '/app/backend/*' -o -path '/app/memory/*' \) -exec grep -lIE 'synisense\.?shield|shield engine|shield adapter' {} + | sort -u
```

Line count: **25** lines.

```
/app/backend/routers/service_1.py
/app/backend/services/layer_b/asr/whisper_provider.py
/app/backend/services/layer_b/vision/frame_perception_provider.py
/app/backend/services/opportunity_briefs/generator.py
/app/backend/services/service_1/composed_conclusion.py
/app/backend/services/synisense/config.py
/app/backend/services/synisense/shield/audit_log.py
/app/backend/services/synisense/shield/brief_synthesizer.py
/app/backend/services/synisense/shield/canonical.py
/app/backend/services/synisense/shield/client.py
/app/backend/services/synisense/shield/deidentifier.py
/app/backend/services/synisense/shield/fluency_synthesizer.py
/app/backend/services/synisense/shield/llm_router.py
/app/backend/services/synisense/shield/perception_router.py
/app/backend/services/synisense/shield/trust_receipt.py
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py
/app/backend/tests/test_perception_router.py
/app/docs/close_reports/machine_readable_registry.md
/app/docs/close_reports/registry_population.md
/app/docs/production_housing/promotion_audit_v0.md
/app/docs/registry/function_promise_registry_v0.md
/app/docs/registry/machine/registry.yaml
/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md
```

### 1.3 · Step-3/4 expanded inventory (per dispatch: `/app/docs/**` + `/app/backend/**` + `/app/memory/**` for any file referencing Shield chokepoint / boundary / mediation / behind-the-Shield / via Shield / Shield engine / shield adapter / Shield fallback / synisense.shield)

Line count: **61** files.

```
/app/backend/routers/service_1.py
/app/backend/services/compliance/__init__.py
/app/backend/services/layer_b/asr/whisper_provider.py
/app/backend/services/layer_b/vision/frame_perception_provider.py
/app/backend/services/opportunity_briefs/generator.py
/app/backend/services/service_1/composed_conclusion.py
/app/backend/services/synisense/config.py
/app/backend/services/synisense/shield/audit_log.py
/app/backend/services/synisense/shield/brief_synthesizer.py
/app/backend/services/synisense/shield/canonical.py
/app/backend/services/synisense/shield/client.py
/app/backend/services/synisense/shield/deidentifier.py
/app/backend/services/synisense/shield/fluency_synthesizer.py
/app/backend/services/synisense/shield/llm_router.py
/app/backend/services/synisense/shield/perception_router.py
/app/backend/services/synisense/shield/trust_receipt.py
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py
/app/backend/tests/invariants/test_phase_7_stage_b_3_wizard.py
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py
/app/backend/tests/test_perception_router.py
/app/docs/close_reports/answer_fluency.md
/app/docs/close_reports/commercial_cut_2026_07_06.md
/app/docs/close_reports/machine_readable_registry.md
/app/docs/close_reports/phase_7_stage_b_2.md
/app/docs/close_reports/phase_7_stage_b_3.md
/app/docs/close_reports/phase_8_b_1.md
/app/docs/close_reports/phase_8_b_2.md
/app/docs/close_reports/phase_8_b_3.md
/app/docs/close_reports/phase_8_b_4.md
/app/docs/close_reports/phase_8_b_5a.md
/app/docs/close_reports/phase_8a_lite.md
/app/docs/close_reports/production_housing_ph_r1.md
/app/docs/close_reports/registry_population.md
/app/docs/governance/registry_doctrine_v1.md
/app/docs/lift_manifest.json
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_4.md
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md
/app/docs/mandates/RMS_UI_Specification_v2_2.md
/app/docs/production_housing/promotion_audit_v0.md
/app/docs/recon/repo_recon_2026.md
/app/docs/registry/function_promise_registry_v0.md
/app/docs/registry/machine/registry.yaml
/app/docs/requirements/operating_values_v1.md
/app/docs/rule2_accounting.json
/app/docs/rulings/answer_fluency_af_e1_to_e4.md
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md
/app/docs/stage_a_proposals/answer_fluency.md
/app/docs/stage_a_proposals/machine_readable_registry_stage_a.md
/app/docs/stage_a_proposals/opportunity_briefs.md
/app/docs/stage_a_proposals/phase_7_stage_a.md
/app/docs/stage_a_proposals/phase_7_stage_b_2.md
/app/docs/stage_a_proposals/phase_7_stage_b_3.md
/app/docs/stage_a_proposals/phase_8.md
/app/docs/stage_a_proposals/production_housing_ph_r1.md
/app/docs/stage_a_proposals/registry_population_stage_a.md
/app/docs/stage_a_proposals/sequencing_harness_stage_a.md
/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md
/app/memory/ORCHESTRATOR_CONTINUITY.md
/app/memory/PHASE_STATE.md
/app/memory/PRD.md
```

## Section 2 — File Inventory

| # | path | sha256 | lines | classification |
|---|---|---|---:|---|
| 1 | `/app/backend/routers/service_1.py` | `325c27de35e846af3007a6dae6990d0286e7e56e63ad38225439e0b9754b0304` | 324 | backend_code |
| 2 | `/app/backend/services/compliance/__init__.py` | `b466a35c37570c825305b748722b909b3410310bd9bd77b14a816a13edc4050b` | 29 | backend_code |
| 3 | `/app/backend/services/layer_b/asr/whisper_provider.py` | `a45900f46f6178051c95f26c21b92da43d73f931e553adcc58bf0800d8d4f66a` | 56 | backend_code |
| 4 | `/app/backend/services/layer_b/vision/frame_perception_provider.py` | `15c940e26012b4c404763dd99d37a7373f1bf8d3dfda68a67e3f599d182c9ebe` | 51 | backend_code |
| 5 | `/app/backend/services/opportunity_briefs/generator.py` | `f2178dd8691827bae1068c57d45d8bcb38092e29ef4ee758d22e3051e8d35210` | 148 | backend_code |
| 6 | `/app/backend/services/service_1/composed_conclusion.py` | `c6adf31f00825ec03c1e7ed28234412cb4d83f52400a346832da892692d023f1` | 453 | backend_code |
| 7 | `/app/backend/services/synisense/config.py` | `9d6143d6441ffb1fb3c03d4e1c439b358369135c7f3ca5ec826297f7a3fd3b24` | 211 | backend_code |
| 8 | `/app/backend/services/synisense/shield/audit_log.py` | `6a49b41fb9cc6ac45e6b5a68142a54a001e62954cf4bcbc30d2479ad571e3b34` | 191 | backend_code |
| 9 | `/app/backend/services/synisense/shield/brief_synthesizer.py` | `87dae261d454d2c6f4eaeeb4153bd69325a839784062437f48b6e3a243e871d2` | 164 | backend_code |
| 10 | `/app/backend/services/synisense/shield/canonical.py` | `ad5b1206ba66419cc501ece1b1c5389540f7df190b6c735a56c5aff2954abe82` | 191 | backend_code |
| 11 | `/app/backend/services/synisense/shield/client.py` | `6bb2426ab5129f97faad7f1e6fbe81b5556beed43ab56a99aaeb403d0e2679b5` | 249 | backend_code |
| 12 | `/app/backend/services/synisense/shield/deidentifier.py` | `6da2f511898a56e1b78c08e3a2619d9c239aa7287060e00b5988ce677e7f5657` | 686 | backend_code |
| 13 | `/app/backend/services/synisense/shield/fluency_synthesizer.py` | `6799f55b9323f38d3b25c7cdf3362d2b0a2b42814bdf058823f65cec4ae7ccd7` | 236 | backend_code |
| 14 | `/app/backend/services/synisense/shield/llm_router.py` | `af225e954c03e1d9e4f754cc616081446e8d2f771e45292e3b0e44d16ef379c4` | 232 | backend_code |
| 15 | `/app/backend/services/synisense/shield/perception_router.py` | `e85fa7e95f01530c5f959c4fbf3b767d69c184771a6b741074cd7ced05937e4e` | 147 | backend_code |
| 16 | `/app/backend/services/synisense/shield/trust_receipt.py` | `086af1886a519749be3ce16b14b85c9511e43f869930d0760d72dba82f6dc50e` | 133 | backend_code |
| 17 | `/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py` | `3b2735a1c57ea466f57882c2650132d56bf5ec96a06ee4b36911daef37ce8ae8` | 383 | backend_test |
| 18 | `/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py` | `7f0c1be2ce52c1d7ff59a7dd68719d04fbff3f77c87e45cd8ec8b8d8510a4d7b` | 456 | backend_test |
| 19 | `/app/backend/tests/invariants/test_phase_7_stage_b_3_wizard.py` | `5e3b89e83fb9574220d06227c896360ce03568ca37d0426cf73d7abff155de97` | 285 | backend_test |
| 20 | `/app/backend/tests/test_no_direct_llm_calls_outside_shield.py` | `6ae182e6a9c5a7749e2488c5cd6e8acbd117025b9a129cc8a7dfcdcb9d9fbd78` | 131 | backend_test |
| 21 | `/app/backend/tests/test_perception_router.py` | `ef66108f1a54dbff460f585fba526e577ff17f572ccc5e9f8bcf47f6e0c3d99b` | 31 | backend_test |
| 22 | `/app/docs/close_reports/answer_fluency.md` | `15f980f82f3ee06166331176f1006d749945503ddbd928468be6004dbec2c425` | 324 | close_report |
| 23 | `/app/docs/close_reports/commercial_cut_2026_07_06.md` | `bbf14900c7e51514e8be687597a5b046e445dc8fbc7db4f8ec8c853a62f20d90` | 162 | close_report |
| 24 | `/app/docs/close_reports/machine_readable_registry.md` | `16828d6ca21e3ead41c4dfaa85443cee364e8e8b461e72b293c5ec5b6a9b9b64` | 192 | close_report |
| 25 | `/app/docs/close_reports/phase_7_stage_b_2.md` | `c46186b173d813bdbdca82e98a3a13618d2a2e30aca4ceebd89503fdafb18a21` | 353 | close_report |
| 26 | `/app/docs/close_reports/phase_7_stage_b_3.md` | `ea12517cec7deee48818a097e942d08601fda5a0f381e215a7df2c508c801c30` | 225 | close_report |
| 27 | `/app/docs/close_reports/phase_8_b_1.md` | `b6d5c7a1ea0aaffa7b2a27dc31d96fd8c64f1ff071caf75913ffe6dde6c3f1fe` | 252 | close_report |
| 28 | `/app/docs/close_reports/phase_8_b_2.md` | `1b4d703d81dad6e80ba1d396ea3668ae29f06180d2eb47e75420e08b383ee580` | 283 | close_report |
| 29 | `/app/docs/close_reports/phase_8_b_3.md` | `a31b5a9d43c0563140a73762789f765390187052ebd4e24b47d9bb6a528f7215` | 176 | close_report |
| 30 | `/app/docs/close_reports/phase_8_b_4.md` | `21d2f5193cfb53fbb3ec2c35f293e78f7bd535f446a969137b4bad8758fdb3b8` | 339 | close_report |
| 31 | `/app/docs/close_reports/phase_8_b_5a.md` | `c48672b4562f330129396ef3b90aaffdfb45f6c2714a671e4aaee2953a7c8baf` | 540 | close_report |
| 32 | `/app/docs/close_reports/phase_8a_lite.md` | `bf4ba9a94f250abad61d33a842bdedf2e7c8571a3fe61b1d3323c25601dbe888` | 151 | close_report |
| 33 | `/app/docs/close_reports/production_housing_ph_r1.md` | `dac521b771f6a68de67f8734e1c27075b25cd6c8621ccdb641320cf0db381201` | 316 | close_report |
| 34 | `/app/docs/close_reports/registry_population.md` | `0399957c8c685da8e7a693b23b8a3952ced1764f67a44f7a5813b968ce93b2e7` | 252 | close_report |
| 35 | `/app/docs/lift_manifest.json` | `10e02bf410edddd07c7b9fab251c1c35591a6bfb232ccc7621466b2ace8c576c` | 1449 | config |
| 36 | `/app/docs/rule2_accounting.json` | `a98ccbbb8049ea38ffcff0a47f4559b20e8d5f9e5863234fe1121284da758b04` | 371 | config |
| 37 | `/app/docs/governance/registry_doctrine_v1.md` | `0bfe65c47e2c55f35e2a860fec405c05b8ed32b3473bcb63a0a259fb810ab471` | 173 | doctrine |
| 38 | `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_4.md` | `ce5206c9e244fe58edb6824f785077c1c835bdf3f5b347f6a4fb98c036212524` | 341 | mandate |
| 39 | `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md` | `a1eae555affed0cbb18cac3e2b5a695e1834d961258b298470714cdbbfbbdaef` | 359 | mandate |
| 40 | `/app/docs/mandates/RMS_UI_Specification_v2_2.md` | `d681c6cd399dd5691d7516015f5fe12d1251414efef6290bb008658c22e40cda` | 222 | mandate |
| 41 | `/app/memory/ORCHESTRATOR_CONTINUITY.md` | `961eea6305ac75458a24f70efe7d46848ef32aedd436e5d1d0ad34eecc91370f` | 277 | memory |
| 42 | `/app/memory/PHASE_STATE.md` | `c099927020bf9d44e006535c8ae6f4aabb5af698e4bd82f96fc81d6ae56fa1ee` | 192 | memory |
| 43 | `/app/memory/PRD.md` | `29f0fd998a99b34457eb68d5eb34990f8b7d1c9f0e602222e58aacf19dfc8257` | 399 | memory |
| 44 | `/app/docs/production_housing/promotion_audit_v0.md` | `ae558f248ed40d7bd2d9a404851b6b7a74f4dfcec5ebc5ac48be09948b559e5c` | 129 | production_housing |
| 45 | `/app/docs/stage_a_proposals/answer_fluency.md` | `363c0ee55d6c0c9f97b01237f7597f8ea2fe458efe8c40ac7b11a2c4d0c0c49e` | 339 | proposal |
| 46 | `/app/docs/stage_a_proposals/machine_readable_registry_stage_a.md` | `a4c2642ccc1db3fac391540c18ef583112b1cd19d82b02dd141b28d84b85068f` | 388 | proposal |
| 47 | `/app/docs/stage_a_proposals/opportunity_briefs.md` | `39061210811943e21a5d1f68da99d356430e0a3bd7d52dc4829ba5fc373d8ab6` | 395 | proposal |
| 48 | `/app/docs/stage_a_proposals/phase_7_stage_a.md` | `e2bfe36e2e61025fe417d1cd2de3e91cf4c88fdcb745d3c5f0028ef795fa98ce` | 807 | proposal |
| 49 | `/app/docs/stage_a_proposals/phase_7_stage_b_2.md` | `c515a71486abef1ad40e0c44d9f32cbceeb9027f1e7a3e59ae07e809defc3718` | 272 | proposal |
| 50 | `/app/docs/stage_a_proposals/phase_7_stage_b_3.md` | `040c4099aa031ddb4b8133ac64f301457e6bdafc13ad12cf5c58fb1ba90f4698` | 323 | proposal |
| 51 | `/app/docs/stage_a_proposals/phase_8.md` | `78db65d82e12b62de4198f081cd60c7f1818052d9b88d81077691c2e6c9bc96c` | 536 | proposal |
| 52 | `/app/docs/stage_a_proposals/production_housing_ph_r1.md` | `4c456c29a09b0c20b3920654028e26f23e0aae3aa3af96df9c824f63938d5461` | 426 | proposal |
| 53 | `/app/docs/stage_a_proposals/registry_population_stage_a.md` | `63d78ca5451a7a0e019a2231d9e59c054312f02c9cea3ed68580988295705e59` | 549 | proposal |
| 54 | `/app/docs/stage_a_proposals/sequencing_harness_stage_a.md` | `04da5080d3c573359cb446198483c63d1972497a627089d4ab5842907da5f84a` | 333 | proposal |
| 55 | `/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md` | `942c9f73cacddfc262fa1c032f9d03de37bec1209ae573c0ff0c19eafa54c83f` | 273 | proposal |
| 56 | `/app/docs/recon/repo_recon_2026.md` | `e49cfc01b0abdf031d53af40d31bbe5160d318a12a266d20ee0e03c9b39f170d` | 352 | recon |
| 57 | `/app/docs/registry/function_promise_registry_v0.md` | `598a7ad4d326dd5c0fc003fe8091a52fd215fb63e76d5c04befd1aa4c25584b0` | 306 | registry |
| 58 | `/app/docs/registry/machine/registry.yaml` | `708ddec778390ed62a2d7e07c6fc7d7c8e252f060723a32ffcf0fc36d1f835d9` | 2015 | registry |
| 59 | `/app/docs/requirements/operating_values_v1.md` | `a6c4a455175ef37dc71362aea2e41b2ce406baaf9a1c77b3f0f1326e0aa608ee` | 132 | requirement |
| 60 | `/app/docs/rulings/answer_fluency_af_e1_to_e4.md` | `e3872bd2d16c85c2d0e696bf527fe881065814fae659ed8341cf5fc1b8cf62ab` | 175 | ruling |
| 61 | `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md` | `91532c04cae050ea85e6b25f3d56d0b0db1c611b3c39450529b69fbe53e35bf2` | 155 | ruling |

## Section 3 — Topic Index (anchors only; no paraphrase)

Each entry is `file:line` where the topic anchor appears. Verbatim excerpts live in `excerpts/by_topic.md`.

### T1 — Shield role & positioning (per doctrine)

- `/app/docs/governance/registry_doctrine_v1.md:109`

### T2 — Shield-mediated model invocation (Sonnet 4.6 via Shield, rung classification)

- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/requirements/operating_values_v1.md:20`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:19`

### T3 — Fluency synthesizer via Shield (`synisense.shield.fluency_synthesizer`)

- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/registry/machine/registry.yaml:413`
- `/app/docs/registry/machine/registry.yaml:421`
- `/app/docs/registry/machine/registry.yaml:452`
- `/app/backend/services/synisense/shield/fluency_synthesizer.py:55`
- `/app/backend/services/service_1/composed_conclusion.py:92`
- `/app/backend/routers/service_1.py:41`
- `/app/backend/routers/service_1.py:290`

### T4 — Brief synthesizer via Shield (`synisense.shield.brief_synthesizer`)

- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/machine/registry.yaml:429`
- `/app/docs/registry/machine/registry.yaml:437`
- `/app/backend/services/synisense/shield/brief_synthesizer.py:46`
- `/app/backend/services/opportunity_briefs/generator.py:11`
- `/app/backend/services/opportunity_briefs/generator.py:38`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:19`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:55`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:101`

### T5 — Mechanical fallback arms (verbatim per registry rows)

- `/app/docs/registry/function_promise_registry_v0.md:52`
- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/machine/registry.yaml:113`
- `/app/docs/registry/machine/registry.yaml:425`
- `/app/docs/registry/machine/registry.yaml:441`
- `/app/docs/requirements/operating_values_v1.md:20`

### T6 — Cost classification & rung-4 accounting

- `/app/docs/registry/function_promise_registry_v0.md:72`
- `/app/docs/registry/function_promise_registry_v0.md:100`
- `/app/docs/registry/function_promise_registry_v0.md:101`
- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/registry/function_promise_registry_v0.md:198`
- `/app/docs/registry/function_promise_registry_v0.md:205`
- `/app/docs/registry/machine/registry.yaml:393`
- `/app/docs/registry/machine/registry.yaml:409`
- `/app/docs/registry/machine/registry.yaml:425`
- `/app/docs/registry/machine/registry.yaml:441`
- `/app/docs/registry/machine/registry.yaml:456`
- `/app/docs/registry/machine/registry.yaml:1423`
- `/app/docs/governance/registry_doctrine_v1.md:109`
- `/app/docs/governance/registry_doctrine_v1.md:111`
- `/app/docs/governance/registry_doctrine_v1.md:115`

### T7 — Behavioural bindings (D-* defect classes touching Shield, if any)

- `/app/docs/governance/registry_doctrine_v1.md:54`
- `/app/docs/governance/registry_doctrine_v1.md:81`
- `/app/docs/governance/registry_doctrine_v1.md:87`
- `/app/docs/governance/registry_doctrine_v1.md:88`
- `/app/docs/governance/registry_doctrine_v1.md:89`
- `/app/docs/governance/registry_doctrine_v1.md:90`
- `/app/docs/governance/registry_doctrine_v1.md:91`
- `/app/docs/governance/registry_doctrine_v1.md:92`
- `/app/docs/governance/registry_doctrine_v1.md:93`
- `/app/docs/governance/registry_doctrine_v1.md:94`
- `/app/docs/governance/registry_doctrine_v1.md:95`
- `/app/docs/governance/registry_doctrine_v1.md:96`
- `/app/docs/governance/registry_doctrine_v1.md:131`
- `/app/docs/governance/registry_doctrine_v1.md:154`
- `/app/docs/governance/registry_doctrine_v1.md:161`
- `/app/docs/governance/registry_doctrine_v1.md:162`
- `/app/docs/governance/registry_doctrine_v1.md:163`
- `/app/docs/governance/registry_doctrine_v1.md:164`
- `/app/docs/governance/registry_doctrine_v1.md:165`
- `/app/docs/governance/registry_doctrine_v1.md:166`
- `/app/docs/governance/registry_doctrine_v1.md:167`
- `/app/docs/governance/registry_doctrine_v1.md:171`
- `/app/docs/registry/function_promise_registry_v0.md:31`
- `/app/docs/registry/function_promise_registry_v0.md:47`
- `/app/docs/registry/function_promise_registry_v0.md:48`
- `/app/docs/registry/function_promise_registry_v0.md:49`
- `/app/docs/registry/function_promise_registry_v0.md:73`
- `/app/docs/registry/function_promise_registry_v0.md:74`
- `/app/docs/registry/function_promise_registry_v0.md:75`
- `/app/docs/registry/function_promise_registry_v0.md:78`
- `/app/docs/registry/function_promise_registry_v0.md:81`
- `/app/docs/registry/function_promise_registry_v0.md:136`
- `/app/docs/registry/function_promise_registry_v0.md:188`
- `/app/docs/registry/function_promise_registry_v0.md:306`

### T8 — Operating Values §1/§10 references to Shield (from operating_values_v1.md)

- `/app/docs/requirements/operating_values_v1.md:9`
- `/app/docs/requirements/operating_values_v1.md:13`
- `/app/docs/requirements/operating_values_v1.md:14`
- `/app/docs/requirements/operating_values_v1.md:15`
- `/app/docs/requirements/operating_values_v1.md:16`
- `/app/docs/requirements/operating_values_v1.md:18`
- `/app/docs/requirements/operating_values_v1.md:20`
- `/app/docs/requirements/operating_values_v1.md:28`
- `/app/docs/requirements/operating_values_v1.md:30`
- `/app/docs/requirements/operating_values_v1.md:44`
- `/app/docs/requirements/operating_values_v1.md:107`
- `/app/docs/requirements/operating_values_v1.md:109`
- `/app/docs/requirements/operating_values_v1.md:111`
- `/app/docs/requirements/operating_values_v1.md:113`
- `/app/docs/requirements/operating_values_v1.md:121`

## Section 4 — Bundle SHA-256 (computed post-archive)

shield_engine_specs.tar.gz  ·  SHA-256: `861af2d4b598959d73f67be48bac9990ca7cb1cd0c45fdb103f89eafb3bafd97`  ·  bytes: **562701**

## Section 5 — Reproduction command

```
cd /tmp && tar -czf shield_engine_specs.tar.gz shield_engine_specs/
sha256sum /tmp/shield_engine_specs.tar.gz
```


---
_Mechanical assembly. No authoring. Standing Rule v3 · Verbatim Doctrine._
