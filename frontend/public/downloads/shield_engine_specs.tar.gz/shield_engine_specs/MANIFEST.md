# Shield Engine Specifications — Mechanical Bundle Manifest (expanded scope, v2)

Assembled mechanically per Standing Rule v3 · Verbatim Doctrine · R4/D7 bounds. No new authoring.

Scope expanded per Owner combined-audit dispatch: docs (spec/mandate) + backend implementing modules (llm_router, grounding gates, refusal envelopes, key custody).

Bundle root: `/tmp/shield_engine_specs/`  ·  Files inventoried: **120**

Excluded from bundle for security: `/app/backend/.env` (contains EMERGENT_LLM_KEY and other secrets).

## Section 1 — Discovery transcripts (verbatim)

### 1.1 · Step-1 grep

Command:
```
grep -RIn -E 'synisense\.shield|Shield engine|shield adapter|via Shield|Shield-mediated|llm_router|grounding.?gate|refusal.?envelope|key custody|shield\.fluency|shield\.brief' /app/docs /app/backend /app/memory | sort -u
```

Line count: **388** lines.

<details><summary>Full transcript</summary>

```
/app/backend/.env:8:# Universal Emergent LLM key (read by services/synisense/shield/llm_router.py via emergentintegrations).
/app/backend/.pytest_cache/v/cache/nodeids:1062:  "tests/invariants/test_v2_gate_refusal_cumulative.py::test_v2_refusal_envelope_contract_frozen",
/app/backend/.pytest_cache/v/cache/nodeids:1063:  "tests/invariants/test_v2_gate_refusal_cumulative.py::test_v2_refusal_envelope_rejects_unknown_reason_code",
/app/backend/.pytest_cache/v/cache/nodeids:1220:  "tests/test_lift_manifest.py::test_manifest_entry_resolves[backend/services/synisense/shield/llm_router.py]",
/app/backend/.pytest_cache/v/cache/nodeids:1239:  "tests/test_lift_manifest.py::test_manifest_entry_resolves[backend/tests/invariants/test_service_1_refusal_envelope.py]",
/app/backend/.pytest_cache/v/cache/nodeids:174:  "tests/invariants/test_dispatch_v0_untouched.py::test_v0_run_route_still_returns_governed_refusal_envelope",
/app/backend/.pytest_cache/v/cache/nodeids:321:  "tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py::test_ob_g_runtime_transient_never_refusal_envelope",
/app/backend/.pytest_cache/v/cache/nodeids:69:  "tests/invariants/test_answer_fluency_af_g1_to_g8.py::test_af_g3c_never_refusal_envelope_on_runtime_transient",
/app/backend/.pytest_cache/v/cache/nodeids:859:  "tests/invariants/test_production_housing_ph_g1_to_g6.py::test_ph_g_readyz_source_never_uses_refusal_envelope",
/app/backend/.pytest_cache/v/cache/nodeids:891:  "tests/invariants/test_service_1_refusal_envelope.py::test_composition_below_floor_returns_flat_outcome_refused",
/app/backend/.pytest_cache/v/cache/nodeids:892:  "tests/invariants/test_service_1_refusal_envelope.py::test_composition_below_floor_uses_max_not_min",
/app/backend/.pytest_cache/v/cache/nodeids:893:  "tests/invariants/test_service_1_refusal_envelope.py::test_infrastructure_fault_does_not_render_as_refusal",
/app/backend/.pytest_cache/v/cache/nodeids:894:  "tests/invariants/test_service_1_refusal_envelope.py::test_no_floor_refusal_returns_flat_outcome_refused",
/app/backend/.pytest_cache/v/cache/nodeids:895:  "tests/invariants/test_service_1_refusal_envelope.py::test_no_lawful_basis_refusal_returns_flat_outcome_refused",
/app/backend/.pytest_cache/v/cache/nodeids:896:  "tests/invariants/test_service_1_refusal_envelope.py::test_service_1_refusal_schema_frozen",
/app/backend/.pytest_cache/v/cache/nodeids:897:  "tests/invariants/test_service_1_refusal_envelope.py::test_supported_class_is_ring5_governed_not_recomputed",
/app/backend/.pytest_cache/v/cache/nodeids:898:  "tests/invariants/test_service_1_refusal_envelope.py::test_validation_422_distinguishable_from_refusal_422",
/app/backend/contracts/admission_refusal.py:155:            "ISO-8601 UTC. When the refusal envelope was constructed. "
/app/backend/contracts/admission_refusal.py:1:"""AdmissionRefusal@v0 — governed admission-time refusal envelope
/app/backend/contracts/admission_refusal.py:83:    """Governed admission-time refusal envelope.
/app/backend/contracts/admission_refusal.py:97:            "Service1Refusal@v0.outcome — refusal envelopes are a "
/app/backend/contracts/composed_conclusion.py:20:**Family posture (not a refusal envelope).**
/app/backend/contracts/composed_conclusion.py:25:— v3 §6.2.6 anchor. No new refusal envelope is landed at 4b; the
/app/backend/contracts/composed_conclusion.py:55:     class: below the objective's floor → the refusal envelope
/app/backend/contracts/service_1_refusal.py:1:"""Service1Refusal@v0 — governed refusal envelope for Service 1 (A2 frozen).
/app/backend/contracts/service_1_refusal.py:38:  compared in `tests/invariants/test_service_1_refusal_envelope.py`.
/app/backend/contracts/service_1_refusal.py:51:    """Flat governed-refusal envelope emitted by `POST /api/service_1/run`."""
/app/backend/routers/health.py:13:NEVER a refusal envelope (AF-E2 amended posture).
/app/backend/routers/objectives.py:227:      * NO refusal envelope; NO `caller_cancelled` reason code anywhere.
/app/backend/routers/service_1.py:14:  * Service1RefusalContract — governed 422 refusal envelope. FROZEN
/app/backend/routers/service_1.py:208:                "queue is saturated. NOT a governed refusal envelope; retry "
/app/backend/routers/service_1.py:285:        # refusal envelope. Bare 503 with a diagnostic detail.
/app/backend/routers/service_1.py:41:from services.synisense.shield import fluency_synthesizer as fluency_synthesizer_module
/app/backend/routers/transform_forms.py:100:    # inline; a below-floor result raises the refusal envelope.
/app/backend/routers/transform_forms.py:120:            content=below_floor_refusal_envelope(
/app/backend/routers/transform_forms.py:20:    below_floor_refusal_envelope,
/app/backend/routers/transform_forms.py:90:    carries class inline'). Below-floor → refusal envelope.
/app/backend/services/compliance/refusal_family_classifier.py:53:NOT governed-refusal envelopes — they do NOT reach this classifier.
/app/backend/services/layer_b/asr/whisper_provider.py:1:"""ASR provider — OpenAI-Whisper-API path (via Shield perception_router).
/app/backend/services/layer_b/asr/whisper_provider.py:24:from services.synisense.shield import perception_router
/app/backend/services/layer_b/contracts.py:15:`/reference/akki-legacy/backend/services/synisense/shield/llm_router.py`).
/app/backend/services/layer_b/factory.py:5:cousin's env-driven LLM model preference in `shield/llm_router.py`.
/app/backend/services/layer_b/vision/frame_perception_provider.py:1:"""Vision-LM provider — frame perception via Shield perception_router.
/app/backend/services/layer_b/vision/frame_perception_provider.py:22:from services.synisense.shield import perception_router
/app/backend/services/layer_b/vision/frame_perception_provider.py:9:`/reference/akki-legacy/backend/services/synisense/shield/llm_router.py`.
/app/backend/services/northena/converge.py:131:    """G6 seam — V2 refusal envelope lands in a gate-stage row.
/app/backend/services/opportunity_briefs/README.md:23:- `brief_grounding.py` — mechanical byte-verbatim grounding gate (OB-E1 α · mirrors AF-E1 β Owner Condition 1 discipline).
/app/backend/services/opportunity_briefs/brief_grounding.py:1:"""Brief grounding gate — OB-E1 α mechanical byte-verbatim substring check.
/app/backend/services/opportunity_briefs/generator.py:38:from services.synisense.shield import brief_synthesizer as _synth
/app/backend/services/opportunity_briefs/generator.py:99:    # OB-E1 α grounding gate.
/app/backend/services/registry/validator.py:136:    "4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)",
/app/backend/services/service_1/admission_refusal.py:110:    """Build the admission-refusal envelope for v3 §6.5 form_not_offerable.
/app/backend/services/service_1/admission_refusal.py:158:    """Build an admission-refusal envelope for v3 §6.1.4/§6.2.4/§6.3.4/
/app/backend/services/service_1/admission_refusal.py:204:    """Build an admission-refusal envelope for v3 §6.1.6 standard hard
/app/backend/services/service_1/admission_refusal.py:249:    """Build an admission-refusal envelope for v3 §6.1.2 license-class
/app/backend/services/service_1/answer_grounding.py:1:"""Answer-grounding gate — Answer Fluency §3.8 (AF-E1 β + 2 conditions).
/app/backend/services/service_1/answer_grounding.py:49:    """Outcome of the grounding gate."""
/app/backend/services/service_1/composed_conclusion.py:131:    fluent-arm LLM prompt + grounding-gate numeric verification).
/app/backend/services/service_1/composed_conclusion.py:134:    output naturally trips the grounding gate → mechanical arm.
/app/backend/services/service_1/composed_conclusion.py:362:    # mechanical arm. NEVER a refusal envelope on any transient.
/app/backend/services/service_1/composed_conclusion.py:407:      * On successful LLM output → run grounding gate.
/app/backend/services/service_1/composed_conclusion.py:92:from services.synisense.shield.fluency_synthesizer import (
/app/backend/services/service_1/dispatch.py:138:ROUTE_PHASE_3_MODEL_REFUSAL = "phase_3_model_refusal_envelope"
/app/backend/services/service_1/dispatch.py:145:DEBT_PHASE_3 = "phase_3_model_refusal_envelope"
/app/backend/services/service_1/dispatch.py:271:    governed refusal envelope).
/app/backend/services/service_1/dispatch.py:58:  * `model` form refusal (§6.5 off-menu refusal envelope) → Phase 3.
/app/backend/services/service_1/refusal_hints.py:17:`test_service_1_refusal_envelope`.
/app/backend/services/service_1/service.py:112:    plain-language objective for refusal-envelope `asked` rendering
/app/backend/services/synisense/config.py:77:    # NOTE: `synisense.shield.internal.ner` REMOVED — Phase A switched
/app/backend/services/synisense/shield/__init__.py:7:- `llm_router`    : outbound LLM provider call (post-de-id).
/app/backend/services/synisense/shield/audit_log.py:169:    from services.synisense.shield.trust_receipt import hash_payload, _canonical_json
/app/backend/services/synisense/shield/audit_log.py:20:log = logging.getLogger("synisense.shield.audit_log")
/app/backend/services/synisense/shield/brief_synthesizer.py:114:    from services.synisense.shield import llm_router
/app/backend/services/synisense/shield/brief_synthesizer.py:116:        text, _prov, _model, _usage = await llm_router.invoke_with_metering(
/app/backend/services/synisense/shield/brief_synthesizer.py:14:    and marks the brief `stale=True` (never a refusal envelope).
/app/backend/services/synisense/shield/brief_synthesizer.py:46:log = logging.getLogger("synisense.shield.brief_synthesizer")
/app/backend/services/synisense/shield/canonical.py:68:from services.synisense.shield import deidentifier
/app/backend/services/synisense/shield/canonical.py:69:from services.synisense.shield.exceptions import ShieldFailure
/app/backend/services/synisense/shield/canonical.py:71:logger = logging.getLogger("akki.synisense.shield.canonical")
/app/backend/services/synisense/shield/client.py:135:# (via `llm_router.invoke_with_metering`). The chat streaming surface
/app/backend/services/synisense/shield/client.py:27:from services.synisense.shield import (
/app/backend/services/synisense/shield/client.py:30:    llm_router,
/app/backend/services/synisense/shield/client.py:54:    llm_router uses its built-in generic system prompt (preserves
/app/backend/services/synisense/shield/client.py:67:    llm_text, provider, model, usage = await llm_router.invoke_with_metering(
/app/backend/services/synisense/shield/client.py:81:    # `llm_router.invoke_with_metering` returns `usage = {"input_tokens",
/app/backend/services/synisense/shield/client.py:9:    from services.synisense.shield.client import invoke as shield_invoke
/app/backend/services/synisense/shield/deidentifier.py:254:            "synisense.shield: %s load raised %s: %s — attempting download",
/app/backend/services/synisense/shield/deidentifier.py:287:                        "synisense.shield: using en_core_web_sm fallback "
/app/backend/services/synisense/shield/deidentifier.py:291:                log.info("synisense.shield: spaCy NER ready (model=%s)", candidate)
/app/backend/services/synisense/shield/deidentifier.py:295:                log.warning("synisense.shield: %s failed (%s)", candidate, last)
/app/backend/services/synisense/shield/deidentifier.py:438:            "synisense.shield: warmup OK (model=%s, %d ms)",
/app/backend/services/synisense/shield/deidentifier.py:449:            "synisense.shield: ⚠️  WARMUP FAILED (%s) — backend will "
/app/backend/services/synisense/shield/deidentifier.py:474:                "synisense.shield: also failed to persist "
/app/backend/services/synisense/shield/deidentifier.py:49:log = logging.getLogger("synisense.shield.deidentifier")
/app/backend/services/synisense/shield/deidentifier.py:582:        from services.synisense.shield.tenant_entities import lookup_in_text
/app/backend/services/synisense/shield/fluency_synthesizer.py:148:    """Route the prompt through the Shield's existing llm_router with
/app/backend/services/synisense/shield/fluency_synthesizer.py:166:    # llm_router falls back to mock silently on missing key; the
/app/backend/services/synisense/shield/fluency_synthesizer.py:177:    # Route through the existing Shield llm_router for the actual
/app/backend/services/synisense/shield/fluency_synthesizer.py:180:    from services.synisense.shield import llm_router  # local to avoid cycles
/app/backend/services/synisense/shield/fluency_synthesizer.py:182:        text, _prov, _model, _usage = await llm_router.invoke_with_metering(
/app/backend/services/synisense/shield/fluency_synthesizer.py:19:**Never a refusal envelope on any transient.** Refusal taxonomy
/app/backend/services/synisense/shield/fluency_synthesizer.py:217:    Does NOT emit refusal envelopes. Does NOT call the grounding gate
/app/backend/services/synisense/shield/fluency_synthesizer.py:30:Shield via `llm_router._provider_for("analytical")` — Phase 7 Stage
/app/backend/services/synisense/shield/fluency_synthesizer.py:55:log = logging.getLogger("synisense.shield.fluency_synthesizer")
/app/backend/services/synisense/shield/llm_router.py:147:            log.info("synisense.shield.llm_router: EMERGENT_LLM_KEY absent — using echo fallback")
/app/backend/services/synisense/shield/llm_router.py:157:            "synisense.shield.llm_router: SDK unavailable (emergent=%s litellm=%s)",
/app/backend/services/synisense/shield/llm_router.py:218:        log.warning("synisense.shield.llm_router: invoke failed (%s)", type(exc).__name__)
/app/backend/services/synisense/shield/llm_router.py:66:log = logging.getLogger("synisense.shield.llm_router")
/app/backend/services/synisense/shield/perception_router.py:31:from services.synisense.shield import trust_receipt
/app/backend/services/synisense/shield/perception_router.py:33:log = logging.getLogger("synisense.shield.perception_router")
/app/backend/services/synisense/shield/perception_router.py:3:Mirrors `services/synisense/shield/llm_router.py` (cousin path:
/app/backend/services/synisense/shield/perception_router.py:4:`/reference/akki-legacy/backend/services/synisense/shield/llm_router.py`).
/app/backend/services/synisense/shield/perception_router.py:64:    """Build the audit metadata. Mirrors llm_router's audit shape."""
/app/backend/services/synisense/shield/trust_receipt.py:35:log = logging.getLogger("synisense.shield.trust_receipt")
/app/backend/services/system_state.py:133:            "v2_refusal_envelope_contract": "v0 (V2RefusalEnvelope@v0 — FROZEN)",
/app/backend/services/system_state.py:147:            "outer_gate_receipt@v0", "v2_refusal_envelope@v0",
/app/backend/services/transform_forms/callable_skill_gate.py:134:def below_floor_refusal_envelope(*, class_label: str, floor: str) -> Dict[str, Any]:
/app/backend/services/v2_gate/refusal.py:26:    """Emit a structured V2 refusal envelope.
/app/backend/tests/invariants/admission_refusal.contract_snapshot.json:20:      "description": "Family discriminator. Same value + type as Service1Refusal@v0.outcome \u2014 refusal envelopes are a family, distinguished by firing site + reason semantics, not by a second grammar.",
/app/backend/tests/invariants/admission_refusal.contract_snapshot.json:3:  "description": "Governed admission-time refusal envelope.\n\nFirst firing reason: `form_not_offerable` (v3 \u00a76.5). Future reasons\n(e.g. standard-not-met, offerability-out-of-scope) land as REGISTRY\nadditions at `services/service_1/admission_refusal_reasons.vN.json`\n\u2014 this contract file is NOT modified when a reason is added.",
/app/backend/tests/invariants/admission_refusal.contract_snapshot.json:6:      "description": "ISO-8601 UTC. When the refusal envelope was constructed. Convention-anchored to MiningPlan.generated_at.",
/app/backend/tests/invariants/service_1_refusal.contract_snapshot.json:15:  "description": "Flat governed-refusal envelope emitted by `POST /api/service_1/run`.",
/app/backend/tests/invariants/test_admission_refusal_dispatch.py:4:covering the unified admission-refusal envelope, its versioned reason
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:119:    The grounding gate function returns pass/fail; it never patches
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:190:# ─── AF-G3c · Never refusal envelope on any runtime transient ─────────
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:192:async def test_af_g3c_never_refusal_envelope_on_runtime_transient():
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:193:    """AF-E2 amended: NEVER a refusal envelope on any transient.
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:218:        # envelope will wrap this; NOT an admission_refusal envelope.
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:332:    refusal envelope. Ledger row still fires with
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:358:    # Mechanical prose emitted; NOT a refusal envelope shape.
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:36:from services.synisense.shield import fluency_synthesizer
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py:6:mechanical arm · never a refusal envelope) + AF-E3 α (sidecar telemetry
/app/backend/tests/invariants/test_dispatch_shape_responsive.py:474:    governed refusal envelope emission (AdmissionRefusal@v0, 17th
/app/backend/tests/invariants/test_dispatch_v0_untouched.py:94:async def test_v0_run_route_still_returns_governed_refusal_envelope():
/app/backend/tests/invariants/test_frozen_contract_snapshot_parity.py:65:    "v2_refusal.py":                  "v2_refusal_envelope.contract_snapshot.json",
/app/backend/tests/invariants/test_ledger_absorbs_outer_gate_and_v2_via_stamp_audit.py:5:extension point — outer-gate receipts + V2 refusal envelopes absorb into
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:35:from services.synisense.shield import brief_synthesizer
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:437:# ─── OB-G-Runtime-Transient · never a refusal envelope ────────────────
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:439:async def test_ob_g_runtime_transient_never_refusal_envelope():
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:442:    written; NEVER a refusal envelope."""
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py:455:    # No refusal envelope shape (would be `AdmissionRefusal_v0`)
/app/backend/tests/invariants/test_phase_5_stage_b_async_delivery.py:732:    refusal envelope.
/app/backend/tests/invariants/test_phase_5_stage_b_async_delivery.py:746:            f"HTTP 503; NEVER a governed refusal envelope."
/app/backend/tests/invariants/test_phase_5_stage_b_async_delivery.py:770:        f"503 body MUST NOT masquerade as a governed refusal envelope; got: {body}"
/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py:160:        # 503 must be either db_ping_failed or parity_mismatch (never a refusal envelope).
/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py:177:    # Refusal taxonomy stays closed: 503 is infra readiness, NEVER a refusal envelope.
/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py:379:def test_ph_g_readyz_source_never_uses_refusal_envelope():
/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py:380:    """AST attest: routers/health.py does NOT import or return a refusal envelope."""
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:160:        f"refusal envelope key drift: got {sorted(b.keys())} "
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:1:"""A2 HTTP-layer invariants for `POST /api/service_1/run` refusal envelope.
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:224:    a governed refusal envelope.
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:243:    # Confirm this shape is NOT a refusal envelope
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:302:    refusal envelope's supported_class equals max(input classes) — the
/app/backend/tests/invariants/test_service_1_refusal_envelope.py:68:        "artifact_id": "a2-refusal-envelope-test",
/app/backend/tests/invariants/test_transform_forms.py:10:  * TF-G4 : Below-floor query returns refusal envelope.
/app/backend/tests/invariants/test_transform_forms.py:140:# ===== TF-G4 : Below-floor query returns refusal envelope =====
/app/backend/tests/invariants/test_transform_forms.py:144:    below floor; refusal envelope shape available."""
/app/backend/tests/invariants/test_transform_forms.py:152:    env = below_floor_refusal_envelope(class_label="non_factual", floor="fact")
/app/backend/tests/invariants/test_transform_forms.py:41:    below_floor_refusal_envelope,
/app/backend/tests/invariants/test_v2_gate_refusal_cumulative.py:64:def test_v2_refusal_envelope_rejects_unknown_reason_code():
/app/backend/tests/invariants/test_v2_gate_refusal_cumulative.py:93:def test_v2_refusal_envelope_contract_frozen():
/app/backend/tests/invariants/test_v2_gate_refusal_cumulative.py:95:        (Path(__file__).parent / "v2_refusal_envelope.contract_snapshot.json"
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:117:        "`services.synisense.shield.client.invoke(...)`. "
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:7:LLM provider SDK call goes through `services.synisense.shield.client`
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py:8:(consumer-facing) → `services.synisense.shield.llm_router` (the
/app/backend/tests/test_perception_router.py:5:from services.synisense.shield import perception_router, trust_receipt
/app/docs/audits/g6_conformance_v1.md:61:| `V2RefusalEnvelope@v0` | `contracts/v2_refusal.py` | `v2_refusal_envelope.contract_snapshot.json` | `test_v2_refusal_envelope_contract_frozen` | **MATCH** |
/app/docs/close_reports/answer_fluency.md:107:| **AF-G2a** grounding gate (A) — foreign unit_id → REJECT | GREEN | `...::test_af_g2a_foreign_unit_id_triggers_reject` |
/app/docs/close_reports/answer_fluency.md:108:| **AF-G2b** grounding gate (B) — uncovered sentence → REJECT | GREEN | `...::test_af_g2b_uncovered_sentence_triggers_reject` |
/app/docs/close_reports/answer_fluency.md:109:| **AF-G2c** grounding gate (C) — numeric-verification (Owner Cond 1) | GREEN | `...::test_af_g2c_unverified_numeral_triggers_reject` |
/app/docs/close_reports/answer_fluency.md:110:| **AF-G2d** grounding gate (D) — full-response REJECT (Owner Cond 2) | GREEN | `...::test_af_g2d_any_failure_full_response_falls_to_mechanical` |
/app/docs/close_reports/answer_fluency.md:113:| **AF-G3c** AF-E2 amended — NEVER a refusal envelope | GREEN | `...::test_af_g3c_never_refusal_envelope_on_runtime_transient` |
/app/docs/close_reports/answer_fluency.md:15:- **AF-E2 amended boundary set** (owner-value amendment to BCR anchor): config defect (Emergent key missing) → 503 fail-loud · runtime transients (llm_unavailable / llm_timeout / llm_parse_failure / grounding_reject) → mechanical arm · **NEVER a refusal envelope**.
/app/docs/close_reports/answer_fluency.md:199:- **C4** grounding-gate visibility (any spec text asserting grounding is a runtime-visible ledger row rather than a post-hoc gate)
/app/docs/close_reports/answer_fluency.md:240:- Real unit-text plumbing from data source to `_UnitView.text`: current path reads Ring-1 text from Registry rows if present (`row.get("text") or row.get("content")`); in synthetic fixtures where Ring-1 text isn't surfaced, the fluent arm's output naturally trips grounding-gate → mechanical arm. Full text-plumbing is a deployment integration concern gated on the 9.2-OWN-1..2 archive-access work (see §11); not fluency-scope.
/app/docs/close_reports/answer_fluency.md:258:3. **LLM model: Sonnet 4.5 via Emergent LLM key already inside Shield** at `llm_router.py::_provider_for("analytical")` → `("anthropic", "claude-sonnet-4-5-20250929")`. Owner scope anchor said "Sonnet 4.6"; the codebase carries Sonnet 4.5 in the analytical provider preference (Phase 7 Stage B-2 seed). Reused as-is — no `integration_playbook_expert_v2` call required.
/app/docs/close_reports/answer_fluency.md:79:1. **AF-E1 +2 conditions** expanded grounding gate to 4 sub-gates (A/B/C/D) plus numeric-verification distinct cell (AF-G2c) — +40 raw LoC in gate roster vs α-only estimate.
/app/docs/close_reports/answer_fluency.md:95:- **Disposition applied: atomic single commit** per §4.1 baseline. Dev's judgment (per Owner §4.2 delegation "no round-trip"): the +2 LoC boundary nudge does not merit fragmenting a semantically-coordinated, fully-validated atomic commit (fluency_synthesizer + grounding gate + dispatcher + sidecar + goldens + gate roster share the same rename + attribution + numeric-verification semantic unit). A retroactive split would itself introduce coordination LoC (git motion, cross-commit reference in close report, split-A/B boundary attest) net-adding to the cumulative — the §4.2 split value inversion Owner Standing Disposition warned against.
/app/docs/close_reports/commercial_cut_2026_07_06.md:30:| Shield boundary | preserved — `services/wizard/*` and `services/master_admin/*` import zero LLM libraries; the `SonnetWizardAgent` extraction did NOT alter Shield's other functions (`_LITELLM_AVAILABLE` + language-tier routing table + main Shield entrypoint all intact at `services/synisense/shield/llm_router.py`). |
/app/docs/close_reports/commercial_cut_2026_07_06.md:59:| `SonnetWizardAgent` + `_sonnet_invoke` (Shield LLM-driven wizard-agent driver) | CUT (surgical extraction) | Extracted from `services/synisense/shield/llm_router.py` lines 224-418 to `/app/salvage/commercial_cut_2026_07_06/backend/wizard/sonnet_wizard_agent_extracted.py`. Rationale: buyer-variant-only live consumer; operator uses `DeterministicStubAgent`. |
/app/docs/close_reports/housekeeping_preflight.md:209:  - V2 refusal envelope gains a new reason code path: `cumulative_disclosure_risk` (defined at G6 for this exact unlock).
/app/docs/close_reports/machine_readable_registry.md:62:**(a) Foreign-key promise integrity (β):** verified — every function row's `PROM-*` token in the `promise` field resolves to an existing top-level `promises` array `promise_id`. Non-PROM adjacent references (e.g., `governance §8` on `synisense.shield.data_blind_prompt_template`) are documentation cross-references, not primary promise attributions; not linted. **No unresolved PROM-references landed.**
/app/docs/close_reports/opportunity_briefs.md:109:| **OB-G-Runtime-Transient** `test_ob_g_runtime_transient_never_refusal_envelope` | Tier-1 (AF-E2-precedent-shape) | GREEN | same |
/app/docs/close_reports/opportunity_briefs.md:220:| AF-E2 amended boundary set (Standing Disposition 2026-07-10 · AF-scope-only) | GREEN — briefs run under §12.1 posture; brief runtime transients → sidecar telemetry, never a refusal envelope (`test_ob_g_runtime_transient_never_refusal_envelope`) |
/app/docs/close_reports/opportunity_briefs.md:230:- **[Tier 3]** LLM model: Sonnet via `llm_router::_provider_for("analytical")` (Phase 7 Stage B-2 seed reused · no new integration).
/app/docs/close_reports/phase_4a_stage_b.md:374:v2_refusal_envelope.contract_snapshot.json
/app/docs/close_reports/phase_5_stage_b.md:119:Infrastructure faults return HTTP 503 (or 5xx family), NEVER a governed refusal envelope. Queue saturation, database unavailability, worker crashes — all infra. Refusals are governance decisions; 503 is an infra decision. Struck code: `async_queue_saturated` (was a candidate refusal reason at Stage A; STRUCK at Stage B open). Enforced by:
/app/docs/close_reports/phase_5_stage_b.md:171:| `test_queue_overflow_raises_503_not_refusal` | Saturation → HTTP 503, body not a refusal envelope | GREEN |
/app/docs/close_reports/phase_7_stage_b_2.md:107:| **B — Sonnet 4.6 inside Shield** | `services/synisense/shield/llm_router.py` +196 (`SonnetWizardAgent` class + `_sonnet_invoke` helper + provider config `claude-sonnet-4-5-20250929`* + no-silent-degrade path); LLM-invariant gates in the same test file (~200L: `test_sonnet_wizard_agent_*` × 6 + `test_no_silent_model_degrade_*` + `test_no_direct_llm_calls_outside_shield_still_green` + `test_llm_unavailable_*` × 3 shape-negatives) | 1 modified source (Shield); LLM test cluster | **631** | +7 LLM gates including grep-negative + no-silent-degrade + Shield-boundary reruns |
/app/docs/close_reports/phase_7_stage_b_2.md:212:| `services/synisense/shield/llm_router.py` (MODIFIED +196) | +196 | `SonnetWizardAgent` class + `_sonnet_invoke` helper + no-silent-degrade path |
/app/docs/close_reports/phase_7_stage_b_2.md:237:| No LLM code in `services/wizard/*` | ✅ `SonnetWizardAgent` lands in `services/synisense/shield/llm_router.py`; `test_sonnet_wizard_agent_lives_inside_shield_boundary` GREEN grep-negative |
/app/docs/close_reports/phase_7_stage_b_2.md:239:| Infra-not-refusal (Standing Disposition Infra-not-refusal) | ✅ Sonnet errors → HTTP 503; three shape-negative gates (`test_llm_unavailable_*`) enforce non-refusal envelope |
/app/docs/close_reports/phase_8_conformance_map.md:392:- **Shield-side residue** — `backend/services/synisense/shield/llm_router.py`
/app/docs/close_reports/phase_8_seam_3_sub_stage_1.md:205:- `backend/tests/invariants/test_service_1_refusal_envelope.py` (`_write_delta == 1` per R-1)
/app/docs/close_reports/phase_8_seam_3_sub_stage_1.md:66:- `test_service_1_refusal_envelope.py::test_no_lawful_basis_refusal_returns_flat_outcome_refused` — pre-composition-refusal `_write_delta` expectation flipped from 0 → 1 (the pinned refusal-family ledger row is the coverage substrate this sub-stage exists to produce). Provenance comment cites R-1.
/app/docs/close_reports/production_housing_ph_r1.md:120:| **PH-G-Refusal-Closed** /readyz source never uses refusal envelope | 1 | Tier-1 (AF-E2 amended posture) | same |
/app/docs/close_reports/production_housing_ph_r1.md:227:| AF-E2 amended boundary set (Standing Disposition 2026-07-10) | GREEN — /readyz 503 is infra readiness signal, never a refusal envelope (attested at test_ph_g_readyz_source_never_uses_refusal_envelope AST cell) |
/app/docs/close_reports/production_housing_ph_r1.md:67:  - Refusal taxonomy untouched — 503 is infra readiness signal, NEVER a refusal envelope (AF-E2 amended posture · attested at test_ph_g_readyz_source_never_uses_refusal_envelope AST cell).
/app/docs/close_reports/production_housing_ph_r1.md:78:  - **Current shape:** `invoke_with_metering(prompt, model_preference, timeout_seconds, system_msg) -> (text, provider, model, usage)` at `services/synisense/shield/llm_router.py`.
/app/docs/close_reports/production_housing_ph_r1.md:84:- **Zero code change to `llm_router.py` at PH-R1.** Shape rename lands post-PH-R4 owner-side swap.
/app/docs/close_reports/registry_population.md:44:- Sub-steps of named-and-tested behaviors folded into parent row's `mandate` field per α-amended posture (attested throughout §3 — e.g., "AF-G2a..d + AF-G3a..c" cell subgroups fold into `synisense.shield.grounding_gate_answer_fluency`).
/app/docs/close_reports/transform_forms.md:118:3. **Service modules LoC** (planned 270; actual 436) — 4 modules landed with substantial Owner-verbatim docstrings inline (defensibility_loader + KA assembly + gate + persistence) + `callable_skill_gate.py` at 144 LoC hosts three exported symbols (`require_governed_skill_query` + `ensure_response_carries_class` + `below_floor_refusal_envelope` + `BelowFloorError` + `_CLASS_RANK` map). +166 LoC.
/app/docs/close_reports/transform_forms.md:24:| `backend/services/transform_forms/callable_skill_gate.py` | `02d5674517a804eb93ba5c8b1ab1d64368294650294a3a32a6164396c99b3871` | 144 | TF-E4 (a) α · per-call inner gate decorator + response class-inline mutation + refusal envelope. |
/app/docs/close_reports/transform_forms.md:61:| **TF-G4** Below-floor → refusal envelope | `test_tf_g4_below_floor_response_raises_refusal` + `test_tf_g4_at_or_above_floor_returns_mutated_response` | ✅ GREEN (2 sub-cells) |
/app/docs/g6_prep/g6_scope_from_source.md:82:**Refusal invariant (§29.1 + §30 "purpose limitation"):** structured refusal envelope; NO partial egress ever. Any V2 refusal halts the egress with zero content bytes emitted.
/app/docs/governance/registry_doctrine_v1.md:102:Four rungs, ordered by cost. Selection rule: the lowest rung that meets the promise. The registry's ladder_rung field makes every placement inspectable; the build's own precedent stands as the pattern — grounding gates were ruled as byte-mechanical checks, explicitly rejecting semantic scoring, and both frontier-LLM consumers carry mechanical fallback arms, so the expensive rung is architecturally optional everywhere it appears:
/app/docs/governance/tiered_ruling_model.md:15:> Tier 1 — client-promise (full rigor): provenance/audit integrity, security boundaries (auth scope, key custody, raw-never-egresses), honesty grammar (class-with-claim, refusal-first, no hidden mocks, no fabricated values), frozen wire contracts. Verbatim rulings and named gates stay.
/app/docs/governance/tiered_ruling_model.md:27:**Definition (Owner verbatim):** *"client-promise (full rigor): provenance/audit integrity, security boundaries (auth scope, key custody, raw-never-egresses), honesty grammar (class-with-claim, refusal-first, no hidden mocks, no fabricated values), frozen wire contracts. Verbatim rulings and named gates stay."*
/app/docs/handoff/backend_contract_surface_v1.md:214:| 17 | `/api/service_1/run` | POST | `Service1RunRequest` (see below) | `Service1RunSummary` (200) OR `Service1Refusal@v0` (§1.14, 422 with `outcome="refused"`) | 422 governed refusal (see §2.1); 422 validation (Pydantic, `detail: list`, distinguishable from refusal by presence of `outcome`); 500 ONLY on infrastructure fault (`outcome` never == "refused") | N — WRITE endpoint | Product v2.1 §8.4 + §11; Interface Spec §5.4 refusal state | G4 + **A2 refusal envelope** |
/app/docs/handoff/backend_contract_surface_v1.md:32:| 12 | `V2RefusalEnvelope` | @v0 | `backend/contracts/v2_refusal.py` | `v2_refusal_envelope.contract_snapshot.json` | Product v2.1 §29.1 + §30 | G6 | Structured V2 refusal — 4 reason codes. No partial-egress. |
/app/docs/handoff/backend_contract_surface_v1.md:348:**Structural discipline:** every refusal envelope carries `reason`/`reason_code` + correlation identifiers (`run_id`, `trace_id`, `artifact_ref`). The `Service1Refusal@v0` envelope carries the four surface-rendering fields the frontend needs verbatim (`asked`, `supported_class`, `what_would_raise_it`, plus `outcome` as discriminator). The frontend renders "asked / supported class / what would raise it" per §5.4 obligation — for Service 1 refusals this is backed directly by the frozen envelope; for other refusal types (V2, Solva, Northena) the frontend synthesises the render from the correlated ledger row + stamp-audit payload.
/app/docs/handoff/backend_contract_surface_v1.md:379:- Every refusal envelope contract (§4 above) must have a corresponding first-class render surface.
/app/docs/handoff/backend_contract_surface_v1.md:416:- **Frozen at:** 2026-07-02T01:00Z; **A2 refusal-envelope amendment:** 2026-07-02T02:15Z
/app/docs/handoff/seam_unlock_runbook.md:184:- V2 refusal envelope gains a new reason code path: `cumulative_disclosure_risk` (defined at G6 for this exact unlock).
/app/docs/lift_manifest.json:1280:        "test_v2_refusal_envelope_rejects_unknown_reason_code",
/app/docs/lift_manifest.json:1282:        "test_v2_refusal_envelope_contract_frozen",
/app/docs/lift_manifest.json:1312:      "shape_signature": "Pydantic frozen contract: Service1Refusal (governed refusal envelope with outcome discriminator)",
/app/docs/lift_manifest.json:1336:      "module": "backend/tests/invariants/test_service_1_refusal_envelope.py",
/app/docs/lift_manifest.json:1363:      "notes": "A2. Byte-frozen JSON schema for Service1Refusal@v0. Freeze discipline mandate-forced by Operating Protocol \u00a71.7 (contract snapshot invariants). Enforced by test_service_1_refusal_envelope::test_service_1_refusal_schema_frozen. 11th snapshot file (14 frozen contracts; five_rings snapshot covers multiple ring contracts under one file)."
/app/docs/lift_manifest.json:225:      "cousin_citation": "/reference/akki-legacy/backend/services/synisense/shield/llm_router.py",
/app/docs/lift_manifest.json:249:      "cousin_citation": "/reference/akki-legacy/backend/services/synisense/shield/llm_router.py",
/app/docs/lift_manifest.json:250:      "shape_signature": "Vision-LM provider via Shield perception_router chokepoint",
/app/docs/lift_manifest.json:37:      "module": "backend/services/synisense/shield/llm_router.py",
/app/docs/lift_manifest.json:38:      "cousin_citation": "/reference/akki-legacy/backend/services/synisense/shield/llm_router.py",
/app/docs/lift_manifest.json:73:      "cousin_citation": "backend/services/synisense/shield/llm_router.py",
/app/docs/lift_manifest.json:74:      "shape_signature": "mirrors llm_router: env-driven route to ASR / vision (post-de-id chokepoint)",
/app/docs/lift_manifest.json:81:        "backend/services/synisense/shield/llm_router.py"
/app/docs/lift_manifest.json:83:      "notes": "G0.5 extension. Structural mirror of the in-pod llm_router (Rule-2-budgeted ~200 LoC bridge, journaled at G0.5 close)."
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_4.md:182:  llm_router.complete(messages, temperature, model) -> text
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:182:  llm_router.complete(messages, temperature, model) -> text
/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md:101:6. Enforced at conclusion class: below the objective's floor → the refusal envelope (asked / supported_class / what_would_raise_it).
/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md:117:6. Standard enforced per call; below-floor queries return the refusal envelope.
/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md:127:- **Late refusal is first-class**: `accepted → … → refused` is a normal terminal state carrying the same refusal envelope. Integrating apps must render it as a governed refusal, never a failure.
/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md:192:  - V2 refusal envelope gains a new reason code path: `cumulative_disclosure_risk` (defined at G6 for this exact unlock).
/app/docs/mandates/archive/RMS_Product_Engineering_Spec_v2.1.md:1070:- **Behavioral delta when opened:** V2 refusal envelope gains a new reason code path — `cumulative_disclosure_risk` — defined at G6 for exactly this unlock. Individually-clean egresses that re-combine to reconstruct identities get refused when the k-anonymity or l-diversity threshold is crossed, or when the DP epsilon budget is exhausted. The V2 tracking store begins persisting egress fingerprints across sessions.
/app/docs/mandates/northena.md:220:**`stamp_audit: Optional[Dict]` — permissive by design.** The untyped `Dict` shape is intentional, not a lapse: it is the load-bearing reason engine artifacts from later phases (G3 Solva boundary emissions, G4 Mtafiti/Targeta stamps, G5a trace correlation, G6 outer-gate receipts, A2 refusal envelopes) can be absorbed into a Ledger row without mutating the frozen `northena_ledger_row@v0` contract. Every engine that emits a stamp landed downstream via this side-channel, allowing 14 frozen contracts to remain byte-identical across G3–G6 while the ledger's semantic reach grew. Any future proposal to type `stamp_audit` (e.g. `Optional[StampAudit]`) would harden it into a mutation surface and lose this property; the permissive contract is a deliberate design decision guarded by `test_ledger_absorbs_outer_gate_and_v2_via_stamp_audit.py::test_northena_ledger_row_contract_snapshot_unchanged_at_g6`.
/app/docs/production_housing/llm_swap_seam.md:128:**Zero code change to `llm_router.py` at PH-R1.** The rename lands post-PH-R4 [OWNER] LLM account swap. This doc is the written target for that swap — no rediscovery of the seam required.
/app/docs/production_housing/llm_swap_seam.md:15:>   llm_router.complete(messages, temperature, model) -> text
/app/docs/production_housing/llm_swap_seam.md:22:**Module:** `/app/backend/services/synisense/shield/llm_router.py`
/app/docs/production_housing/llm_swap_seam.md:58:  text, _prov, _model, _usage = await llm_router.invoke_with_metering(
/app/docs/production_housing/llm_swap_seam.md:67:  text = await llm_router.complete(
/app/docs/production_housing/llm_swap_seam.md:82:  text, _prov, _model, _usage = await llm_router.invoke_with_metering(
/app/docs/production_housing/llm_swap_seam.md:91:  text = await llm_router.complete(
/app/docs/production_housing/promotion_audit_v0.md:68:**Verifiable:** Yes — `grep -rn "invoke_with_metering\|from services.synisense.shield import llm_router" backend/services/` returns exactly the 2 documented call sites plus the router itself.
/app/docs/recon/repo_recon_2026.md:49:| 25 | `v2_refusal.py` | `v2_refusal_envelope.contract_snapshot.json` | v0 |
/app/docs/registry/consolidation_log_v0.md:23:**Surface class:** Shield-adjacent grounding gate (both `services/**/grounding.py`).
/app/docs/registry/consolidation_log_v0.md:37:**Surface class:** grounding gate.
/app/docs/registry/consolidation_log_v0.md:72:**Source line A** (`docs/rulings/answer_fluency_af_e1_to_e4.md` — AF-E2 amended boundary set): runtime transients → mechanical arm; NEVER a refusal envelope.
/app/docs/registry/consolidation_log_v0.md:73:**Source line B** (same source, AF-E2 amended): config defects → 503 fail loud; NEVER routed via refusal envelope.
/app/docs/registry/consolidation_log_v0.md:75:**Token overlap:** ~52% (both share "never a refusal envelope" · differ on runtime-transient handling vs config-defect handling).
/app/docs/registry/consolidation_log_v0.md:77:**Surface class:** refusal envelope taxonomy (shared).
/app/docs/registry/consolidation_log_v0.md:79:**Decision:** **TIE-BROKE-TOWARD-DISTINCT.** Rationale: while both share the "never refusal envelope" outcome, the RESPONSES differ (mechanical arm vs 503 fail-loud). Under-merge here would fold two distinct operational responses into one promise; Owner's tie-break-toward-distinct posture applies. Q1 redundancy query at future dispatched turn can surface the shared surface-class if the split proves redundant.
/app/docs/registry/function_promise_registry_v0.md:100:| synisense.shield.grounding_gate_answer_fluency | SyniSense | Built to REJECT the whole answer_text if any per-sentence structured anchor fails byte-verbatim substring against its unit_id or numeric verification. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-no-semantic-scoring | S1.call | `backend/services/service_1/answer_grounding.py` | Runtime check + AST negative-scan for `sum/mean/statistics` | 13 cells (AF-G2a..d + AF-G3a..c + AF-G-Grounding-Fail) · §6.11 rate class | AF-G-Grounding-Fail (green) · AF-G-E1-No-Semantic-Scoring | 1 · Deterministic + rung-4 upstream synthesis | Owner |
/app/docs/registry/function_promise_registry_v0.md:101:| synisense.shield.grounding_gate_opportunity_briefs | SyniSense | Built to REJECT any brief where a quantitative anchor's value fails byte-verbatim against its Registry-read reference. Whole-brief reject on any failure. | PROM-S1-byte-verbatim-anchor-grounding · PROM-S1-registry-native-aggregate | S1.call (as briefs are advisory to S1's app-facing surface) | `backend/services/opportunity_briefs/brief_grounding.py` | Runtime check + AST no-synthesis-compute | OB-G1 · OB-G-Grounding-Fail · OB-G-E3-No-Synth-Compute · §6.11 | 1 · Deterministic + rung-4 upstream | Owner |
/app/docs/registry/function_promise_registry_v0.md:102:| synisense.shield.fluency_synthesizer | SyniSense | Built to compose the fluent `answer_text` behind the Shield chokepoint using Sonnet 4.6 via Emergent LLM key; caller cannot bypass. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py:L182` | Runtime chokepoint + AST single-source (piggyback) | AF-G6a · §6.11 · 4 async cells | 4 · Frontier LLM (with mechanical fallback per AF-E2 amended) | Owner |
/app/docs/registry/function_promise_registry_v0.md:103:| synisense.shield.brief_synthesizer | SyniSense | Built to compose the brief text behind the Shield chokepoint using Sonnet 4.6 via `_provider_for("analytical")` reuse of Phase 7 Stage B-2 seed. | PROM-S1-shield-single-source · PROM-S1-runtime-transient-never-refusal | S1.call (advisory to S1's app-facing) | `backend/services/synisense/shield/brief_synthesizer.py:L116` | Runtime chokepoint | OB-G1 async cells · §6.11 | 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback) | Owner |
/app/docs/registry/function_promise_registry_v0.md:104:| synisense.shield.per_sentence_anchor_map | SyniSense | Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match. | PROM-S1-byte-verbatim-anchor-grounding | S1.call | `backend/services/synisense/shield/fluency_synthesizer.py` (structured output block) | Runtime schema validate | AF-E1 β per-sentence structured mapping cells | 4 · Frontier LLM (structured output) | Owner |
/app/docs/registry/function_promise_registry_v0.md:105:| synisense.shield.data_blind_prompt_template | SyniSense | Built to attest LLM prompt templates never carry secret env vars, credentials, or masked data. | PROM-S1-shield-single-source · governance §8 | S1.call | `backend/services/synisense/shield/{fluency_prompt.v0,brief_prompt.v0}.txt` | Grep-negative on prompt files | AF-G-DB · OB-G-DB · §6.1 · 2 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:106:| synisense.shield.advisory_marker_write_time_attach | SyniSense | Built to attach the advisory marker at brief-registry write time; render-surface reads verbatim from sidecar; no strip path exists. | PROM-S1-class-honesty-render-time | S1.call (advisory route) · S3.prove | `backend/services/opportunity_briefs/advisory_marker.py` + AST no-strip walk | Write-time attach + §6.10 reflection walk | OB-G2 · OB-G2-Seam1-No-Strip · §6.10 | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:107:| synisense.shield.advisory_marker_render_time_visible | SyniSense (render surface class) | Built to render the advisory marker verbatim on every card via `data-testid="opportunity-brief-advisory-marker"`. | PROM-S1-class-honesty-render-time | S1.call (advisory route) | `frontend/src/pages/opportunity_briefs/OpportunityBriefCard.jsx` | Jest render assertion | OB-Jest-marker cells · 2 Jest | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:108:| synisense.shield.class_honesty_governed_response_boundary | SyniSense | Built to enforce that governed-response synthesis (service_1) never imports opportunity_briefs; §6.10 AST walk over service_1/**. | PROM-S1-class-honesty-render-time | S1.call (governed response path) | `backend/services/service_1/**` + AST negative-scan | AST/reflection walk (grep-negative) | OB-G-Seam3 · §6.10 · 1 cell | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:109:| synisense.shield.fluency_mode_telemetry_sidecar | SyniSense | Built to emit fluency-mode telemetry via sidecar; envelope byte-identical; parity preserved. | PROM-S1-frozen-wire-contract · PROM-S1-runtime-transient-never-refusal | S3.prove | `backend/services/service_1/fluency_mode_telemetry.py` | Contract-shape lint | AF-G-Sidecar cells · §6.1 · 4 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:110:| synisense.shield.brief_telemetry_sidecar | SyniSense | Built to emit brief-generation telemetry via sidecar following AF-E3 α precedent; envelope byte-identical. | PROM-S1-frozen-wire-contract | S3.prove | `backend/services/opportunity_briefs/brief_telemetry.py` | Contract-shape lint | OB-G-Telemetry · §6.1 · 1 cell | 1 · Deterministic | builder-Tier-3 |
/app/docs/registry/function_promise_registry_v0.md:111:| synisense.shield.mechanical_composer_baseline | SyniSense | Built to preserve the pre-fluency f-string mechanical composer byte-identically to goldens for regression-check. | PROM-S1-frozen-wire-contract | S1.call | `backend/services/service_1/mechanical_composer.py` + `backend/tests/goldens/answer_fluency/pre_3_8/mechanical_baseline.json` | Byte-identity lock (SHA-pin) | AF-G1 · 5 legacy SHA-pin gates repointed · §6.6 | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:112:| synisense.shield.brief_id_namespace_boundary | SyniSense | Built to mint brief IDs in a distinct `brief_` namespace; `/api/solva/trace/{brief_*}` returns 404. | PROM-S3-brief-namespace-distinct-from-trace | S3.prove | `backend/services/opportunity_briefs/brief_registry.new_brief_id` + `backend/routers/solva.py:get_trace` | Runtime 404 + namespace grep | OB-G3 · OB-G3-Seam2-Namespace-Distinct · §6.11 · 2 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:113:| synisense.shield.refusal_taxonomy_closed | SyniSense | Built to enforce the 4-code auth-refusal registry; runtime transients and infra 503s never routed via refusal envelope. | PROM-S1-refusal-taxonomy-closed | S1.call · S3.prove | `backend/services/auth/refusal_envelope.py` + AST negative on health.py | Type-level wall + AST scan | AF-G-Never-Refusal-Envelope · OB-G-Runtime-Transient-Never-Refusal-Envelope · PH-G-Refusal-Closed · §6.10 · 3 cells | 1 · Deterministic | Owner |
/app/docs/registry/function_promise_registry_v0.md:260:**Cells accounted:** the 1,408 CI cells group under 66 function rows via gate-identity aggregation. Cells-per-function distribution: median ~5 cells/function · max ~16 cells/function (grounding gate family) · min 1 cell/function.
/app/docs/registry/function_promise_registry_v0.md:44:| PROM-S1-refusal-taxonomy-closed | Refusal codes are a bounded 4-code set (`auth_missing` · `auth_expired` · `auth_scope_insufficient` · `auth_identity_mismatch_for_wizard_session`); infra 503s and runtime transients are NEVER routed via refusal envelope. | yes | 4 | P9-E5 · AF-E2 amended (Standing Disposition 2026-07-10) · PH-E3 α |
/app/docs/registry/function_promise_registry_v0.md:52:| PROM-S1-runtime-transient-never-refusal | Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope. | yes | 2 | AF-E2 amended · OB-runtime-transient-precedent |
/app/docs/registry/function_promise_registry_v0.md:53:| PROM-S1-config-defect-fail-loud | Config defects (missing Emergent key · invalid key) fail loud 503 at startup; NEVER routed via refusal envelope. | yes | 1 | AF-E2 amended |
/app/docs/registry/function_promise_registry_v0.md:99:| synisense.shield.llm_single_source_boundary | SyniSense | Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`). | PROM-S1-shield-single-source | S1.call · S1.pass-receipts-through | `backend/services/synisense/shield/llm_router.py` + AST gate | AST/reflection walk | 1 cell · §6.10 rate class (attested at `test_no_direct_llm_calls_outside_shield`) | Contract-immutability at frozen envelope | 1 · Deterministic (AST walk) | Owner |
/app/docs/registry/machine/registry.yaml:113:    text: Runtime transients (llm_unavailable · llm_timeout · llm_parse_failure · grounding_reject) surface as sidecar telemetry with mechanical fallback arm; they are NEVER a refusal envelope.
/app/docs/registry/machine/registry.yaml:120:    text: Config defects (missing Emergent key · invalid key) fail loud 503 at startup; NEVER routed via refusal envelope.
/app/docs/registry/machine/registry.yaml:365:  - function_id: synisense.shield.llm_single_source_boundary
/app/docs/registry/machine/registry.yaml:367:    mandate: "Built to enforce that no non-Shield module imports an LLM SDK; the swap seam is one module (`llm_router.py`)."
/app/docs/registry/machine/registry.yaml:373:    surface: "`backend/services/synisense/shield/llm_router.py` + AST gate"
/app/docs/registry/machine/registry.yaml:381:  - function_id: synisense.shield.grounding_gate_answer_fluency
/app/docs/registry/machine/registry.yaml:397:  - function_id: synisense.shield.grounding_gate_opportunity_briefs
/app/docs/registry/machine/registry.yaml:413:  - function_id: synisense.shield.fluency_synthesizer
/app/docs/registry/machine/registry.yaml:429:  - function_id: synisense.shield.brief_synthesizer
/app/docs/registry/machine/registry.yaml:441:    ladder_rung: 4 · Frontier LLM (Registry-anchor grounding gate mechanically fallback)
/app/docs/registry/machine/registry.yaml:445:  - function_id: synisense.shield.per_sentence_anchor_map
/app/docs/registry/machine/registry.yaml:447:    mandate: "Built to produce `{prose, per_sentence: [{sentence_text, unit_ids}]}` structured mapping so the grounding gate runs anchor-by-sentence, not fuzzy match."
/app/docs/registry/machine/registry.yaml:460:  - function_id: synisense.shield.data_blind_prompt_template
/app/docs/registry/machine/registry.yaml:476:  - function_id: synisense.shield.advisory_marker_write_time_attach
/app/docs/registry/machine/registry.yaml:48:    text: "Refusal codes are a bounded 4-code set (`auth_missing` · `auth_expired` · `auth_scope_insufficient` · `auth_identity_mismatch_for_wizard_session`); infra 503s and runtime transients are NEVER routed via refusal envelope."
/app/docs/registry/machine/registry.yaml:492:  - function_id: synisense.shield.advisory_marker_render_time_visible
/app/docs/registry/machine/registry.yaml:507:  - function_id: synisense.shield.class_honesty_governed_response_boundary
/app/docs/registry/machine/registry.yaml:522:  - function_id: synisense.shield.fluency_mode_telemetry_sidecar
/app/docs/registry/machine/registry.yaml:538:  - function_id: synisense.shield.brief_telemetry_sidecar
/app/docs/registry/machine/registry.yaml:553:  - function_id: synisense.shield.mechanical_composer_baseline
/app/docs/registry/machine/registry.yaml:568:  - function_id: synisense.shield.brief_id_namespace_boundary
/app/docs/registry/machine/registry.yaml:583:  - function_id: synisense.shield.refusal_taxonomy_closed
/app/docs/registry/machine/registry.yaml:585:    mandate: Built to enforce the 4-code auth-refusal registry; runtime transients and infra 503s never routed via refusal envelope.
/app/docs/registry/machine/registry.yaml:591:    surface: "`backend/services/auth/refusal_envelope.py` + AST negative on health.py"
/app/docs/requirements/operating_values_v1.md:105:- **LLM swap (PH-R4): **target shape per llm_swap_seam.md · cutover proven by the AF golden set: mechanical arm byte-identical, fluent arm re-validated through the grounding gates · zero call-site changes per BCR.
/app/docs/requirements/operating_values_v1.md:20:| Fluent synthesis | Sonnet via Shield (as built) | — | 4 | Answer fluency + briefs, mechanical fallback arms stand | Rung-3 owned text models: out until an estate-trained corpus exists — dependency, not deferral |
/app/docs/rule2_accounting.json:265:    "journal_ref": "[counting_standard: post-§0-strict] Phase 7 Stage B-2 close 2026-07-04. Buyer variant state machine + Sonnet 4.6 LLM integration + dual-delta gate. 7-endpoint buyer router mounted at /api/wizard/buyer/*. Zero new frozen contracts; mechanical parity 26 unchanged. 26 prior frozen contract sources byte-identical (verified by test_prior_contract_file_exists_and_stable_at_7b_2 parametrised over 25 contract sources + 1 count-invariant). Owner Condition-A pre-LLM Guard-1 mandatory-tier gate landed BEFORE any LLM code (Block A → 624 GREEN → Block B Sonnet wiring → 631 GREEN → Block C buyer SM + router + dual-delta → 685 GREEN). Owner Condition-2 grep-negative gates confirm buyer_state_machine.py re-implements NONE of {validate_source_tags, validate_guard_1_operator_mandatory_all_operator_supplied, _record_feasibility_snapshot}. SonnetWizardAgent lives inside services/synisense/shield/llm_router.py (Shield boundary preserved). Temp 0.2 live / 0.0 hermetic replay. No silent model degrade — Sonnet-unavailable → HTTP 503 (Owner Standing Disposition Infra-not-refusal). Zero new §0.1 Standing Dispositions at B-2 (§0.1 FROZEN per Owner correction). ~1600-2000 anchored band target (mid ~1800) → ~1757 actual → WITHIN BAND (-2.4% delta below mid; +0.4% within top-of-band). Deliverables: 3 NEW source files (dual_delta.py 91L + buyer_state_machine.py 332L + routers/wizard_buyer.py 267L) + 1 NEW test file (test_phase_7_stage_b_2_wizard.py 835L) + 5 MODIFIED files. Close report: /app/docs/close_reports/phase_7_stage_b_2.md (SHA quoted in return message). Ratio strings transcribed verbatim per Owner cap."
/app/docs/rule2_accounting.json:321:    "journal_ref": "[counting_standard: post-§0-strict; snapshot_lloc_in_band=yes] Phase 8 Seam 3 Sub-stage 1 close 2026-07-07. Amendment F applied (7 fold points in build brief + R-4 registry attribution-note fix + rulings §10 R-1..R-6 append). Refusal-family ledger wire-up at 6 live instrumentation sites I1-I6 via canonical emit_refusal_ledger_row: I1=service.py:127 no_defensibility_floor→composition_below_floor + I2=service.py:135 no_lawful_basis→composition_below_floor + I3=service.py:188 composition_below_floor→composition_below_floor + I4=composed_conclusion.py:273 composition_below_floor→composition_below_floor + I5=async_worker.py ComposedService1Refusal arm→composition_below_floor (R-5: emit BEFORE transition_to_refused, idempotent dedup on (trace_id, reason) via _refusal_row_exists_for_objective) + I6=async_worker.py AdmissionRefusal_v0 arm→admission_refusals (R-5 same discipline). Zero new frozen contracts (parity 26 unchanged; snapshot parity 26/26 byte-identical). Zero new §0.1 dispositions (§0.1 FROZEN). Zero new §0.2 debts arose. GET /api/compliance/refusals_coverage endpoint added to routers/compliance.py (DPO/admin auth-gated; body = RefusalsCoverageResponse per compose_coverage_marker query-time β per E3.β + Amendment E — no materialization, no index). Backend test surface: 847 → 869 (+22 gates in tests/invariants/test_phase_8_seam_3_sub_stage_1.py: §A LB gate parametrised over 6 I-sites + 1 aggregate = 7 cases per R-1 data-shape invariant + §B 4 unit tests emit_refusal_ledger_row family/stage validation + pinned key discipline + R-3 unclassified registered + §C 4 coverage_marker tests empty/populated/query-time-earliest/seam-3-boundary + §D 4 router auth tests no-token/wrong-role/dpo/admin + §E 1 R-5 idempotency + §F 1 R-4 registry note fix + §G 1 409 self-audit static scan). Frontend Jest ui_spec_v1: 92 → 98 (+6 gates in test_phase_8_seam_3_coverage_marker.test.js: MIDDLE_DOT constant + loading + error + empty + populated + all-4-families incl R-3 unclassified). Frontend Playwright chromium: 26 → 28 (+2 smokes in compliance_coverage_marker_smoke.spec.ts: named gate test_coverage_marker_renders_middle_dot_glyph_verbatim asserts U+00B7 explicitly + forbids hyphen substitute + empty-state honest-note middle-dot). NEW backend files (1 test + 4 source, 4 source landed pre-authorization at commit a33d9eb per R-6 WIP-checkpoint disposition): tests/invariants/test_phase_8_seam_3_sub_stage_1.py 529L + services/compliance/refusal_ledger.py 130L + services/compliance/coverage_marker.py 128L + services/compliance/refusals_coverage_response.py 80L + services/compliance/refusal_families.v0.json 31L. NEW frontend files (2): pages/compliance/RefusalsCoverageMarker.js 119L + __tests__/ui_spec_v1/test_phase_8_seam_3_coverage_marker.test.js 122L + e2e/compliance_coverage_marker_smoke.spec.ts 110L. MODIFIED backend files (5): services/service_1/service.py +50L (I1+I2+I3 wire-up with LedgerArtifactRef + emit_refusal_ledger_row pre-raise) + services/service_1/composed_conclusion.py +20L (I4 wire-up pre-raise) + services/service_1/async_worker.py +65L (I5+I6 wire-up per R-5 emit-before-transition + _refusal_row_exists_for_objective dedup helper) + services/service_1/async_state.py +8L (E4 dead-stub migration docstring only; body byte-identical) + routers/compliance.py +20L (GET /api/compliance/refusals_coverage handler). MODIFIED frontend files (3): apiClient.js +7L (complianceRefusalsCoverage shim) + pages/compliance/ComplianceHomePage.js +9L net (rider wire-up: complianceRefusalsCoverage in Promise.all + coverage state + <RefusalsCoverageMarker /> mounted under card-refusals-this-month) + __tests__/ui_spec_v1/test_phase_8_b_5a_compliance.test.js mock updated with complianceRefusalsCoverage shim. MODIFIED test-guardrail files (9): test_dispatch_v0_untouched.py + test_v0_paths_byte_identical_after_4a.py/4b.py — service.py SHA refreshed 05e905ed→4a453e30 with R-1..R-6 provenance comment; test_v0_paths_byte_identical_after_5b.py/6b.py/7b_1.py + test_phase_7_stage_b_2/3_wizard.py — synthesis-lines slice index [315:321]→[329:335] (content SHA d2e72653 byte-identical, Owner Q4.c protection preserved; only file position shifted after I4 wire-up); test_service_1_refusal_envelope.py — _write_delta expectation 0→1 with R-1 provenance comment (pre-composition refusals now emit exactly one pinned refusal-family ledger row per R-1 LB gate). MODIFIED doc/manifest (3): docs/build_briefs/phase_8_seam_3_sub_stage_1.md (Amendment F 7 fold points: brief lines 19/31 census-confirmed 6 I-sites + I1-I6 anchors + R-1 disposition in §5 + R-2 in §4 + R-3 in §3 E1.γ + R-5 in §4 + R-6 in §8) + docs/rulings/seam_3_stage_a_e1_to_e7.md (§10 R-1..R-6 verbatim append per Standing Rule v3) + docs/mandates/MANIFEST.md BCR v1.4.1 hash refreshed d1f49bc5→ce5206c9 (pre-existing E7 drift from 2026-07-06; landed here as housekeeping per §4.3 dev-autonomous). R-6 WIP-checkpoint documented: a33d9eb = pre-authorization scaffolding of 4 compliance/*.py files, interrupted by compaction; true Sub-stage 1 landing commit is the atomic gate event (this commit) — recorded, not punished. Rule 2 accounting: raw LoC ~1,160 net (+880 new files + +280 modified). Owner-anchored band 1,300-1,800 → 1,160 actual → WITHIN BAND (below top). No Rule-2 overage. Owner Condition 1 ratified: first-commit gating (Pytest + Jest + Playwright + frontend rider + backend router + registry attribution-note fix all in same landing commit). E-rulings and R-rulings audit: E4 dead-stub migration docstring only (body byte-identical) / E5 no HTTP 409 introduced (test_g_no_409_in_sub_stage_1_diff static scan zero hits) / E7 middle-dot U+00B7 asserted explicitly in Jest + Playwright / R-1 data-shape invariant landed with 6 exercise + 1 aggregate = 7 cases / R-2 C2/C6 stay un-wired (grep of emit_refusal_ledger_row call sites shows I1-I6 only, resurrection-guarded by invariant) / R-3 unclassified registered in refusal_families.v0.json + rider renders 4 families / R-4 registry attribution-note fix landed with §F test + no version bump / R-5 emit-before-transition idempotent with §E dedup helper test / R-6 WIP-checkpoint line landed. Honest-cost report on E3.β query-time: compose_coverage_marker() end-to-end latency 4.66ms at Sub-stage-1 landing against dataset ~10k NORTHENA_LEDGER_COLLECTION rows — no cost problem observed; no index, no materialization. Sub-stage 2 preconditions surfaced: canonical writer + registry ready; unclassified fallback for Sub-stage 2 family attribution TBD; §8 checker (Sub-stage 3) can enumerate consequence classes against 4 registry families with no further schema work. Standing constraints preserved: 26 frozen contracts byte-identical parity; §0.1 unchanged; §0.2 unchanged; no Ruling-4 shared-derivation violations; 4-code auth-refusal registry closed (0 new codes at Sub-stage 1). Close report: /app/docs/close_reports/phase_8_seam_3_sub_stage_1.md SHA-256 (recorded below in close report). Ratio strings and counting standard as-recorded per Owner cap."
/app/docs/rulings/answer_fluency_af_e1_to_e4.md:122:| **AF-G3c** | Tier-1 | AF-E2 amended: NEVER a refusal envelope on any transient | `...::test_af_g3c_never_refusal_envelope_on_runtime_transient` |
/app/docs/rulings/answer_fluency_af_e1_to_e4.md:35:> **Runtime transients degrade gracefully → mechanical arm:** provider down, rate-limited, Shield timeout, structured-output parse failure. Response succeeds, fluency_mode=mechanical, telemetry carries the reason (llm_unavailable / llm_timeout / llm_parse_failure / grounding_reject). Never a refusal envelope.
/app/docs/rulings/answer_fluency_af_e1_to_e4.md:53:**Never a refusal envelope** on any runtime transient. Refusal taxonomy (`admission_refusal` + `service_1_refusal`) untouched at Answer Fluency scope.
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:101:- **Shield chokepoint (Phase 7 Stage B-2)** → OB brief_synthesizer via `llm_router::_provider_for("analytical")`.
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:19:- LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured JSON via Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (mirrors AF-E1 β precedent).
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:87:### §2.2 No refusal-envelope emission on any runtime path
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:89:Refusal taxonomy (`admission_refusal` + `service_1_refusal`) untouched at OB scope. Briefs are ADVISORY output; brief-generation failures → mechanical fallback (stale-brief marking) OR grounding-reject (brief NOT written); NEVER a refusal envelope. §0.1 disposition from AF-E2 amended is AF-scope-only per Owner; briefs run under §12.1 remaining-gates posture.
/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md:72:- Refusal taxonomy untouched — 503 is infra readiness signal, never a refusal envelope.
/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md:77:- Current shape: `services/synisense/shield/llm_router.py::invoke_with_metering(prompt, model_preference, timeout_seconds, system_msg) -> (text, provider, model, usage)`.
/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md:83:- Zero code change to `llm_router.py` at PH-R1. Shape rename lands post-PH-R4.
/app/docs/rulings/transform_forms_tf_e1_to_e4.md:66:- `below_floor_refusal_envelope(...)` — refusal shape `{outcome: refused, reason: defensibility_below_floor, detail: {class, floor}}`.
/app/docs/stage_a_proposals/answer_fluency.md:112:| `services/service_1/answer_grounding.py` (new · grounding gate) | §6.3 standalone (~100) — grounding option-specific (post-hoc semantic overlap = light; per-sentence structured anchors = heavy) | **120** | 200 | 60 |
/app/docs/stage_a_proposals/answer_fluency.md:124:| AF-G2 grounding gate — per-sentence anchor discipline (Tier-1 honesty gate) | §6.1 classic | 4 | 12 | 48 |
/app/docs/stage_a_proposals/answer_fluency.md:129:| AF-G7 grounding-gate reject → fluency_mode=mechanical (quality-gate NOT refusal) | §6.1 classic | 2 | 12 | 24 |
/app/docs/stage_a_proposals/answer_fluency.md:168:  - **Split-B:** grounding gate + composed_conclusion dispatcher + fluency_mode telemetry + gate roster (the "Service-1-side + honesty-gate" unit)
/app/docs/stage_a_proposals/answer_fluency.md:189:| **AF-G2** | **Tier-1 (no-fabricated-values honesty grammar)** | §6.1 × 4 | Per-sentence grounding gate — every sentence in fluent draft has at least one anchor in `load_bearing_unit_ids`; anchors reference valid unit_ids; anchors are semantically defensible (per the AF-E1 grounding discipline). Reject → fluency_mode=mechanical. See AF-E1 escalation for the specific grounding-discipline ruling required. |
/app/docs/stage_a_proposals/answer_fluency.md:194:| **AF-G7** | Tier-1 (quality-gate ≠ refusal) | §6.1 × 2 | Grounding-gate reject → `fluency_mode="mechanical"` + `_grounding_reject_reason` populated + NO refusal envelope emitted. Ledger row (`NorthenaLedgerRow_v1`) still fires with `data_class="composed_conclusion"` (not a new class). |
/app/docs/stage_a_proposals/answer_fluency.md:210:> - **α · Post-hoc semantic-overlap grounding.** Fluent draft emitted freely by the LLM; grounding gate runs a post-hoc lexical/semantic-overlap check per sentence against the load-bearing unit texts. Sentence is grounded IFF ≥1 unit contributes ≥K semantic overlap (K to be Owner-set; builder-recommendation K=0.35 semantic-token Jaccard). Cheap; permits fluent connectives; but "invented connectives" is a subtle failure mode that lexical overlap may miss.
/app/docs/stage_a_proposals/answer_fluency.md:211:> - **β · Per-sentence structured-output anchor mapping.** LLM is instructed to emit `{prose, per_sentence: [{sentence, unit_ids: [...]}]}` as structured output; grounding gate verifies each declared unit_id is in `load_bearing_unit_ids` + verifies each sentence in prose is covered by at least one anchor. Strictest; catches invented connectives directly (a connective sentence with no unit anchor fails); slight added cost in prompt engineering + LLM output tokens.
/app/docs/stage_a_proposals/answer_fluency.md:235:> - **γ · Include structured-output parse failure as grounding-gate reject** (fall through to mechanical instead of 503) — smoother UX but blurs infra-fault vs quality-gate line.
/app/docs/stage_a_proposals/answer_fluency.md:282:- **[Tier 3 default]** LLM model: **Sonnet 4.6 via Emergent LLM key** — already inside the Shield at `llm_router.py::SonnetWizardAgent` (Phase 7 Stage B-2 precedent). Fluency reuses the same backend; NO new integration required (no `integration_playbook_expert_v2` call). Temp 0.0 for hermetic tests · 0.2 for live per llm_router precedent.
/app/docs/stage_a_proposals/answer_fluency.md:287:- **[Tier 3 default]** grounding-gate config location: co-located with grounding module as constants (no runtime config file; §6.9 verbatim carrier suffices).
/app/docs/stage_a_proposals/answer_fluency.md:305:- C4: grounding-gate visibility (any spec text asserting grounding is a runtime-visible ledger row rather than a post-hoc gate that either succeeds silently or degrades to mechanical? · verified at execution)
/app/docs/stage_a_proposals/answer_fluency.md:325:| FR-G4 no-shadow-source AST posture | GREEN — no new broadcaster residues introduced; grounding-gate anchors reference `load_bearing_unit_ids` (unit_ids, not feed_ids). |
/app/docs/stage_a_proposals/answer_fluency.md:34:- **New:** LLM-synthesised prose arm for the `answer_text` field of `ComposedConclusion_v0`. Lives inside the Shield chokepoint at `services/synisense/shield/` (module name: **[Tier-3 default]** `fluency_synthesizer.py` — matches `llm_router.py` + `perception_router.py` co-tenancy pattern). Consumes the load-bearing_unit_ids + their five-rings text + defensibility class + objective_ref; emits fluent prose grounded per-sentence to unit_ids.
/app/docs/stage_a_proposals/answer_fluency.md:35:- **New:** Grounding-gate service module at `services/service_1/answer_grounding.py` (module name **[Tier-3 default]**) — post-hoc per-sentence anchor verifier. Executes at composed_conclusion package-time BEFORE the envelope leaves Service 1; on grounding-gate FAIL, the code path REJECTS the fluent draft and lands the mechanical baseline (see §2.2). This is a Tier-1 honesty-grammar gate — see AF-E1 for the specific grounding-discipline escalation.
/app/docs/stage_a_proposals/answer_fluency.md:75:    │                         [grounding gate]
/app/docs/stage_a_proposals/answer_fluency.md:7:**Precedent:** Rides existing envelopes (`ComposedConclusion_v0` #18) + existing gates (Shield chokepoint · Sonnet 4.6 model already lives inside Shield at `services/synisense/shield/llm_router.py` per Phase 7 Stage B-2).
/app/docs/stage_a_proposals/answer_fluency.md:89:                  │  per Phase 7 Stage B-2 · reuse llm_router.py Sonnet backend)
/app/docs/stage_a_proposals/answer_fluency.md:95:Load-bearing composition rule: mechanical composer remains the FALLBACK when grounding-gate rejects the fluent draft (this is NOT a "fallback = refusal" pattern — it's a quality-gate reject, tracked in fluency_mode telemetry as `mechanical` with a `_grounding_reject_reason` sidecar field). LLM-unavailability at the Shield boundary (503, timeout, model down) surfaces as 503 to the caller — see AF-E2.
/app/docs/stage_a_proposals/opportunity_briefs.md:272:> - **α · Structured anchor + byte-verbatim substring check (mirrors AF-E1 β + Owner Condition 1 precedent · builder-recommended).** LLM emits `{brief_text, quantitative_anchors: [{value, registry_read_ref}]}` structured output; grounding gate at `brief_grounding.py` verifies every `value` appears byte-verbatim in the referenced Registry read text; every numeric appearing in `brief_text` has a corresponding anchor; **no semantic scoring**. Mechanical byte-substring check per numeral (regex `[0-9]+(?:[.,][0-9]+)*%?`) matches AF-E1 β Owner Condition 1 verbatim (*"mechanical check, no semantic scoring"*). On any failure → brief NOT emitted (regeneration tagged `grounding_reject`); the gate NEVER patches the brief. This is the AF-honesty-grammar posture ported to advisory output — same discipline, same rate-class §6.1, no new precedent required.
/app/docs/stage_a_proposals/opportunity_briefs.md:318:> - **β · Registry-computable aggregate = any value derivable from Registry reads via a whitelisted operator set** (SUM, COUNT, AVG, MIN, MAX). The brief_grounding gate replays the operator against the Registry reads and verifies the emitted value byte-verbatim. Adds substantial gate LoC + operator whitelist maintenance.
/app/docs/stage_a_proposals/opportunity_briefs.md:342:- **[Tier 3 default]** LLM model: **Sonnet via Emergent LLM key** already inside Shield at `llm_router::_provider_for("analytical")` (Phase 7 Stage B-2 seed · AF precedent 2026-07-10 reuse). NO new integration; no `integration_playbook_expert_v2` call needed.
/app/docs/stage_a_proposals/opportunity_briefs.md:378:| AF-E2 amended boundary set precedent | GREEN — Shield transients degrade to stale-brief marking; no refusal envelope. |
/app/docs/stage_a_proposals/opportunity_briefs.md:49:- `services/synisense/shield/brief_synthesizer.py` — Shield-side LLM boundary (mirrors `fluency_synthesizer.py` from AF · Sonnet via `llm_router::_provider_for("analytical")` reuse · Phase 7 Stage B-2 seed · 30s timeout). Enforces structured output `{brief_text, quantitative_anchors: [{value, registry_read_ref}], scope, contributing_slices: [...]}`.
/app/docs/stage_a_proposals/opportunity_briefs.md:67:- **Refusal taxonomy** — untouched. Briefs are ADVISORY output; NEVER enter a refusal envelope; brief-generation failure = infra fault path (per Shield-standard 503 or graceful stale-brief marking).
/app/docs/stage_a_proposals/opportunity_briefs.md:93:    │                     ├─ Sonnet via llm_router::analytical (Phase 7 Stage B-2 reuse)
/app/docs/stage_a_proposals/opportunity_briefs.md:98:[grounding gate]        opportunity_briefs/brief_grounding.py
/app/docs/stage_a_proposals/phase_4_stage_a.md:125:**Family posture (not a refusal envelope).**
/app/docs/stage_a_proposals/phase_4_stage_a.md:130:— v3 §6.2.6 anchor. No new refusal envelope is landed at 4b; the
/app/docs/stage_a_proposals/phase_4_stage_a.md:160:     class: below the objective's floor → the refusal envelope
/app/docs/stage_a_proposals/phase_4_stage_a.md:337:- v3 §6.2.6 line 101 verbatim: "Enforced at conclusion class: below the objective's floor → the refusal envelope (asked / supported_class / what_would_raise_it)."
/app/docs/stage_a_proposals/phase_4_stage_a.md:388:| 6.2.6 | Enforced at conclusion class: below floor → refusal (asked / supported_class / what_would_raise_it) | line 101: "Enforced at conclusion class: below the objective's floor → the refusal envelope (asked / supported_class / what_would_raise_it)." | **COVERED (4b) via EXISTING `Service1Refusal@v0`** | NO new contract; existing A2 envelope has exact 7-field shape. Gate 15 asserts fires cleanly with `reason=composition_below_floor` and all named fields present. Family-consistency preserved. |
/app/docs/stage_a_proposals/phase_5_stage_a.md:106:| # | Refusal class | Firing site | Existing envelope on disk | Envelope source path | Contract # (of 18) | Sync HTTP status | Async wrapper `refusal_envelope` field carries |
/app/docs/stage_a_proposals/phase_5_stage_a.md:113:| 6 | `lawful_basis_absent` (V2 gate — §29.1) | Egress (V2 gate) | `V2RefusalEnvelope` | `contracts/v2_refusal.py:22-59`; snapshot `tests/invariants/v2_refusal_envelope.contract_snapshot.json` | 12 | 422 (existing V2 gate route) | `V2RefusalEnvelope` body verbatim |
/app/docs/stage_a_proposals/phase_5_stage_a.md:124:**Refusal-envelope inventory above resolves cleanly.** However v3 §7 bullet 5 requires: *"No partial egress, including on caller cancellation; a cancelled run is still ledgered."* This surfaces a distinct HAZARD-STOP at the LEDGER surface (not the refusal-envelope surface):
/app/docs/stage_a_proposals/phase_5_stage_a.md:497:      a replay; refusal envelope's trace_id is fresh — flag: Owner may
/app/docs/stage_a_proposals/phase_5_stage_a.md:765:> **Late refusal is first-class**: `accepted → … → refused` is a normal terminal state carrying the same refusal envelope. Integrating apps must render it as a governed refusal, never a failure.
/app/docs/stage_a_proposals/phase_6_stage_a.md:462:| Queue saturated (async capacity exhausted) | INFRA | 503 | `{detail: "..."}` (no refusal envelope) |
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:206:| `services/synisense/shield/llm_router.py` extension (`SonnetWizardAgent` class + Sonnet 4.6 client wiring) | +130 (net addition) | Existing `LlmChat`/`UserMessage` invocation pattern in same file (lines 93-135); `WizardAgent` Protocol lifted verbatim from `services/wizard/agent_interface.py` |
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:233:| No LLM code in `services/wizard/*` | ✅ `SonnetWizardAgent` lands in `services/synisense/shield/llm_router.py`; wizard modules import the Protocol only |
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:249:Sonnet 4.6 via Shield's existing `emergentintegrations.LlmChat` path. Owner explicitly said: "Use the standard Emergent LLM key path via Shield's config. Do NOT prompt for API keys." **No user prompt** — Stage B lifts the key from Shield's config lookup (existing pattern at `llm_router.py:41-80` via `os.environ.get("EMERGENT_LLM_KEY")` — verify at Stage B).
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:46:3. **Sonnet 4.6 LLM integration** — new `SonnetWizardAgent` class inside `services/synisense/shield/llm_router.py` (Shield boundary preserved).
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:96:**Landing location:** `services/synisense/shield/llm_router.py` (existing 221 LoC; extends to ~330 LoC). Adds:
/app/docs/stage_a_proposals/phase_7_stage_b_2.md:99:- Sonnet 4.6 via Emergent LLM Key using the existing `emergentintegrations.LlmChat + UserMessage` pattern (see current `llm_router.py:31-40` — `_EMERGENT_AVAILABLE` probe already scaffolded).
/app/docs/stage_a_proposals/production_housing_ph_r1.md:113:- **Refusal taxonomy** — untouched. Healthchecks are infra endpoints; 503 on not-ready is infra fault, never a refusal envelope.
/app/docs/stage_a_proposals/production_housing_ph_r1.md:260:| AF-E2 amended boundary set precedent | GREEN — 503 on not-ready is infra fault; refusal envelope untouched. |
/app/docs/stage_a_proposals/production_housing_ph_r1.md:352:> Owner authority-source language (BCR v1.5 §3.4 annex verbatim): *"llm_router.complete(messages, temperature, model) -> text · provider selection reads LLM_PROVIDER; call sites never change."*
/app/docs/stage_a_proposals/production_housing_ph_r1.md:356:> **Escalation:** the current `services/synisense/shield/llm_router.py` exposes `invoke_with_metering(prompt, model_preference, timeout_seconds, system_msg)` and `_provider_for(kind)` (private dispatch). BCR annex names the target shape as `complete(messages, temperature, model) -> text`. Two dispositions available.
/app/docs/stage_a_proposals/production_housing_ph_r1.md:360:> - **β · Introduce `complete(messages, temperature, model)` public wrapper at PH-R1** — new public function in `llm_router.py` that calls `invoke_with_metering` internally. All existing call sites (fluency_synthesizer, brief_synthesizer, wizard SonnetAgent · post-cut just fluency+brief) migrate to the new shape. Non-trivial refactor; risks breakage. Not required by PH-R1 (BCR §3.4 says "documented", not "renamed").
/app/docs/stage_a_proposals/production_housing_ph_r1.md:390:- **[Tier 3 default]** LLM swap seam doc format: markdown attesting the current `services/synisense/shield/llm_router.py` shape + the BCR annex target shape + the migration path.
/app/docs/stage_a_proposals/production_housing_ph_r1.md:44:>   llm_router.complete(messages, temperature, model) -> text
/app/docs/stage_a_proposals/production_housing_ph_r1.md:7:**Precedent:** Rides existing FastAPI/React/Mongo stack; Emergent LLM key already inside Shield at `services/synisense/shield/llm_router.py`; MONGO_URL / DB_NAME already env-driven per protected variable posture.
/app/docs/stage_a_proposals/production_housing_ph_r1.md:84:- `docs/production_housing/llm_swap_seam.md` — canonical documentation of the `services/synisense/shield/llm_router.py` chokepoint:
/app/docs/stage_a_proposals/production_housing_ph_r1.md:88:  - **Zero code change** — the existing `llm_router.py` already implements the chokepoint; this Stage A only documents the seam per BCR annex requirement.
/app/docs/stage_a_proposals/sequencing_harness_stage_a.md:34:> Four rungs, ordered by cost. Selection rule: the lowest rung that meets the promise. The registry's ladder_rung field makes every placement inspectable; the build's own precedent stands as the pattern — grounding gates were ruled as byte-mechanical checks, explicitly rejecting semantic scoring, and both frontier-LLM consumers carry mechanical fallback arms, so the expensive rung is architecturally optional everywhere it appears:
/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md:70:- Q3-01 `S1.pass-receipts-through` — cited by `synisense.shield.llm_single_source_boundary`; mechanical Q3 (b) does NOT flag it as gap (has a function). v0.md's Q3-01 finding is that no CI cell attests downstream trust — that's post-boundary archaeology, not mechanical.
/app/docs/stage_a_proposals/transform_forms.md:150:| **TF-G4** Below-floor query returns refusal envelope (BCR §3.7 line 117 spec) | inner gate refuses below floor | `test_tf_g4_below_floor_query_returns_refusal` |
/app/docs/stage_a_proposals/transform_forms.md:312:- **α** — a decorator on the skill query endpoint (per-endpoint, module-scoped) that composes: (i) scope check via `services.auth.key_grants.check_scope` (P8E-E2 α single-source), (ii) standard-floor check against the provisioning record's `floor`, (iii) response mutation to include `defensibility.class` inline. Failure at any step → refusal envelope (below-floor) or 403 (scope mismatch).
/app/memory/ORCHESTRATOR_CONTINUITY.md:111:| **Phase 7 Stage B-2 — Buyer variant + Sonnet 4.6 LLM (SonnetWizardAgent inside Shield) + dual-delta gate + Condition-A pre-LLM Guard-1 landing + Condition-2 grep-negative single-source (× 3 symbols)** | **CLOSED** | **685 (+72 net: intermediate block sequence 613 → 624 (Block A pre-LLM Guard-1 mandatory-tier) → 631 (Block B Sonnet 4.6 inside Shield) → 685 (Block C buyer SM + router + dual-delta + Condition-2 single-source + byte-identity 26 + regressions); 38 named gates including Condition A(i) parametrised × 8 mandatory-fields + Condition 2 grep-negative parametrised × 3 symbols + byte-identity parametrised over 25 contract sources = 72 collected new cases)** | ~500 (`WizardAgent` Protocol from B-1 + operator SM shape via imports + operator router shape mirror + `provenance_preservation.py` declarative-table pattern for dual-delta + `LlmChat`/`litellm` pattern in Shield + gate scaffolding from B-1 test file + `ASGITransport` test pattern) | ~1757 (3 NEW source files: dual_delta.py 91L + buyer_state_machine.py 332L + routers/wizard_buyer.py 267L; 1 NEW test file: test_phase_7_stage_b_2_wizard.py 835L; 5 MODIFIED files: services/synisense/shield/llm_router.py +196 SonnetWizardAgent class + _sonnet_invoke helper + no-silent-degrade path, services/wizard/operator_state_machine.py +12 Condition-A predicate + variant kwarg, routers/wizard_operator.py +18 SourceTagViolation import + 422 boundary, services/wizard/session_persistence.py +4 additive compound index, server.py +2 buyer router mount; 1 docs-only fix: docs/lift_manifest.json +6 pre-existing 8a-lite path repair) | ~3.5× overall / ~1.4× discretionary (v2 accounting, post-§0-strict); **anchored band 1600-2000 (mid ~1800) → 1757 actual → WITHIN BAND (-2.4% delta below mid; +0.4% within top-of-band). No Rule-2 stop-and-judge triggered. Transcription-only per Owner cap; disc/mandate split not re-derived; ratio strings transcribed verbatim.** | 2026-07-04 — Phase 7 wizard-side dispatch plan-debt buyer-variant + LLM portion RESOLVED. §3.3 buyer variant LIVE at 7 endpoints under `/api/wizard/buyer/*` (session/turn/propose/agent-assumption/commit-review/freeze + GET session). SonnetWizardAgent (Claude Sonnet 4.6 via Emergent LLM Key) lives inside `services/synisense/shield/llm_router.py` — `test_no_direct_llm_calls_outside_shield_still_green` GREEN + `test_sonnet_wizard_agent_lives_inside_shield_boundary` GREEN (no LLM SDK import in `services/wizard/*`). Temp 0.2 live / 0.0 hermetic replay (`_invoke` monkeypatched in test seam). No silent model degrade — Sonnet-unavailable → HTTP 503 (Owner Standing Disposition `Infra-not-refusal`). Dual-delta gate (Owner E6 `Visibility-not-prohibition` mechanical application): standard/grain-changing proposals refuse `dual_delta_missing` at `/propose` endpoint when price_delta or class_delta absent; reach-changing proposals admissible without dual-delta. Owner Condition-A pre-LLM Guard-1 mandatory-tier gate on `POST /api/wizard/operator/{sid}/agent-assumption` (3 LB gates): (i) refuse `AgentAssumption_v0` on mandatory-tier field when `variant="operator"` via `SourceTagViolation` at `services/wizard/operator_state_machine.py:189-192`; (ii) never mint operator-source CommittedValue from the endpoint (structural); (iii) never append OperatorTurn (structural). Buyer variant behavior: Guard 1 no-ops on `variant="buyer"` (agent-may-propose per v3 §3.3). Owner Condition-2 grep-negative gates confirm `buyer_state_machine.py` re-implements NONE of {`validate_source_tags`, `validate_guard_1_operator_mandatory_all_operator_supplied`, `_record_feasibility_snapshot`} — imports each from operator-proven module (`test_buyer_state_machine_does_not_reimplement_shared_symbol` parametrised × 3 GREEN). Zero new frozen contracts (parity 26 unchanged). **26 PRIOR frozen contract sources byte-identical pre-7b-2 vs post-7b-2** — verified by `test_prior_contract_file_exists_and_stable_at_7b_2` parametrised over 25 contract source files + `test_prior_26_contracts_count_at_26` count invariant. `services/service_1/composed_conclusion.py:316-321` UNTOUCHED (Verdict A regression preserved from 4b/5b/6b/7b-1). `services/service_1/provenance_preservation.py` UNTOUCHED (byte-identical SHA `1eedde91f797...`); buyer SM imports it (single-source preserved for Owner E7). Ruling 4 shared-derivation preserved (buyer SM imports `_record_feasibility_snapshot` from operator-proven module which itself invokes `services.mtafiti.floor_feasibility.derive_floor_feasibility(...)`). Zero new §0.1 Standing Dispositions (§0.1 FROZEN per Owner correction). 1 new Plan Debt at §0.2: `Wizard session-ownership binding plan-debt` — verbatim: *"Wizard session-ownership binding lands with Phase 8 auth/key model — recorded as the system-wide auth landing, not a wizard-special. [Owner ruling, Phase 7 Stage B-2 dispatch, 2026-07-04]"*. Rule 2 accounting JSON backfilled at close (9 → 28 phases; strict transcription per Owner cap; served through `/api/discipline/lift_manifest`). PHASE_STATE.md dedupe housekeeping applied (`## Live State`, `## Phase Ledger`, `## Pending Decisions` each appear exactly once post-dedupe; git-stat: 121 lines total delta, 28 insertions / 93 deletions). Platform auto-commit `1625c8e` (2026-07-04 18:59:09 UTC) collapsed working-tree Block A/B/C sequence into a single commit. Close report on-disk canonical: `/app/docs/close_reports/phase_7_stage_b_2.md` (SHA quoted in return message). **`pytest -q` = 685/685 GREEN.** |
/app/memory/ORCHESTRATOR_CONTINUITY.md:119:| **Commercial Cut per BCR v1.4 §12 — subtractive change with mandatory preservation** | **CLOSED, ACCEPTED 2026-07-06** | **Pytest 814/814 (from 855; -41 net = -59 buyer/dual-delta/Sonnet/binding-copy/session tests removed + 18 new MAN-G1 named gate); Jest 70/70 (from 72; -2 §5.2 binding-copy tests cut); Playwright chromium 20/20 (from 24; buyer_surface_5_smoke.spec.ts cut whole = -4)** | N/A (subtractive) | N/A (subtractive) | N/A subtractive-per-§12 (NEGATIVE net LoC delta; not a band) | 2026-07-06 — Commercial cut executed per BCR v1.4 §12 (14 requirement IDs CUT-1..4 / PRES-1..3-ALT / MAN-1 / MAN-G1..G3 / BND-1..2 all satisfied). Buyer §5 wizard state machine + dual-delta + wizard-buyer router + buyer §5.1/5.2/5.3 pages + §5 Playwright smoke + Sonnet 4.6 wizard-agent LLM extracted to `/app/salvage/commercial_cut_2026_07_06/` (SHA-preserving). Surgical splits: `router_shims.py` (buyer helpers extracted), `admission_handoff.py` (reduced re-export), `llm_router.py` (SonnetWizardAgent + `_sonnet_invoke` extracted at lines 224-418), `test_phase_7_stage_b_2/b_3_wizard.py` operator+parity retained, Jest `test_phase_8_b_3_binding_copy_verbatim.test.js` §4-only. Removals: `server.py` buyer-router include; `App.js` buyer imports + 3 routes; `apiClient.js` 7 buyer wizard methods. New: MAN-G1 named gate at `/app/backend/tests/invariants/test_commercial_cut_man_g1.py` (18 tests over 17 forbidden commercial symbols). `QuoteEnvelope_v0` + `pricing_tiers.v0.json` + `AsyncDeliveryAccepted_v1.quote` field + `WizardCommitState_v0.variant="buyer"` Literal value ORPHAN-IN-PLACE (byte-identical per PRES-3 stands / PRES-3-ALT struck). Parity 26/26 byte-identical. Manifest bookkeeping: `RMS_UI_Specification_v1.md` row SHA realigned to post-Owner-directed-SUPERSEDED-banner state (`9053a4c4...`). Close report on-disk canonical: `/app/docs/close_reports/commercial_cut_2026_07_06.md` SHA-256 `bbf14900c7e51514e8be687597a5b046e445dc8fbc7db4f8ec8c853a62f20d90`. Salvage MANIFEST SHA `3196257965781b3c0ee38685c2f2d24902a3fe0484a0b15c704183d981e50d61`. Zero new §0.1 dispositions. Zero new §0.2 debts. |
/app/memory/ORCHESTRATOR_CONTINUITY.md:134:- **Commercial cut deliverables (2026-07-06):** whole-file cuts (4 backend + 4 frontend, SHA-preserving to salvage); surgical splits: `router_shims.py` operator-only + `admission_handoff.py` reduced re-export + `llm_router.py` SonnetWizardAgent extraction + `test_phase_7_stage_b_2_wizard.py` + `test_phase_7_stage_b_3_wizard.py` trimmed to operator+parity + `test_phase_8_b_1_auth_and_shims.py` E3 triad reduced + Jest `test_phase_8_b_3_binding_copy_verbatim.test.js` §4-only. Removals: `server.py` buyer-router include; `App.js` buyer routes + imports; `apiClient.js` buyer wizard methods. New: MAN-G1 named gate at `/app/backend/tests/invariants/test_commercial_cut_man_g1.py` (18 tests). Manifest bookkeeping: `RMS_UI_Specification_v1.md` row SHA realigned to post-Owner-directed-SUPERSEDED-banner state (`9053a4c4...`), noted for Part 3+ full manifest re-authoring.
/app/memory/ORCHESTRATOR_CONTINUITY.md:136:- Doctrinal-tension resolutions (all Stage B-4 gates + commercial-cut gates LOAD-BEARING GREEN post-cut): (a) 26 frozen contracts byte-identical — GREEN. (b) Shield boundary — GREEN (services/master_admin/* imports zero LLM libraries; commercial-cut REMOVED the buyer-variant SonnetWizardAgent + `_sonnet_invoke` from Shield; the language-tier routing table + main Shield entrypoint remain intact at `services/synisense/shield/llm_router.py`). (c) §0.1 Standing Dispositions FROZEN — GREEN (zero additions at cut). (d) Standing Rule v3 delivery — canonical markdown on-disk + SHA quoted; no full-text inline paste. (e) Substrate-drop 9/9 — GREEN (post-manifest-SHA-realignment). (f) Read-only route invariant (G5a) — GREEN. (g) Outer-gate irreversibility (G6). (h) V2 refusal terminality (G6). (i) Ruling 3 config-as-versioned-not-frozen — commercial `pricing_tiers.vN.json` orphan-in-place, byte-identical. (j) Ruling 4 shared-derivation. (k) Frozen-field-changes-as-new-versions — no in-place mutation; PRES-3 stands, PRES-3-ALT struck. (l) Infra-not-refusal. (m) Auth-not-refusal. (n) Wizard `wizard_transcript` retention marker preserved. (o) Disposition-must-cite-owner-ruling. (p) Sizing-anchor-declares-snapshot-inclusion — commercial cut is **first subtractive phase**; Rule-2 one-liner cites `subtractive-per-§12` in lieu of numeric anchor; net LoC delta NEGATIVE. (q) Owner E1 federation-forward preserved. (r) Owner E1 no-hand-rolled-crypto. (s) E1 scope-enforcement per call. (t) E2 4-code bounded set preserved. (u) `RMS_MASTER_ADMIN_TOKEN` retirement + `X-RMS-Master-Admin` header retirement — grep-negative GREEN. (v) §6.3 collapsed-by-default diff. (w) §4.2 fixture-schema invariant. (x) **NEW at commercial cut: BND-1 satisfied — extractor tree has zero live commercial code; zero price/quote/offer/catalogue/order/buyer live consumer; MAN-G1 named gate ratifies.** (y) **NEW at commercial cut: BND-2 posture recorded** — single sales business assumption stands; marketplace [STAKED] item NOT re-litigated per Owner ruling.
/app/memory/ORCHESTRATOR_CONTINUITY.md:19:- **V2 refusal terminality** (G6): V2 refusal envelope IS the record; no partial-egress ever; enforced by `test_v2_gate_refusal_cumulative.py`.
/app/memory/ORCHESTRATOR_CONTINUITY.md:206:- Phase 7 Stage B-2 deliverables (2026-07-04): (i) **3 NEW source files** — `services/wizard/dual_delta.py` (91L; declarative-table pattern mirroring `provenance_preservation.py`; Owner E6 `Visibility-not-prohibition` mechanical application), `services/wizard/buyer_state_machine.py` (332L; mirrors operator SM shape; imports `_record_feasibility_snapshot` + `validate_source_tags` + `validate_guard_1_operator_mandatory_all_operator_supplied` from operator-proven modules per Owner Condition 2), `routers/wizard_buyer.py` (267L; 7 endpoints mounted at `/api/wizard/buyer/*`). (ii) **1 NEW test file** — `test_phase_7_stage_b_2_wizard.py` (835L; 38 named gates + parametrised expansions = 72 collected cases). (iii) **5 MODIFIED source files** — `services/synisense/shield/llm_router.py` +196 (`SonnetWizardAgent` class + `_sonnet_invoke` helper + no-silent-degrade path); `services/wizard/operator_state_machine.py` +12 (Condition A(i) predicate at `record_agent_assumption` + `variant` kwarg default operator); `routers/wizard_operator.py` +18 (`SourceTagViolation` import + 422 boundary for Condition A(i)); `services/wizard/session_persistence.py` +4 (additive compound index on `variant + session_id`); `server.py` +2 (buyer router mount). (iv) **1 docs-only fix** — `docs/lift_manifest.json` +6 (pre-existing 8a-lite path repair carry-through). (v) **0 NEW Standing Owner Dispositions** at §0.1 (§0.1 FROZEN per Owner correction). (vi) **1 NEW Plan Debt** at §0.2: `Wizard session-ownership binding plan-debt` — verbatim: *"Wizard session-ownership binding lands with Phase 8 auth/key model — recorded as the system-wide auth landing, not a wizard-special. [Owner ruling, Phase 7 Stage B-2 dispatch, 2026-07-04]"*. (vii) **Rule 2 accounting JSON backfill** — `/app/docs/rule2_accounting.json` extended 9 → 28 phases (transcription-only from ORCHESTRATOR §2 + PHASE_STATE row narratives per Owner cap). (viii) **PHASE_STATE.md dedupe** — three duplicated section headers collapsed to a single authoritative section each; git-stat 28 insertions / 93 deletions.
/app/memory/ORCHESTRATOR_CONTINUITY.md:238:| 12 | `backend/contracts/v2_refusal.py` (V2RefusalEnvelope) | `v2_refusal_envelope.contract_snapshot.json` | `test_v2_gate_refusal_cumulative.py::test_v2_refusal_envelope_contract_frozen` | **G6** |
/app/memory/ORCHESTRATOR_CONTINUITY.md:240:| 14 | `backend/contracts/service_1_refusal.py` (Service1Refusal) | `service_1_refusal.contract_snapshot.json` | `test_service_1_refusal_envelope.py::test_service_1_refusal_schema_frozen` | **A2** |
/app/memory/ORCHESTRATOR_CONTINUITY.md:277:User dispatched **A2 — Service1Refusal envelope + composition_below_floor branch** with eight locked decisions (D1b include new branch, D2a static hint table, D3a flat JSONResponse, D4b 14th freeze, D6a Ring-5-upstream-boundary Path A, D7a max reduction, D8a `len(eligible)==0` trigger, X1 discipline observation tracked separately). e1_dev executed the phase autonomously to acceptance gate. STEP 0 preconditions: CI baseline 347/347 green; §204/§247 wording check confirmed source specs prescribe content categories only (`corroboration / accountable source` in `< >` placeholder syntax), NOT verbatim strings — HAZARD-STOP (f) did NOT fire, user's rewrite is authoritative. Shipped: `contracts/service_1_refusal.py` (14th frozen contract, 7 fields: outcome discriminator + reason + run_id + trace_id + asked + supported_class + what_would_raise_it); `service_1_refusal.contract_snapshot.json` (11th snapshot file); `services/service_1/refusal_hints.py` (static per-reason table, three user-locked strings); service layer wired at all three refusal sites via `Service1Refusal(reason, run_id, trace_id, *, asked, supported_class, what_would_raise_it)` exception + `_max_supported_class` helper reading Ring-5-governed per-unit `defensibility_class` with local `_CLASS_ORDER` mirror (D6a doctrine, no `solva_depth` import — service.py docstring L10-11 `"Does NOT invoke Solva"` intact); new `composition_below_floor` raise site fires on `if not eligible:` after Targeta filtering (D8a); router replaced `raise HTTPException(422)` with `return JSONResponse(status_code=422, content=refusal.model_dump())` for flat top-level body (D3a); `responses={200: Service1RunSummary, 422: Service1RefusalContract}` documented on the decorator for OpenAPI; added `objective_text: str` field to `Service1RunRequest` and plumbed through 5 test call-sites (`test_service_1_invariants.py` 4 sites + `test_trace_lens_readonly.py` 1 + `test_trace_lens_cross_engine_correlation.py` 2). Test suite: 7 new HTTP-layer invariant tests + 1 snapshot invariant, all in `test_service_1_refusal_envelope.py`, all green (validation-vs-refusal distinguishability via `body.outcome === "refused"` field-check, NOT status code; infrastructure-fault guard proves 500-not-refusal; D6a governed-not-recomputed via signal-ring mutation test; D7a max-not-min via mixed-class fixture). `.github/workflows/g0-gate.yml` gained `workflow_dispatch`. `docs/handoff/backend_contract_surface_v1.md` realigned across §1 (13→14), §1.14 new subsection, §2 route #17 error cell (fixed self-contradicting "500 (not 500)"), §2.1 request/response examples corrected (previous doc showed `ObjectiveRequest`-shape not `Service1RunRequest`-shape) + three refusal branches enumerated + validation-vs-refusal distinguishability + infrastructure-fault non-conflation, §4 Service 1 row updated with 7-field envelope reference, §5.3 tightened per user brief ("Verified across contracts" → "these payloads carry the class; Gate 1's build-time test enforces completeness"), §5.4 backed by the new envelope, §8 signature bumped to `-v1.1-a2-e1_dev-20260702T021500Z` + CI 340→355. `docs/lift_manifest.json` gained 4 new entries. `BUILD_JOURNAL.md` A2 close entry filed with strict §0 inline discretionary enumeration. **`make ci` = 355/355 green** (delta +15 from G6: +7 handoff route + +7 A2 refusal tests + +1 A2 snapshot invariant). No HAZARD-STOPs raised. Backend surface still FROZEN; A2 was a targeted additive amendment, not a re-open. Parked; G5b dispatch to `e1_web_frontend_dev` still awaits user go with the amended artifact validated.
/app/memory/ORCHESTRATOR_CONTINUITY.md:40:- **Infra-not-refusal** — [Owner ruling, Phase 5 Stage A close, 2026-07-04] *"async_queue_saturated — struck as a refusal code; it's a 503. Saturation is the system unable, not unwilling — an infra condition, not a governance decision, and the three-render-path doctrine forbids dressing infra as refusal."* — **Retroactively citation-audited 2026-07-04 (Phase 6 Stage B) per new meta-doctrine `Disposition-must-cite-owner-ruling`; original inline body preserved verbatim below.** Infrastructure faults return HTTP 503 (or 5xx family), NEVER a governed refusal envelope. Refusals are governance decisions (with `reason` + `what_you_can_do` actor-appropriate path forward); 503 is an infrastructure decision (retry-later signal). Struck code at Stage B: `async_queue_saturated` (was a candidate refusal reason at Stage A design; STRUCK at Stage B open as violating this Disposition). Standing pattern: substrate saturation, database unavailability, worker crashes, external-API timeouts — all infra; all 5xx; never refusals. Enforced by `test_no_async_queue_saturated_code_in_any_registry` (grep-negative across all four registries: `admission_refusal_reasons.v0/v1/v2.json` + `service_1_refusal_reasons.v0.json`) + `test_queue_overflow_raises_503_not_refusal` (LOAD-BEARING; queue full → HTTPException 503, response body does NOT carry `outcome=refused`). **Distinction retained at Phase 6 Stage B:** `fleet_policy_reserved_zero_capacity` is a GOVERNANCE refusal (Master Admin unwilling to allocate) @422 AdmissionRefusal_v0, NOT infra (503) — enforced by `test_fleet_capacity_governance_refusal_uses_admission_refusal_v0` (LB) + `test_queue_saturation_returns_503_not_refusal` (both distinct outcomes preserved).
/app/memory/ORCHESTRATOR_CONTINUITY.md:53:- **Phase 3 model-refusal plan-debt** (Phase 2 close, 2026-07-03) — **RESOLVED at Phase 3 close, 2026-07-03**: v3 §6.5 (`model` form off-menu refusal) — resolved by landing `AdmissionRefusal@v0` as the 17th frozen contract. Owner redefined the Phase 3 receiver from a model-specific refusal contract to the UNIFIED admission-refusal envelope (Phase 3 dispatch ruling), with `form_not_offerable` as the FIRST firing reason. Future admission-refusal reasons extend via the versioned reason registry (new Standing Owner Disposition in §0.1). Phase 2's scaffold placeholder for `form == "model"` was REPLACED (Condition 5 migration) by an `AdmissionRefusal@v0` emission at HTTP 422 in the same v2 dispatch code path.
/app/memory/ORCHESTRATOR_CONTINUITY.md:56:- **Phase 7 wizard-side dispatch plan-debt** (Phase 2 close, 2026-07-03; **restated Phase 4a Stage B close 2026-07-04 with license-class fallback-arm wrap; PARTIALLY RESOLVED at Phase 7 Stage B-1 close 2026-07-04; buyer-variant + LLM portion RESOLVED at Phase 7 Stage B-2 close 2026-07-04**): v3 §3.3 — the shaping wizard invokes `compute_feasibility` per-turn (guard 3). **RESOLVED at Phase 7 Stage B-1 close, 2026-07-04:** operator-variant state machine + Guard 1/2/3 + source-tag XOR invariant + license-class Option C wrap landed. `services/service_1/license_class_selection.py::derive_license_class(envelope, wizard_state=None)` primary arm reads FROZEN wizard state (Owner E1 branch-discrimination LB gate). **RESOLVED at Phase 7 Stage B-2 close, 2026-07-04:** buyer state machine + dual-delta gate (Owner E6 `Visibility-not-prohibition` mechanical application) + Sonnet 4.6 LLM (`SonnetWizardAgent` inside `services/synisense/shield/llm_router.py`) landed. Owner Condition-A pre-LLM Guard-1 mandatory-tier gate on `POST /api/wizard/operator/{sid}/agent-assumption` (3 LB gates: refuse mandatory-tier operator-variant / never-mint operator-source CommittedValue / never-append OperatorTurn). Owner Condition-2 grep-negative single-source × 3 symbols (`validate_source_tags`, `validate_guard_1_operator_mandatory_all_operator_supplied`, `_record_feasibility_snapshot`) — buyer SM imports each from operator-proven module. Zero new frozen contracts (parity 26 unchanged); zero new §0.1 Standing Dispositions (§0.1 FROZEN per Owner correction). **REMAINING at Phase 7 Stage B-3:** commit-review + buyer freeze + admission handoff to `POST /api/objectives`. **Additional Phase 7 receiver debt (Phase 3 close, 2026-07-03):** wizard-side rendering of `AdmissionRefusal@v0` as REFUSAL-WITH-PATH per UI Spec §3.3 (refusal, never error) — contract shape is Phase-7-consumable unchanged (Condition 4). **Additional Phase 7 license-class debt (Phase 4a Stage B close, 2026-07-04):** wrap `derive_license_class_from_commissioner` as the FALLBACK ARM of a new unified `derive_license_class(objective)` with explicit-value-if-present (from wizard commit state, likely `WizardCommitState_v0` sidecar) as primary arm; ONE site (still `services/service_1/license_class_selection.py`), Ruling 4 shared-derivation unchanged. Pre-committed verbatim in module docstring per Ruling 4. **RESOLVED at Phase 7 Stage B-1 close, 2026-07-04:** additive `derive_license_class` two-arm function landed; fallback body byte-identical (slice SHA `ca3b2007f0cee58da3de0562eea3e92492761cda95a8297e632b5346b8d0e41e`).
/app/memory/PHASE_STATE.md:22:- **Current gate:** **§3.8 Answer Fluency CLOSED + RATIFIED 2026-07-10 · unconditional per governance §12** — atomic execution commit per Owner rulings AF-E1 β + 2 conditions + AF-E2 amended boundary set + AF-E3 α + AF-E4 α + 1 ordering condition. LLM-synthesised fluent `answer_text` behind Shield chokepoint (`fluency_synthesizer.py`); Sonnet 4.5 via Emergent LLM key. AF-E2 amended boundary set landed: config defects → 503 fail-loud; runtime transients → mechanical arm; NEVER a refusal envelope. §11 9.2-OWN resolution landed same commit (compute-to-data topology). Backend Pytest 1162 passed + 1 skipped · Jest 137/137 unchanged · Playwright chromium 44/44 unchanged. Parity 31/31 byte-identical. Rule 2: 1,140 raw code+tests vs [650, 950] → +20% ABOVE-TOP (drivers credible per close §2.3). One new §0.1 disposition (AF-scope-only BCR "unavailability surfaces as 503" superseded for runtime transients). Close: `/app/docs/close_reports/answer_fluency.md`. Rulings: `/app/docs/rulings/answer_fluency_af_e1_to_e4.md`. Governance §12 close-ratification-on-own-text landed same-turn.
/app/memory/PHASE_STATE.md:3:**Last update:** 2026-07-10 (§3.4 Production Housing PH-R1 CLOSED + MANDATE-COMPLETE gate reached · atomic execution commit per Owner rulings PH-E1 α (vault-class classification + no-secrets-in-image · store choice is PH-R4 [OWNER] binding) + PH-E2 α (multi-stage single-image split · deploy topology owner-side) + PH-E3 α (`/readyz` FS-enumeration sharing V1-G7's authoritative counter · one counting mechanism · readiness and parity gate never disagree) + PH-E4 α + documentation-addition (seam doc records BCR annex target shape as binding migration target with 2-post-cut call-site inventory: fluency_synthesizer.py:L182 + brief_synthesizer.py:L116 · zero code change to llm_router.py) + `/api/system/build_info` Owner enhancement promotion (STAKED promotion-not-rebuild claim made mechanical · payload `{git_sha, build_timestamp, parity_count}` · no secrets · same shared counter as PH-E3) + band `[900, 1,700]` RATIFIED. Landed: `Dockerfile` (multi-stage · node:20-alpine → python:3.11-slim · non-root app user · EXPOSE 8001 · HEALTHCHECK CMD curl /api/healthz · CMD uvicorn preserved verbatim) + `.dockerignore` (excludes .env* · node_modules · .git · docs/ · memory/ · salvage/) + `docker-compose.yml` (dev-parity mongo:6 + backend) + `services/health/parity_counter.py` (48 LoC shared authoritative FS-enumeration counter · O(31)) + `services/health/__init__.py` (14 LoC re-exports) + `routers/health.py` (84 LoC · /api/healthz liveness no-auth-no-DB + /api/readyz readiness with DB ping + parity check · 503 on either fail · refusal taxonomy untouched) + `routers/system_info.py` (95 LoC · /api/system/build_info Owner enhancement · git SHA + build timestamp + parity_count · GIT_SHA/BUILD_TIMESTAMP build-args with git-rev-parse fallback · no secrets) + 4 production_housing docs (env_findings_v0.md 93 · frontend_backend_split.md 77 · llm_swap_seam.md 134 · promotion_audit_v0.md 129) + rulings record 134 + PH-R1 close 350 + 24 backend Pytest cells (PH-G1..G6 + auxiliary) + 3 Playwright chromium smokes (build_info_smoke.spec.ts). V1-G7 test refactored to import from shared counter (`services.health.count_frozen_contract_snapshots()` · 10 LoC delta) — one authoritative counter across three surfaces (/api/readyz + /api/system/build_info + V1-G7 gate). Backend Pytest 1202 passed + 1 skipped (baseline 1178 + 1 → +24 new PH-R1 cells) · Jest 145/145 unchanged (PH-R1 lands no UI cells) · Playwright chromium 51/51 (baseline 48/48 → +3 new PH-R1 build_info smokes). Parity 31/31 byte-identical (attested at PH-G-Parity). Rule 2 verdict (raw LoC per §9 band-relative trichotomy): 1,498 raw code+tests+docs vs ratified band [900, 1,700] → WITHIN BAND at 75% of range (snapshot_raw_in_band=yes). §4.2 raw threshold 1,500 NOT crossed (1,498 vs 1,500 = -0.13% · effectively at-threshold clean pass) · Tier-2 disclosure-only per §12.1 (non-blocking); atomic single commit per §4.1 baseline (dev's judgment per Owner delegation); split-fallback NOT triggered. Zero new §0.1 dispositions. Zero new §0.2 debts. §12 close-ratification-on-own-text criteria met: (a) named gates green, (b) rulings + Owner-addition + enhancement attested as applied, (c) no new Tier-1 escalation during execution → close ratifies on its own text. **MANDATE-COMPLETE lands with this close per Owner declaration 2026-07-10.** Close: `/app/docs/close_reports/production_housing_ph_r1.md`. Rulings: `/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md`.)
/app/memory/PHASE_STATE.md:95:- **Commercial-cut close (2026-07-06) — deliverables:** whole-file cuts (4 backend + 4 frontend); surgical splits (`router_shims.py` operator-only + `admission_handoff.py` reduced re-export + `llm_router.py` SonnetWizardAgent extraction + `test_phase_7_stage_b_2_wizard.py` operator+parity + `test_phase_7_stage_b_3_wizard.py` operator+parity + `test_phase_8_b_1_auth_and_shims.py` E3 triad reduced + Jest `test_phase_8_b_3_binding_copy_verbatim.test.js` §4-only); server.py buyer-router-include removed; App.js buyer routes + imports removed; apiClient.js buyer wizard methods removed; MAN-G1 named gate landed at `test_commercial_cut_man_g1.py` (18 tests). Salvage MANIFEST at `/app/salvage/commercial_cut_2026_07_06/MANIFEST.md` SHA `3196257965781b3c0ee38685c2f2d24902a3fe0484a0b15c704183d981e50d61`. Close report SHA `bbf14900c7e51514e8be687597a5b046e445dc8fbc7db4f8ec8c853a62f20d90`.
/app/memory/PRD.md:100:- **Landed:** LLM-synthesised fluent `answer_text` behind Shield chokepoint (`services/synisense/shield/fluency_synthesizer.py` · Sonnet 4.5 via Emergent LLM key reused from `llm_router.py` Phase 7 Stage B-2 seed). Per-sentence structured anchor mapping grounding gate at `services/service_1/answer_grounding.py` — 4 sub-gates: (A) unit_id ∈ load_bearing set, (B) sentence-anchor cover, (C) numeric verification (Owner Cond 1 · mechanical byte-substring check, no semantic scoring), (D) full-response REJECT on any failure (Owner Cond 2 · gate never patches prose). Fluency-mode telemetry sidecar mirrors 9.2a-E2 α cond 2 precedent · `ComposedConclusion_v0` envelope byte-identical · parity 31 preserved. AF-E2 amended boundary set (owner-value amendment to BCR anchor): config defects → 503 fail-loud, runtime transients (llm_unavailable / llm_timeout / llm_parse_failure / grounding_reject) → mechanical arm, NEVER a refusal envelope. AF-E4 α ordering condition honored: pre-3.8 mechanical composer f-string captured byte-identically to goldens BEFORE any refactor; extracted to `services/service_1/mechanical_composer.py`. §11 9.2-OWN resolution landed verbatim in `docs/governance/tiered_ruling_model.md` same commit per Owner PART 1 (compute-to-data topology · 9.2b collapses to two owner-side external actions).
/app/memory/PRD.md:219:- **Phase 7 Stage B-2 — Buyer variant + Sonnet 4.6 LLM (SonnetWizardAgent inside Shield) + dual-delta gate + Condition-A pre-LLM Guard-1 landing + Condition-2 grep-negative single-source (× 3 symbols)** (2026-07-04): CLOSED. Live at 7 endpoints `POST /api/wizard/buyer/{session, {sid}/turn, {sid}/propose, {sid}/agent-assumption, {sid}/commit-review, {sid}/freeze}` + `GET /api/wizard/buyer/{sid}`. `SonnetWizardAgent` (Claude Sonnet 4.6 via Emergent LLM Key) lives inside `services/synisense/shield/llm_router.py` — `services/wizard/*` remains LLM-free (Shield boundary preserved). Temp 0.2 live / 0.0 hermetic replay. No silent model degrade — Sonnet-unavailable → HTTP 503 (Standing Disposition `Infra-not-refusal`). Dual-delta gate (`services/wizard/dual_delta.py`, Owner E6 `Visibility-not-prohibition` mechanical application): standard/grain-changing proposals refuse `dual_delta_missing` if `price_delta` or `class_delta` absent; reach-changing proposals admissible. Owner Condition-A pre-LLM Guard-1 mandatory-tier gate on `POST /api/wizard/operator/{sid}/agent-assumption` (3 LB gates). Owner Condition-2 grep-negative single-source × 3 symbols confirms `buyer_state_machine.py` re-implements NONE of {`validate_source_tags`, `validate_guard_1_operator_mandatory_all_operator_supplied`, `_record_feasibility_snapshot`}. Zero new frozen contracts (parity 26 unchanged); zero new §0.1 Standing Dispositions (§0.1 FROZEN per Owner correction); 1 new §0.2 Plan Debt `Wizard session-ownership binding` — [Owner ruling, Phase 7 Stage B-2 dispatch, 2026-07-04]. 26 prior frozen contract sources byte-identical. 685/685 backend GREEN (baseline 613 → +72 net; intermediate block sequence 613 → 624 → 631 → 685). Rule-2 accounting: band 1600-2000 (mid ~1800); actual ~1757; WITHIN BAND (-2.4% delta). On-disk canonical `/app/docs/close_reports/phase_7_stage_b_2.md` SHA `c46186b173d813bdbdca82e98a3a13618d2a2e30aca4ceebd89503fdafb18a21`.
/app/memory/PRD.md:251:12. `v2_refusal_envelope@v0` (G6)
/app/memory/PRD.md:293:12. **V2 refusal terminality** (G6): V2 refusal envelope IS the record; no partial-egress ever.
/app/memory/PRD.md:89:- **Landed:** `services/opportunity_briefs/` package (8 modules: `__init__` + `generator` + `brief_registry` + `brief_selector` + `brief_grounding` + `brief_telemetry` + `advisory_marker` + `shape_as_objective_prefill` + README salvage carrier per OB-R1 lifted-not-imported). Shield chokepoint at `services/synisense/shield/brief_synthesizer.py` (Sonnet via `llm_router::_provider_for("analytical")` Phase 7 Stage B-2 seed reuse · 30s timeout · structured JSON output validated by hard schema) + `brief_prompt.v0.txt` (data-blind template). OB-E1 α (byte-verbatim structured-anchor grounding · whole-brief REJECT · gate never patches · no semantic scoring per AF-E1 β Owner Condition 1 precedent). OB-E2 α × 3 seams (Seam-1 write-time attach at `advisory_marker.attach()` + render-time no-strip §6.10 reflection walk · Seam-2 route-level 404 at `routers/solva.py::get_trace(...)` for `brief_`-prefixed IDs · Seam-3 grep-negative service_1/** → opportunity_briefs/** import boundary via §6.10 AST walk · AS-G6/TF-G9/FR-G4/AF-G6b lineage · no new precedent minted). OB-E3 α (Registry-computable aggregate = Registry-exposed native · synthesis-time compute FORBIDDEN via §6.10 AST walk over generator + brief_synthesizer for {sum,avg,mean,min,max,count,statistics} Name calls). Frontend surface UI Spec v2.2 §3.7 landed at `frontend/src/pages/opportunity_briefs/{OpportunityBriefsPage,OpportunityBriefCard}.jsx` + route `/opportunity-briefs` in App.js (three fixture-census briefs per AS-U2 · scope chip + advisory marker + stale indicator + shape-as-objective handoff writing sessionStorage `opportunity_brief_reach_prefill` + navigation). Sidecar telemetry `brief_telemetry.py` mirrors AF-E3 α + 9.2a-E2 α cond 2 precedent. Parity 31/31 preserved (attested at OB-G-Parity · no frozen contract touched).
```
</details>

### 1.2 · Step-2 find inventory

Command:
```
find /app -type f \( -name '*.md' -o -name '*.py' -o -name '*.json' -o -name '*.yaml' \) -not -path '*/node_modules/*' -not -path '*/salvage/*' -exec grep -lIE 'shield|llm_router|grounding.?gate|refusal.?envelope|key.custody' {} + | sort -u
```

Line count: **125** files.

<details><summary>Full inventory</summary>

```
/app/BUILD_JOURNAL.md
/app/backend/contracts/admission_refusal.py
/app/backend/contracts/composed_conclusion.py
/app/backend/contracts/northena_ledger.py
/app/backend/contracts/service_1_refusal.py
/app/backend/routers/health.py
/app/backend/routers/objectives.py
/app/backend/routers/service_1.py
/app/backend/routers/transform_forms.py
/app/backend/services/compliance/refusal_family_classifier.py
/app/backend/services/compliance/trust_receipt_allowlist.py
/app/backend/services/layer_b/asr/whisper_provider.py
/app/backend/services/layer_b/contracts.py
/app/backend/services/layer_b/factory.py
/app/backend/services/layer_b/vision/frame_perception_provider.py
/app/backend/services/northena/admit.py
/app/backend/services/northena/converge.py
/app/backend/services/northena/gate.py
/app/backend/services/northena/ledger.py
/app/backend/services/opportunity_briefs/README.md
/app/backend/services/opportunity_briefs/brief_grounding.py
/app/backend/services/opportunity_briefs/generator.py
/app/backend/services/outer_gate/mint.py
/app/backend/services/registry/validator.py
/app/backend/services/service_1/admission_refusal.py
/app/backend/services/service_1/answer_grounding.py
/app/backend/services/service_1/composed_conclusion.py
/app/backend/services/service_1/dispatch.py
/app/backend/services/service_1/refusal_hints.py
/app/backend/services/service_1/service.py
/app/backend/services/synisense/config.py
/app/backend/services/synisense/shield/__init__.py
/app/backend/services/synisense/shield/audit_log.py
/app/backend/services/synisense/shield/brief_synthesizer.py
/app/backend/services/synisense/shield/canonical.py
/app/backend/services/synisense/shield/client.py
/app/backend/services/synisense/shield/deidentifier.py
/app/backend/services/synisense/shield/exceptions.py
/app/backend/services/synisense/shield/fluency_synthesizer.py
/app/backend/services/synisense/shield/llm_router.py
/app/backend/services/synisense/shield/perception_router.py
/app/backend/services/synisense/shield/trust_receipt.py
/app/backend/services/system_state.py
/app/backend/services/transform_forms/callable_skill_gate.py
/app/backend/services/v2_gate/refusal.py
/app/backend/tests/invariants/admission_refusal.contract_snapshot.json
/app/backend/tests/invariants/service_1_refusal.contract_snapshot.json
/app/backend/tests/invariants/test_admission_refusal_dispatch.py
/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py
/app/backend/tests/invariants/test_dispatch_shape_responsive.py
/app/backend/tests/invariants/test_dispatch_v0_untouched.py
/app/backend/tests/invariants/test_frozen_contract_snapshot_parity.py
/app/backend/tests/invariants/test_ledger_absorbs_outer_gate_and_v2_via_stamp_audit.py
/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py
/app/backend/tests/invariants/test_phase_5_stage_b_async_delivery.py
/app/backend/tests/invariants/test_phase_7_stage_b_3_wizard.py
/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py
/app/backend/tests/invariants/test_service_1_refusal_envelope.py
/app/backend/tests/invariants/test_transform_forms.py
/app/backend/tests/invariants/test_v2_gate_refusal_cumulative.py
/app/backend/tests/test_no_direct_llm_calls_outside_shield.py
/app/backend/tests/test_perception_router.py
/app/docs/audits/g3_solva_conformance_v1.md
/app/docs/audits/g6_conformance_v1.md
/app/docs/close_reports/answer_fluency.md
/app/docs/close_reports/commercial_cut_2026_07_06.md
/app/docs/close_reports/housekeeping_preflight.md
/app/docs/close_reports/machine_readable_registry.md
/app/docs/close_reports/opportunity_briefs.md
/app/docs/close_reports/phase_4a_stage_b.md
/app/docs/close_reports/phase_5_stage_b.md
/app/docs/close_reports/phase_7_stage_b_2.md
/app/docs/close_reports/phase_7_stage_b_3.md
/app/docs/close_reports/phase_8_b_1.md
/app/docs/close_reports/phase_8_b_2.md
/app/docs/close_reports/phase_8_b_3.md
/app/docs/close_reports/phase_8_b_5a.md
/app/docs/close_reports/phase_8_conformance_map.md
/app/docs/close_reports/phase_8_seam_3_sub_stage_1.md
/app/docs/close_reports/production_housing_ph_r1.md
/app/docs/close_reports/registry_population.md
/app/docs/close_reports/transform_forms.md
/app/docs/g4_prep/targeta_prep.md
/app/docs/g6_prep/g6_scope_from_source.md
/app/docs/governance/registry_doctrine_v1.md
/app/docs/governance/tiered_ruling_model.md
/app/docs/handoff/backend_contract_surface_v1.md
/app/docs/handoff/seam_unlock_runbook.md
/app/docs/lift_manifest.json
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_4.md
/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md
/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md
/app/docs/mandates/archive/RMS_Product_Engineering_Spec_v2.1.md
/app/docs/mandates/northena.md
/app/docs/production_housing/llm_swap_seam.md
/app/docs/production_housing/promotion_audit_v0.md
/app/docs/recon/repo_recon_2026.md
/app/docs/registry/consolidation_log_v0.md
/app/docs/registry/function_promise_registry_v0.md
/app/docs/registry/machine/registry.yaml
/app/docs/requirements/operating_values_v1.md
/app/docs/rule2_accounting.json
/app/docs/rulings/answer_fluency_af_e1_to_e4.md
/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md
/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md
/app/docs/rulings/transform_forms_tf_e1_to_e4.md
/app/docs/stage_a_proposals/answer_fluency.md
/app/docs/stage_a_proposals/machine_readable_registry_stage_a.md
/app/docs/stage_a_proposals/opportunity_briefs.md
/app/docs/stage_a_proposals/phase_4_stage_a.md
/app/docs/stage_a_proposals/phase_5_stage_a.md
/app/docs/stage_a_proposals/phase_6_stage_a.md
/app/docs/stage_a_proposals/phase_7_stage_b_2.md
/app/docs/stage_a_proposals/phase_7_stage_b_3.md
/app/docs/stage_a_proposals/phase_8.md
/app/docs/stage_a_proposals/production_housing_ph_r1.md
/app/docs/stage_a_proposals/registry_population_stage_a.md
/app/docs/stage_a_proposals/sequencing_harness_stage_a.md
/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md
/app/docs/stage_a_proposals/transform_forms.md
/app/frontend/public/downloads/shield_engine_specs.bundle.md
/app/memory/ORCHESTRATOR_CONTINUITY.md
/app/memory/PHASE_STATE.md
/app/memory/PRD.md
/app/memory/web/iteration_1.md
```
</details>

## Section 2 — bundle_index (path · sha256 · lines · classification)

This block is the evidence base cited by Part A's SyniSense row.


| # | path | sha256 | lines | classification |
|---|---|---|---:|---|
| 1 | `/app/backend/services/compliance/__init__.py` | `b466a35c37570c825305b748722b909b3410310bd9bd77b14a816a13edc4050b` | 29 | backend_code |
| 2 | `/app/backend/services/layer_b/asr/whisper_provider.py` | `a45900f46f6178051c95f26c21b92da43d73f931e553adcc58bf0800d8d4f66a` | 56 | backend_code |
| 3 | `/app/backend/services/layer_b/contracts.py` | `ba735439f413ae56ed5828cc25e91b4870ab1949885e17c1d8a09add2fc8a8d6` | 111 | backend_code |
| 4 | `/app/backend/services/layer_b/factory.py` | `132c49e6d5f23fa403738dd5853c5ffb11c9fb5fbfca3dceb9afed9e23aed397` | 93 | backend_code |
| 5 | `/app/backend/services/layer_b/vision/frame_perception_provider.py` | `15c940e26012b4c404763dd99d37a7373f1bf8d3dfda68a67e3f599d182c9ebe` | 51 | backend_code |
| 6 | `/app/backend/services/northena/converge.py` | `4f24c9f52a98496809828e57151f95caf351be1be29828c5a84c18321786f0f3` | 149 | backend_code |
| 7 | `/app/backend/services/opportunity_briefs/generator.py` | `f2178dd8691827bae1068c57d45d8bcb38092e29ef4ee758d22e3051e8d35210` | 148 | backend_code |
| 8 | `/app/backend/services/registry/validator.py` | `7ac8b790f259abe679563987302d01e085e695437c4c9d3f0376510cf68d4097` | 366 | backend_code |
| 9 | `/app/backend/services/service_1/composed_conclusion.py` | `c6adf31f00825ec03c1e7ed28234412cb4d83f52400a346832da892692d023f1` | 453 | backend_code |
| 10 | `/app/backend/services/service_1/dispatch.py` | `27c1fd9bc248dd3bb3776478bc4cf27d38de347fca3c48607c7c46a47cf5ff6d` | 507 | backend_code |
| 11 | `/app/backend/services/service_1/service.py` | `4a453e30a05f3d840ac7ff54d4a387db6f6f7252ad70358edcd1a9b5299c17f8` | 309 | backend_code |
| 12 | `/app/backend/services/system_state.py` | `3738fe47c5c1b4a712683dce9cf13665d29eb8d964d0d1d233768a5d0bff08ba` | 151 | backend_code |
| 13 | `/app/backend/services/transform_forms/callable_skill_gate.py` | `02d5674517a804eb93ba5c8b1ab1d64368294650294a3a32a6164396c99b3871` | 144 | backend_code |
| 14 | `/app/backend/services/opportunity_briefs/brief_grounding.py` | `3880742d2d39fde9081db99fbadabb5ee196e56b9a8466a14379232544f58633` | 103 | backend_code_grounding |
| 15 | `/app/backend/services/service_1/answer_grounding.py` | `f5a105adfcb8ca12fbbdba5f618fa7eb79c57f2e574e0956e89303acc0162311` | 164 | backend_code_grounding |
| 16 | `/app/backend/contracts/admission_refusal.py` | `e68a1e383042835c8104d140e39469615c5f4a81461defaa7d13f098f68acf6f` | 158 | backend_code_refusal |
| 17 | `/app/backend/contracts/service_1_refusal.py` | `4fe38c214dc592603ceeffaf07732d33e374bae825fc7556d8684f667e41b022` | 98 | backend_code_refusal |
| 18 | `/app/backend/services/compliance/refusal_family_classifier.py` | `3dddd9efdaa4c188af1387428e661aa5d09e133b7188de0011c2dcce0ab69ad3` | 121 | backend_code_refusal |
| 19 | `/app/backend/services/service_1/admission_refusal.py` | `02476f51a68903cd59e8d04b099c7f090933c98732b89b91f2eb6d11ac977b4f` | 516 | backend_code_refusal |
| 20 | `/app/backend/services/service_1/refusal_hints.py` | `6ba48f7e22455b6a2b640a063cd212090b39d5dc67dc63314cc952de31b77856` | 46 | backend_code_refusal |
| 21 | `/app/backend/services/v2_gate/refusal.py` | `f562385f66e36e938654226302205acbbc3acc7f3691ef47e88cd5ec01d17b76` | 40 | backend_code_refusal |
| 22 | `/app/backend/tests/invariants/admission_refusal.contract_snapshot.json` | `99381316dc71bf8f97acb36706bdfb057cb14c2da9ef1d32639aa788d72d67fb` | 68 | backend_code_refusal |
| 23 | `/app/backend/tests/invariants/service_1_refusal.contract_snapshot.json` | `56ec42bb5a12bda02f98653ee5762dda62fe91bd5543fbef6ea2f20f5822020d` | 74 | backend_code_refusal |
| 24 | `/app/backend/tests/invariants/test_admission_refusal_dispatch.py` | `9e02acdf34126a3b5f425ce55cd70a27528b06f2e58c8149847503ea80f12a35` | 399 | backend_code_refusal |
| 25 | `/app/backend/tests/invariants/test_service_1_refusal_envelope.py` | `702ad62f4f3c4735e9bc4ba00a3ee895e76d706a1dab2095bdcbc4ef47f5c543` | 383 | backend_code_refusal |
| 26 | `/app/backend/services/synisense/shield/llm_router.py` | `af225e954c03e1d9e4f754cc616081446e8d2f771e45292e3b0e44d16ef379c4` | 232 | backend_code_router |
| 27 | `/app/backend/services/synisense/config.py` | `9d6143d6441ffb1fb3c03d4e1c439b358369135c7f3ca5ec826297f7a3fd3b24` | 211 | backend_code_shield |
| 28 | `/app/backend/services/synisense/shield/__init__.py` | `23f360aa11f6c6a074b3c17953accca0fa4abc6da4e07fe89886bc9614b5d9c5` | 12 | backend_code_shield |
| 29 | `/app/backend/services/synisense/shield/audit_log.py` | `6a49b41fb9cc6ac45e6b5a68142a54a001e62954cf4bcbc30d2479ad571e3b34` | 191 | backend_code_shield |
| 30 | `/app/backend/services/synisense/shield/brief_synthesizer.py` | `87dae261d454d2c6f4eaeeb4153bd69325a839784062437f48b6e3a243e871d2` | 164 | backend_code_shield |
| 31 | `/app/backend/services/synisense/shield/canonical.py` | `ad5b1206ba66419cc501ece1b1c5389540f7df190b6c735a56c5aff2954abe82` | 191 | backend_code_shield |
| 32 | `/app/backend/services/synisense/shield/client.py` | `6bb2426ab5129f97faad7f1e6fbe81b5556beed43ab56a99aaeb403d0e2679b5` | 249 | backend_code_shield |
| 33 | `/app/backend/services/synisense/shield/deidentifier.py` | `6da2f511898a56e1b78c08e3a2619d9c239aa7287060e00b5988ce677e7f5657` | 686 | backend_code_shield |
| 34 | `/app/backend/services/synisense/shield/fluency_synthesizer.py` | `6799f55b9323f38d3b25c7cdf3362d2b0a2b42814bdf058823f65cec4ae7ccd7` | 236 | backend_code_shield |
| 35 | `/app/backend/services/synisense/shield/perception_router.py` | `e85fa7e95f01530c5f959c4fbf3b767d69c184771a6b741074cd7ced05937e4e` | 147 | backend_code_shield |
| 36 | `/app/backend/services/synisense/shield/trust_receipt.py` | `086af1886a519749be3ce16b14b85c9511e43f869930d0760d72dba82f6dc50e` | 133 | backend_code_shield |
| 37 | `/app/backend/contracts/composed_conclusion.py` | `d2df3f29531676d38f5ad4bd2946acd3e0c22148cb1d0ced294db5e280fc645c` | 178 | backend_contract |
| 38 | `/app/backend/routers/health.py` | `4221b7d14d208f14cf1754384d8917ac99d935d53a3cb43b992449b5954839f6` | 84 | backend_router |
| 39 | `/app/backend/routers/objectives.py` | `f7a1e7aeb795d7c2c8793ced8175aa4eb077e9fe7790a982e89e727c01b84d33` | 232 | backend_router |
| 40 | `/app/backend/routers/service_1.py` | `325c27de35e846af3007a6dae6990d0286e7e56e63ad38225439e0b9754b0304` | 324 | backend_router |
| 41 | `/app/backend/routers/transform_forms.py` | `7ae5382f5676406450f3c77e525140f08dda70ade5c03d7506e5ee9a95e0b099` | 124 | backend_router |
| 42 | `/app/backend/tests/conftest.py` | `1966ef415b2e548d714d2ee0e9796dbf85792a743d66d0c1bb046c1ad0b9701b` | 45 | backend_test |
| 43 | `/app/backend/tests/invariants/test_answer_fluency_af_g1_to_g8.py` | `3b2735a1c57ea466f57882c2650132d56bf5ec96a06ee4b36911daef37ce8ae8` | 383 | backend_test |
| 44 | `/app/backend/tests/invariants/test_dispatch_shape_responsive.py` | `19828fa1cb695f97d8f54c694ad1da0f2746526764ceff0dbf108c5b11ba85ac` | 569 | backend_test |
| 45 | `/app/backend/tests/invariants/test_dispatch_v0_untouched.py` | `0e980694faec6c9a706c10a709338d671afc81973ebf5786ca3618f464083c6f` | 131 | backend_test |
| 46 | `/app/backend/tests/invariants/test_frozen_contract_snapshot_parity.py` | `9e02d73637c3eb9019b9f3860a22a774ff3df03da86841bfa39cc23a423ee0de` | 143 | backend_test |
| 47 | `/app/backend/tests/invariants/test_ledger_absorbs_outer_gate_and_v2_via_stamp_audit.py` | `6ce49dd6e0e2e941acbdc7cecb9d413992c9c89dbfc25268d6c40eb283313fe9` | 129 | backend_test |
| 48 | `/app/backend/tests/invariants/test_opportunity_briefs_ob_g1_to_g5.py` | `7f0c1be2ce52c1d7ff59a7dd68719d04fbff3f77c87e45cd8ec8b8d8510a4d7b` | 456 | backend_test |
| 49 | `/app/backend/tests/invariants/test_phase_5_stage_b_async_delivery.py` | `0dd314375c64e49d4054fd79a6d039e869eab46d1668755eef9f59ff98a19896` | 894 | backend_test |
| 50 | `/app/backend/tests/invariants/test_phase_7_stage_b_3_wizard.py` | `5e3b89e83fb9574220d06227c896360ce03568ca37d0426cf73d7abff155de97` | 285 | backend_test |
| 51 | `/app/backend/tests/invariants/test_production_housing_ph_g1_to_g6.py` | `78896e2372fe9ea940ee57b443a64778f0f446a8bdcf6cf31b85e05f6d497d1f` | 389 | backend_test |
| 52 | `/app/backend/tests/invariants/test_transform_forms.py` | `cdefaf7578a21ec42777e2f32f01893366b8a464836896c77f4c707fc445150e` | 422 | backend_test |
| 53 | `/app/backend/tests/invariants/test_v2_gate_refusal_cumulative.py` | `7e4ab3da25de66d9e5de6f8c5c22e2e79763f0cd2554a031156ea55d7a363286` | 189 | backend_test |
| 54 | `/app/backend/tests/test_no_direct_llm_calls_outside_shield.py` | `6ae182e6a9c5a7749e2488c5cd6e8acbd117025b9a129cc8a7dfcdcb9d9fbd78` | 131 | backend_test |
| 55 | `/app/backend/tests/test_perception_router.py` | `ef66108f1a54dbff460f585fba526e577ff17f572ccc5e9f8bcf47f6e0c3d99b` | 31 | backend_test |
| 56 | `/app/docs/close_reports/answer_fluency.md` | `15f980f82f3ee06166331176f1006d749945503ddbd928468be6004dbec2c425` | 324 | close_report |
| 57 | `/app/docs/close_reports/commercial_cut_2026_07_06.md` | `bbf14900c7e51514e8be687597a5b046e445dc8fbc7db4f8ec8c853a62f20d90` | 162 | close_report |
| 58 | `/app/docs/close_reports/housekeeping_preflight.md` | `8e543ef9e527b691f72ff465f15678b86762ffaec38545733ac9e3ae0ef0a2cb` | 294 | close_report |
| 59 | `/app/docs/close_reports/machine_readable_registry.md` | `16828d6ca21e3ead41c4dfaa85443cee364e8e8b461e72b293c5ec5b6a9b9b64` | 192 | close_report |
| 60 | `/app/docs/close_reports/opportunity_briefs.md` | `8e8448c51bda77a7dec6018dfe29c328c971b75317b3327736dd030eda0d199d` | 273 | close_report |
| 61 | `/app/docs/close_reports/phase_4a_stage_b.md` | `f5bb38e7d25b3e295bb38aec24bf6e46404bb164ab0b9a5cd639c451234eb866` | 576 | close_report |
| 62 | `/app/docs/close_reports/phase_5_stage_b.md` | `49ce2262b1f6f6e244bb7294b165734f6de31a1b176a55f73dd8871e94a2def5` | 470 | close_report |
| 63 | `/app/docs/close_reports/phase_7_stage_b_2.md` | `c46186b173d813bdbdca82e98a3a13618d2a2e30aca4ceebd89503fdafb18a21` | 353 | close_report |
| 64 | `/app/docs/close_reports/phase_7_stage_b_3.md` | `ea12517cec7deee48818a097e942d08601fda5a0f381e215a7df2c508c801c30` | 225 | close_report |
| 65 | `/app/docs/close_reports/phase_8_b_1.md` | `b6d5c7a1ea0aaffa7b2a27dc31d96fd8c64f1ff071caf75913ffe6dde6c3f1fe` | 252 | close_report |
| 66 | `/app/docs/close_reports/phase_8_b_2.md` | `1b4d703d81dad6e80ba1d396ea3668ae29f06180d2eb47e75420e08b383ee580` | 283 | close_report |
| 67 | `/app/docs/close_reports/phase_8_b_3.md` | `a31b5a9d43c0563140a73762789f765390187052ebd4e24b47d9bb6a528f7215` | 176 | close_report |
| 68 | `/app/docs/close_reports/phase_8_b_4.md` | `21d2f5193cfb53fbb3ec2c35f293e78f7bd535f446a969137b4bad8758fdb3b8` | 339 | close_report |
| 69 | `/app/docs/close_reports/phase_8_b_5a.md` | `c48672b4562f330129396ef3b90aaffdfb45f6c2714a671e4aaee2953a7c8baf` | 540 | close_report |
| 70 | `/app/docs/close_reports/phase_8_conformance_map.md` | `e747a0f6ee815b003d4962dac515b0743451747b1ef4812fa824e6cbe98874e7` | 716 | close_report |
| 71 | `/app/docs/close_reports/phase_8_seam_3_sub_stage_1.md` | `fe4aa0f051afed51fa62bdb20ad7d0afa63e67963f3d3352f366f6522c9e7c00` | 222 | close_report |
| 72 | `/app/docs/close_reports/phase_8a_lite.md` | `bf4ba9a94f250abad61d33a842bdedf2e7c8571a3fe61b1d3323c25601dbe888` | 151 | close_report |
| 73 | `/app/docs/close_reports/production_housing_ph_r1.md` | `dac521b771f6a68de67f8734e1c27075b25cd6c8621ccdb641320cf0db381201` | 316 | close_report |
| 74 | `/app/docs/close_reports/registry_population.md` | `0399957c8c685da8e7a693b23b8a3952ced1764f67a44f7a5813b968ce93b2e7` | 252 | close_report |
| 75 | `/app/docs/close_reports/transform_forms.md` | `54c9d3c1bfb1ad4a7614294f2c85823dda259a1e5de7169d84b7de4db18605e4` | 247 | close_report |
| 76 | `/app/docs/lift_manifest.json` | `10e02bf410edddd07c7b9fab251c1c35591a6bfb232ccc7621466b2ace8c576c` | 1449 | config |
| 77 | `/app/docs/rule2_accounting.json` | `a98ccbbb8049ea38ffcff0a47f4559b20e8d5f9e5863234fe1121284da758b04` | 371 | config |
| 78 | `/app/docs/audits/g6_conformance_v1.md` | `d3c4307237648fb5ae91a20b0cd5a8330182bb849eee89a25a69a014c57c0efa` | 109 | docs_other |
| 79 | `/app/docs/g6_prep/g6_scope_from_source.md` | `277d7c238fe84e162e7e05e031564bdcd840b8a8a9d9ac9a716571bce48d254a` | 194 | docs_other |
| 80 | `/app/docs/governance/registry_doctrine_v1.md` | `0bfe65c47e2c55f35e2a860fec405c05b8ed32b3473bcb63a0a259fb810ab471` | 173 | doctrine |
| 81 | `/app/docs/governance/tiered_ruling_model.md` | `a37e472413d44eb971ea616a8e6f0f7df5c58f030e862990a07be43da77a3e37` | 346 | doctrine |
| 82 | `/app/docs/handoff/backend_contract_surface_v1.md` | `765effad78482c4bc66945e039bf4135314d58de5a770d3d6cb5c34126981428` | 424 | handoff_doc |
| 83 | `/app/docs/handoff/seam_unlock_runbook.md` | `fabda3ec882bd2bf68fe44978ade9ce0b175145f032cfd5bf2249f4003922b91` | 229 | handoff_doc |
| 84 | `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_4.md` | `ce5206c9e244fe58edb6824f785077c1c835bdf3f5b347f6a4fb98c036212524` | 341 | mandate |
| 85 | `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md` | `a1eae555affed0cbb18cac3e2b5a695e1834d961258b298470714cdbbfbbdaef` | 359 | mandate |
| 86 | `/app/docs/mandates/RMS_Product_Engineering_Spec_v3.md` | `af2e3cb2fccfd92278dedec725732ae1b5b48dff614fd6f7c8fbc805160d915a` | 197 | mandate |
| 87 | `/app/docs/mandates/RMS_UI_Specification_v2_2.md` | `d681c6cd399dd5691d7516015f5fe12d1251414efef6290bb008658c22e40cda` | 222 | mandate |
| 88 | `/app/docs/mandates/archive/RMS_Product_Engineering_Spec_v2.1.md` | `510cc1a9f58138cf4753e907fdb68a1b0334b5336eff05db32a3c40071cf484b` | 1070 | mandate |
| 89 | `/app/docs/mandates/northena.md` | `ab0beeddf23c9530cc54c6ddd4255b4b3d0435df0d4c156d05de478e65af8345` | 503 | mandate |
| 90 | `/app/memory/ORCHESTRATOR_CONTINUITY.md` | `961eea6305ac75458a24f70efe7d46848ef32aedd436e5d1d0ad34eecc91370f` | 277 | memory |
| 91 | `/app/memory/PHASE_STATE.md` | `c099927020bf9d44e006535c8ae6f4aabb5af698e4bd82f96fc81d6ae56fa1ee` | 192 | memory |
| 92 | `/app/memory/PRD.md` | `29f0fd998a99b34457eb68d5eb34990f8b7d1c9f0e602222e58aacf19dfc8257` | 399 | memory |
| 93 | `/app/backend/services/opportunity_briefs/README.md` | `8fb3201a87b64fcc797e33519dfa633536d755f2999fc28efa270224d4acdd56` | 36 | other |
| 94 | `/app/docs/production_housing/env_findings_v0.md` | `638ab372848197ab37cc12718936dbbe2cc1af3b5bc310a65f601b8020f85bc6` | 93 | production_housing |
| 95 | `/app/docs/production_housing/llm_swap_seam.md` | `fc344104b59bc39f388860610a444b204a8897b0c8c11c2417af1f211814220d` | 134 | production_housing |
| 96 | `/app/docs/production_housing/promotion_audit_v0.md` | `ae558f248ed40d7bd2d9a404851b6b7a74f4dfcec5ebc5ac48be09948b559e5c` | 129 | production_housing |
| 97 | `/app/docs/stage_a_proposals/answer_fluency.md` | `363c0ee55d6c0c9f97b01237f7597f8ea2fe458efe8c40ac7b11a2c4d0c0c49e` | 339 | proposal |
| 98 | `/app/docs/stage_a_proposals/machine_readable_registry_stage_a.md` | `a4c2642ccc1db3fac391540c18ef583112b1cd19d82b02dd141b28d84b85068f` | 388 | proposal |
| 99 | `/app/docs/stage_a_proposals/opportunity_briefs.md` | `39061210811943e21a5d1f68da99d356430e0a3bd7d52dc4829ba5fc373d8ab6` | 395 | proposal |
| 100 | `/app/docs/stage_a_proposals/phase_4_stage_a.md` | `028bf99c6bcd28779f6f32c5585a13e4feb4950518ef458b3440e1e1b2391504` | 983 | proposal |
| 101 | `/app/docs/stage_a_proposals/phase_5_stage_a.md` | `8150688e73e2e22f3fbd6e4ea5a78c8bf0020534efca0179921dad1beb97b7df` | 831 | proposal |
| 102 | `/app/docs/stage_a_proposals/phase_6_stage_a.md` | `62894f2cf4ee40a5d4352b9705c66da6c7fd29f0cafa7f2fe8703a2c37cccf78` | 606 | proposal |
| 103 | `/app/docs/stage_a_proposals/phase_7_stage_a.md` | `e2bfe36e2e61025fe417d1cd2de3e91cf4c88fdcb745d3c5f0028ef795fa98ce` | 807 | proposal |
| 104 | `/app/docs/stage_a_proposals/phase_7_stage_b_2.md` | `c515a71486abef1ad40e0c44d9f32cbceeb9027f1e7a3e59ae07e809defc3718` | 272 | proposal |
| 105 | `/app/docs/stage_a_proposals/phase_7_stage_b_3.md` | `040c4099aa031ddb4b8133ac64f301457e6bdafc13ad12cf5c58fb1ba90f4698` | 323 | proposal |
| 106 | `/app/docs/stage_a_proposals/phase_8.md` | `78db65d82e12b62de4198f081cd60c7f1818052d9b88d81077691c2e6c9bc96c` | 536 | proposal |
| 107 | `/app/docs/stage_a_proposals/production_housing_ph_r1.md` | `4c456c29a09b0c20b3920654028e26f23e0aae3aa3af96df9c824f63938d5461` | 426 | proposal |
| 108 | `/app/docs/stage_a_proposals/registry_population_stage_a.md` | `63d78ca5451a7a0e019a2231d9e59c054312f02c9cea3ed68580988295705e59` | 549 | proposal |
| 109 | `/app/docs/stage_a_proposals/sequencing_harness_stage_a.md` | `04da5080d3c573359cb446198483c63d1972497a627089d4ab5842907da5f84a` | 333 | proposal |
| 110 | `/app/docs/stage_a_proposals/standing_queries_as_ci_stage_a.md` | `942c9f73cacddfc262fa1c032f9d03de37bec1209ae573c0ff0c19eafa54c83f` | 273 | proposal |
| 111 | `/app/docs/stage_a_proposals/transform_forms.md` | `4278d0ef3254007396ec7322b633523a703448589f1b896a4b43556d348a0a05` | 384 | proposal |
| 112 | `/app/docs/recon/repo_recon_2026.md` | `e49cfc01b0abdf031d53af40d31bbe5160d318a12a266d20ee0e03c9b39f170d` | 352 | recon |
| 113 | `/app/docs/registry/consolidation_log_v0.md` | `2c60425599afbd59cb083cc8a391a94b717598a796a8028ca28ca4176ab26062` | 157 | registry |
| 114 | `/app/docs/registry/function_promise_registry_v0.md` | `598a7ad4d326dd5c0fc003fe8091a52fd215fb63e76d5c04befd1aa4c25584b0` | 306 | registry |
| 115 | `/app/docs/registry/machine/registry.yaml` | `708ddec778390ed62a2d7e07c6fc7d7c8e252f060723a32ffcf0fc36d1f835d9` | 2015 | registry |
| 116 | `/app/docs/requirements/operating_values_v1.md` | `a6c4a455175ef37dc71362aea2e41b2ce406baaf9a1c77b3f0f1326e0aa608ee` | 132 | requirement |
| 117 | `/app/docs/rulings/answer_fluency_af_e1_to_e4.md` | `e3872bd2d16c85c2d0e696bf527fe881065814fae659ed8341cf5fc1b8cf62ab` | 175 | ruling |
| 118 | `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md` | `91532c04cae050ea85e6b25f3d56d0b0db1c611b3c39450529b69fbe53e35bf2` | 155 | ruling |
| 119 | `/app/docs/rulings/production_housing_ph_r1_ph_e1_to_e4.md` | `7f0a0e2ce62d9fdcec0015f63813e24e4d02006d5ce594737863aea5712af8fc` | 134 | ruling |
| 120 | `/app/docs/rulings/transform_forms_tf_e1_to_e4.md` | `e2f8e4fbd33b50cfee0634ed0dda2f81267c3a297913288dc252cefb10a2d243` | 77 | ruling |

## Section 3 — Topic Index (T1..T12, anchor-only)

Verbatim ranges live in `excerpts/by_topic.md`. Each anchor is `file:line`.

### T1 — Shield role & positioning (per doctrine)

- `/app/docs/governance/registry_doctrine_v1.md:109`
- `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:30`
- `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:236`
- `/app/docs/mandates/RMS_Build_Completion_Requirements_v1_5.md:296`

### T2 — Shield-mediated model invocation (Sonnet 4.6 via Shield, rung classification)

- `/app/docs/registry/function_promise_registry_v0.md:100`
- `/app/docs/registry/function_promise_registry_v0.md:101`
- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/requirements/operating_values_v1.md:20`

### T3 — Fluency synthesizer (`synisense.shield.fluency_synthesizer`)

- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/registry/machine/registry.yaml:413`
- `/app/docs/registry/machine/registry.yaml:421`
- `/app/docs/registry/machine/registry.yaml:452`
- `/app/backend/services/synisense/shield/fluency_synthesizer.py:55`
- `/app/backend/services/service_1/composed_conclusion.py:92`

### T4 — Brief synthesizer (`synisense.shield.brief_synthesizer`)

- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/machine/registry.yaml:429`
- `/app/docs/registry/machine/registry.yaml:437`
- `/app/backend/services/synisense/shield/brief_synthesizer.py:46`
- `/app/backend/services/opportunity_briefs/generator.py:11`
- `/app/backend/services/opportunity_briefs/generator.py:38`

### T5 — Mechanical fallback arms

- `/app/docs/registry/function_promise_registry_v0.md:52`
- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/function_promise_registry_v0.md:111`
- `/app/docs/registry/machine/registry.yaml:113`
- `/app/docs/registry/machine/registry.yaml:425`
- `/app/docs/registry/machine/registry.yaml:441`
- `/app/docs/registry/machine/registry.yaml:553`
- `/app/docs/registry/machine/registry.yaml:560`
- `/app/docs/requirements/operating_values_v1.md:20`

### T6 — Cost classification & rung-4 accounting

- `/app/docs/registry/function_promise_registry_v0.md:72`
- `/app/docs/registry/function_promise_registry_v0.md:100`
- `/app/docs/registry/function_promise_registry_v0.md:101`
- `/app/docs/registry/function_promise_registry_v0.md:102`
- `/app/docs/registry/function_promise_registry_v0.md:103`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/registry/function_promise_registry_v0.md:198`
- `/app/docs/registry/function_promise_registry_v0.md:205`
- `/app/docs/registry/machine/registry.yaml:393`
- `/app/docs/registry/machine/registry.yaml:409`
- `/app/docs/registry/machine/registry.yaml:425`
- `/app/docs/registry/machine/registry.yaml:441`
- `/app/docs/registry/machine/registry.yaml:456`
- `/app/docs/registry/machine/registry.yaml:1423`
- `/app/docs/governance/registry_doctrine_v1.md:109`
- `/app/docs/governance/registry_doctrine_v1.md:111`
- `/app/docs/governance/registry_doctrine_v1.md:115`

### T7 — Behavioural bindings (D-* defect classes touching Shield)

- `/app/docs/governance/registry_doctrine_v1.md:87`
- `/app/docs/governance/registry_doctrine_v1.md:88`
- `/app/docs/governance/registry_doctrine_v1.md:89`
- `/app/docs/governance/registry_doctrine_v1.md:90`
- `/app/docs/governance/registry_doctrine_v1.md:91`
- `/app/docs/governance/registry_doctrine_v1.md:92`
- `/app/docs/governance/registry_doctrine_v1.md:93`
- `/app/docs/governance/registry_doctrine_v1.md:94`
- `/app/docs/governance/registry_doctrine_v1.md:95`
- `/app/docs/governance/registry_doctrine_v1.md:96`
- `/app/docs/governance/registry_doctrine_v1.md:131`
- `/app/docs/governance/registry_doctrine_v1.md:154`
- `/app/docs/governance/registry_doctrine_v1.md:171`
- `/app/docs/registry/function_promise_registry_v0.md:47`
- `/app/docs/registry/function_promise_registry_v0.md:48`
- `/app/docs/registry/function_promise_registry_v0.md:49`
- `/app/docs/registry/function_promise_registry_v0.md:74`
- `/app/docs/registry/function_promise_registry_v0.md:75`
- `/app/docs/registry/function_promise_registry_v0.md:78`
- `/app/docs/registry/function_promise_registry_v0.md:133`
- `/app/docs/registry/function_promise_registry_v0.md:139`
- `/app/docs/registry/function_promise_registry_v0.md:141`
- `/app/docs/registry/function_promise_registry_v0.md:188`
- `/app/docs/registry/function_promise_registry_v0.md:202`
- `/app/docs/registry/function_promise_registry_v0.md:205`
- `/app/docs/registry/function_promise_registry_v0.md:207`

### T8 — Operating Values §1/§10 references to Shield

- `/app/docs/requirements/operating_values_v1.md:9`
- `/app/docs/requirements/operating_values_v1.md:13`
- `/app/docs/requirements/operating_values_v1.md:14`
- `/app/docs/requirements/operating_values_v1.md:15`
- `/app/docs/requirements/operating_values_v1.md:16`
- `/app/docs/requirements/operating_values_v1.md:18`
- `/app/docs/requirements/operating_values_v1.md:20`
- `/app/docs/requirements/operating_values_v1.md:28`
- `/app/docs/requirements/operating_values_v1.md:30`
- `/app/docs/requirements/operating_values_v1.md:44`
- `/app/docs/requirements/operating_values_v1.md:107`
- `/app/docs/requirements/operating_values_v1.md:109`
- `/app/docs/requirements/operating_values_v1.md:111`
- `/app/docs/requirements/operating_values_v1.md:113`
- `/app/docs/requirements/operating_values_v1.md:121`

### T9 — llm_router internals

- `/app/backend/services/synisense/shield/llm_router.py:16`
- `/app/backend/services/synisense/shield/llm_router.py:35`
- `/app/backend/services/synisense/shield/llm_router.py:38`
- `/app/backend/services/synisense/shield/llm_router.py:41`
- `/app/backend/services/synisense/shield/llm_router.py:48`
- `/app/backend/services/synisense/shield/llm_router.py:52`
- `/app/backend/services/synisense/shield/llm_router.py:55`
- `/app/backend/services/synisense/shield/llm_router.py:59`
- `/app/backend/services/synisense/shield/llm_router.py:66`
- `/app/backend/services/synisense/shield/llm_router.py:78`
- `/app/backend/services/synisense/shield/llm_router.py:83`
- `/app/backend/services/synisense/shield/llm_router.py:105`
- `/app/backend/services/synisense/shield/llm_router.py:108`
- `/app/backend/services/synisense/shield/llm_router.py:110`
- `/app/backend/services/synisense/shield/llm_router.py:118`
- `/app/backend/services/synisense/shield/llm_router.py:140`
- `/app/backend/services/synisense/shield/llm_router.py:144`
- `/app/backend/services/synisense/shield/llm_router.py:147`
- `/app/backend/services/synisense/shield/llm_router.py:150`
- `/app/backend/services/synisense/shield/llm_router.py:153`
- `/app/backend/services/synisense/shield/llm_router.py:157`
- `/app/backend/services/synisense/shield/llm_router.py:166`
- `/app/backend/services/synisense/shield/llm_router.py:168`
- `/app/backend/services/synisense/shield/llm_router.py:170`
- `/app/backend/services/synisense/shield/llm_router.py:187`
- `/app/backend/services/synisense/shield/llm_router.py:211`
- `/app/backend/services/synisense/shield/llm_router.py:218`
- `/app/backend/services/synisense/shield/llm_router.py:224`
- `/app/backend/services/synisense/shield/llm_router.py:227`
- `/app/backend/services/synisense/shield/client.py:30`
- `/app/backend/services/synisense/shield/client.py:54`
- `/app/backend/services/synisense/shield/client.py:67`
- `/app/backend/services/synisense/shield/client.py:81`
- `/app/backend/services/synisense/shield/client.py:83`
- `/app/backend/services/synisense/shield/client.py:135`

### T10 — Grounding gates

- `/app/backend/services/opportunity_briefs/brief_grounding.py:1`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:4`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:9`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:10`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:19`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:38`
- `/app/backend/services/opportunity_briefs/brief_grounding.py:63`
- `/app/docs/registry/function_promise_registry_v0.md:48`
- `/app/docs/registry/function_promise_registry_v0.md:50`
- `/app/docs/registry/function_promise_registry_v0.md:100`
- `/app/docs/registry/function_promise_registry_v0.md:101`
- `/app/docs/registry/function_promise_registry_v0.md:104`
- `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:19`
- `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:27`
- `/app/docs/rulings/answer_fluency_af_e1_to_e4.md:126`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:13`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:15`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:20`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:21`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:49`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:54`
- `/app/docs/rulings/opportunity_briefs_ob_e1_to_e3.md:98`

### T11 — Refusal envelopes

- `/app/backend/services/service_1/admission_refusal.py:5`
- `/app/backend/services/service_1/admission_refusal.py:22`
- `/app/backend/services/service_1/admission_refusal.py:26`
- `/app/backend/services/service_1/admission_refusal.py:35`
- `/app/backend/services/service_1/admission_refusal.py:46`
- `/app/backend/services/service_1/admission_refusal.py:55`
- `/app/backend/services/service_1/admission_refusal.py:59`
- `/app/backend/services/service_1/admission_refusal.py:87`
- `/app/backend/services/service_1/admission_refusal.py:110`
- `/app/backend/services/service_1/admission_refusal.py:126`
- `/app/backend/services/service_1/admission_refusal.py:158`
- `/app/backend/services/service_1/admission_refusal.py:178`
- `/app/backend/services/service_1/admission_refusal.py:204`
- `/app/backend/services/service_1/admission_refusal.py:218`
- `/app/backend/services/service_1/admission_refusal.py:249`
- `/app/backend/services/service_1/admission_refusal.py:263`
- `/app/backend/services/service_1/admission_refusal.py:317`
- `/app/backend/services/service_1/admission_refusal.py:356`
- `/app/backend/services/service_1/admission_refusal.py:416`
- `/app/backend/services/service_1/admission_refusal.py:455`
- `/app/backend/services/service_1/admission_refusal.py:493`
- `/app/backend/services/service_1/refusal_hints.py:17`
- `/app/backend/services/v2_gate/refusal.py:26`
- `/app/backend/services/compliance/refusal_family_classifier.py:23`
- `/app/backend/services/compliance/refusal_family_classifier.py:38`
- `/app/backend/services/compliance/refusal_family_classifier.py:53`
- `/app/backend/services/compliance/refusal_family_classifier.py:67`
- `/app/backend/services/compliance/refusal_family_classifier.py:77`
- `/app/backend/services/compliance/refusal_family_classifier.py:78`
- `/app/backend/services/compliance/refusal_family_classifier.py:110`
- `/app/backend/services/compliance/refusal_family_classifier.py:117`
- `/app/backend/services/northena/converge.py:131`
- `/app/backend/contracts/admission_refusal.py:1`
- `/app/backend/contracts/admission_refusal.py:22`
- `/app/backend/contracts/admission_refusal.py:41`
- `/app/backend/contracts/admission_refusal.py:61`
- `/app/backend/contracts/admission_refusal.py:71`
- `/app/backend/contracts/admission_refusal.py:83`
- `/app/backend/contracts/admission_refusal.py:87`
- `/app/backend/contracts/admission_refusal.py:97`
- `/app/backend/contracts/admission_refusal.py:109`
- `/app/backend/contracts/admission_refusal.py:155`
- `/app/backend/contracts/service_1_refusal.py:1`
- `/app/backend/contracts/service_1_refusal.py:37`
- `/app/backend/contracts/service_1_refusal.py:38`
- `/app/backend/contracts/service_1_refusal.py:51`

### T12 — Key custody

- `/app/backend/services/synisense/config.py:27`
- `/app/backend/services/synisense/config.py:120`
- `/app/backend/services/synisense/config.py:169`
- `/app/backend/services/synisense/shield/trust_receipt.py:11`
- `/app/backend/services/synisense/shield/trust_receipt.py:35`
- `/app/backend/services/synisense/shield/trust_receipt.py:64`
- `/app/backend/services/synisense/shield/trust_receipt.py:73`
- `/app/backend/services/synisense/shield/trust_receipt.py:77`
- `/app/backend/services/synisense/shield/trust_receipt.py:99`
- `/app/backend/services/synisense/shield/audit_log.py:4`
- `/app/backend/services/synisense/shield/audit_log.py:5`
- `/app/backend/services/synisense/shield/audit_log.py:20`
- `/app/backend/services/synisense/shield/audit_log.py:23`
- `/app/backend/services/synisense/shield/audit_log.py:24`
- `/app/backend/services/synisense/shield/audit_log.py:169`
- `/app/backend/services/synisense/shield/audit_log.py:172`
- `/app/backend/services/synisense/shield/canonical.py:1`
- `/app/backend/services/synisense/shield/canonical.py:8`
- `/app/backend/services/synisense/shield/canonical.py:11`
- `/app/backend/services/synisense/shield/canonical.py:57`
- `/app/backend/services/synisense/shield/canonical.py:71`
- `/app/backend/services/synisense/shield/canonical.py:81`
- `/app/backend/services/synisense/shield/canonical.py:93`
- `/app/backend/services/synisense/shield/canonical.py:119`
- `/app/backend/services/synisense/shield/llm_router.py:83`
- `/app/backend/services/synisense/shield/llm_router.py:144`
- `/app/backend/services/synisense/shield/llm_router.py:147`

## Section 4 — Bundle SHA-256 (computed post-archive)
_Reported in the parent reply; bundle-internal MANIFEST cannot embed its own outer archive SHA without recursion._

## Section 5 — Reproduction command
```
cd /tmp && tar -czf shield_engine_specs.tar.gz shield_engine_specs/
sha256sum /tmp/shield_engine_specs.tar.gz
```
