# Q1 · ARCHAEOLOGICAL CARRY-OVER · byte-identical from `consolidation_log_v0.md`

THIS ARTIFACT IS REPORT-LEVEL · NEVER BUILD-FAILING · RETIREMENT/MERGE REMAINS RULED ACTION

**Class:** Redundancy archaeology — Owner-ruled merge and tie-break decisions from `consolidation_log_v0.md` (RP-E1 α + tie-broke-toward-distinct).

**Run timestamp:** 2026-07-15T03:59:25.870757+00:00

**Source SHAs:**
- `docs/registry/function_promise_registry_v0.md`: `598a7ad4d326dd5c0fc003fe8091a52fd215fb63e76d5c04befd1aa4c25584b0`
- `docs/registry/function_promise_registry_v0.1_supplement.md`: `2822f99e0c20da6f8d02c1f33233965c90df37aeb6939e711da8df2ebd991092`
- `docs/registry/function_promise_registry_v0.2_supplement.md`: `25c5dd5ac515b34a41584dd2b4ba4eab20eb0ae5d40d9022320761056555b79a`
- `docs/registry/function_promise_registry_v0.3_supplement.md`: `8d4cd2ed9c4e802944517908424ba2297ac3b4dd5e0d2a8e6d54f6042e64a8e4`
- `docs/registry/function_promise_registry_v0.4_supplement.md`: `d1fa1949a206d5fb73481864962f93efaa888a4ef4793efad82a53681fc3dc1b`
- `docs/registry/function_promise_registry_v0.5_supplement.md`: `d2d0c5f4c37dcbe525ff99a757687d7ae81446cd738719341e2b7884d4ac778f`
- `docs/registry/consolidation_log_v0.md`: `2c60425599afbd59cb083cc8a391a94b717598a796a8028ca28ca4176ab26062`
- `docs/registry/machine/registry.yaml`: `669e620f1a752ed242e637c557c66a02d9cff1b83dc0d916aa6916787f7c1dca`

**Entry count:** 8

| entry_id | kind | promise_id | section_ref |
|---|---|---|---|
| CL-1.1 | MERGE | `PROM-S1-byte-verbatim-anchor-grounding` | consolidation_log_v0.md §1.1 |
| CL-1.2 | MERGE | `PROM-S1-no-semantic-scoring` | consolidation_log_v0.md §1.2 |
| CL-1.3 | MERGE | `PROM-S1-frozen-wire-contract` | consolidation_log_v0.md §1.3 |
| CL-1.4 | MERGE | `PROM-S1-class-honesty-render-time` | consolidation_log_v0.md §1.4 |
| CL-1.5 | TIE-BROKE-TOWARD-DISTINCT | `PROM-S1-runtime-transient-never-refusal` | consolidation_log_v0.md §1.5 |
| CL-1.6 | TIE-BROKE-TOWARD-DISTINCT | `PROM-S3-prove-any-operation` | consolidation_log_v0.md §1.6 |
| CL-1.7 | TIE-BROKE-TOWARD-DISTINCT | `PROM-S1-additive-versioning` | consolidation_log_v0.md §1.7 |
| CL-1.8 | TIE-BROKE-TOWARD-DISTINCT | `PROM-S3-mechanical-audit-of-promotion` | consolidation_log_v0.md §1.8 |

