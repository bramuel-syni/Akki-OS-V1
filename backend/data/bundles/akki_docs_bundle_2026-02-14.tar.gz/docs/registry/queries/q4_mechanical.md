# Q4 · MECHANICAL SCAN · behavioral-rule attestation · first-run DELIVERABLE per Owner RM-E3 α

THIS ARTIFACT IS REPORT-LEVEL · NEVER BUILD-FAILING · RETIREMENT/MERGE REMAINS RULED ACTION

**Class:** For every §3 function row in v1, verify it names its evidencing telemetry-or-gate; if not → UNVERIFIED. RM-E3 α client-promise flagging + advisory `remedy-candidate: P4` annotation permitted. Cross-referenced against archaeological finding subjects (SQ-E1 γ · PERMANENT).

**Run timestamp:** 2026-07-14T00:00:00+00:00

**Source SHAs:**
- `docs/registry/function_promise_registry_v1.md`: `d6ad136f65426c0f86df2227a540aac8142b24dd0cbb015b71ef2991a7a6718a`
- `docs/registry/function_promise_registry_v0.md`: `598a7ad4d326dd5c0fc003fe8091a52fd215fb63e76d5c04befd1aa4c25584b0`
- `docs/registry/function_promise_registry_v0.1_supplement.md`: `2822f99e0c20da6f8d02c1f33233965c90df37aeb6939e711da8df2ebd991092`
- `docs/registry/function_promise_registry_v0.2_supplement.md`: `25c5dd5ac515b34a41584dd2b4ba4eab20eb0ae5d40d9022320761056555b79a`
- `docs/registry/function_promise_registry_v0.3_supplement.md`: `8d4cd2ed9c4e802944517908424ba2297ac3b4dd5e0d2a8e6d54f6042e64a8e4`
- `docs/registry/function_promise_registry_v0.4_supplement.md`: `d1fa1949a206d5fb73481864962f93efaa888a4ef4793efad82a53681fc3dc1b`
- `docs/registry/function_promise_registry_v0.5_supplement.md`: `d2d0c5f4c37dcbe525ff99a757687d7ae81446cd738719341e2b7884d4ac778f`

**UNVERIFIED count:** 19  ·  **[CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE]:** 18  ·  **remedy-candidate: P4 advisory annotations:** 5  ·  **Overlaps with archaeological:** 7

## New UNVERIFIED candidates
| function_id | promise_ids | client_promise? | escalation_flag | remedy_advisory | detail |
|---|---|---|---|---|---|
| `synisense.shield.brief_id_namespace_boundary` | `PROM-S3-brief-namespace-distinct-from-trace` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Runtime 404 + namespace grep' lacks testable telemetry/gate reference |
| `northena.artifact.signature_bound` | `PROM-S4-artifact-signature-bound` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Runtime signature check' lacks testable telemetry/gate reference |
| `mtafiti.perception.pinned_model_provenance` | `PROM-S1-honesty-grammar-source-labels`, `PROM-9-2a-real-worker-provenance` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Contract field required (model_id + weights_sha)' lacks testable telemetry/gate reference |
| `mtafiti.perception.mode_selection_evident_at_read` | `PROM-9-2a-mode-selection-evident` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Contract field required (execution_mode)' lacks testable telemetry/gate reference |
| `mtafiti.census.dimension_registry_vocabulary` | `PROM-S1-honesty-grammar-source-labels`, `PROM-S2-census-dimension-integrity` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Vocabulary-set membership check' lacks testable telemetry/gate reference |
| `targeta.commission_wizard.shape_as_objective_prefill` | `PROM-S2-shape-as-objective-reach-only` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Runtime pre-fill contract' lacks testable telemetry/gate reference |
| `targeta.transform_form.per_call_provisioning` | `PROM-tf-transform-form-per-call-provisioning` | no | — | — | enforcement field 'Load-bearing internal contract (no snapshot)' lacks testable telemetry/gate reference |
| `targeta.transform_form.class_registry_additive` | `PROM-tf-class-with-claim-invariant` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Versioned-registry load + additive-only gate' lacks testable telemetry/gate reference |
| `governance.tiered_ruling_model` | `PROM-S3-governance-doc-on-disk` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'On-disk canonical + append-only amendments' lacks testable telemetry/gate reference |
| `governance.standing_rule_v3` | `PROM-S3-governance-doc-on-disk` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'Standing convention + reply-body SHA discipline' lacks testable telemetry/gate reference |
| `governance.registry_doctrine_v1` | `PROM-S3-governance-doc-on-disk`, `PROM-registry-rent-paying` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | — | enforcement field 'On-disk canonical + doctrine-ratification' lacks testable telemetry/gate reference |
| `registry.population.gaux_docs_on_disk` | `PROM-S3-governance-doc-on-disk` | yes | [CLIENT-PROMISE · UNVERIFIED · ESCALATE-AT-CLOSE] | remedy-candidate: P4 | enforcement field 'file-existence' lacks testable telemetry/gate reference |

## Overlaps with archaeological subjects (SQ-E1 γ)
| function_id | detail | overlaps |
|---|---|---|
| `synisense.shield.brief_synthesizer` | enforcement field 'Runtime chokepoint' lacks testable telemetry/gate reference | overlaps: CL-1.5 |
| `northena.retention.seam3_authorized_deletion` | enforcement field 'Runtime dual-control + audit-trail entry' lacks testable telemetry/gate reference | overlaps: Q2-03 |
| `targeta.transform_form.frozen_wire_contract` | enforcement field 'Frozen contract + JSON-schema regression' lacks testable telemetry/gate reference | overlaps: CL-1.3 |
| `akki.backend.tenant_entities_populates_from_s2_onboard` | enforcement field 'pytest (onboard walkthrough writes org_vocabulary ledger row)' lacks testable telemetry/gate reference | overlaps: CL-1.3 |
| `akki.instance.identity_from_config_only` | enforcement field 'pytest + integration curl' lacks testable telemetry/gate reference | overlaps: CL-1.3 |
| `akki.detune.fixture_dir_renamed_org_agnostic` | enforcement field 'git mv attest + reference-count' lacks testable telemetry/gate reference | overlaps: CL-1.3 |
| `akki.detune.branding_moved_to_instance_config` | enforcement field 'jest (Gate 3 Part A `zero_raw_fetch_calls_outside_apiClient`) + integration curl' lacks testable telemetry/gate reference | overlaps: CL-1.3 |

